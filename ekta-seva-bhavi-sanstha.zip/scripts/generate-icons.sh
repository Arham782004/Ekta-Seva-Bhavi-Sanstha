#!/usr/bin/env bash
set -e

mkdir -p public
mkdir -p dist

FONT_BOLD="/usr/share/fonts/truetype/freefont/FreeSansBold.ttf"

echo "Creating master 512x512 icon..."
# Create 512x512 master icon with ImageMagick
convert -size 512x512 xc:none \
  -fill "#064e3b" -draw "roundrectangle 0,0 511,511 80,80" \
  -stroke "#ca8a04" -strokewidth 6 -fill none -draw "circle 256,256 256,36" \
  -stroke "#eab308" -strokewidth 2 -fill none -draw "circle 256,256 256,48" \
  -stroke none -fill "#047857" -draw "circle 256,256 256,70" \
  -stroke none -fill "#eab308" -draw "path 'M 256,120 C 275,170 300,205 300,240 C 300,265 280,285 256,285 C 232,285 212,265 212,240 C 212,205 237,170 256,120 Z'" \
  -fill "#fef08a" -draw "path 'M 256,170 C 265,195 278,215 278,235 C 278,247 268,257 256,257 C 244,257 234,247 234,235 C 234,215 247,195 256,170 Z'" \
  -fill "#ffffff" -draw "path 'M 190,300 C 210,285 240,290 256,305 C 272,290 302,285 322,300 C 335,310 330,335 300,345 L 256,360 L 212,345 C 182,335 177,310 190,300 Z'" \
  -font "$FONT_BOLD" -pointsize 42 -fill "#fef08a" -gravity center -annotate +0+130 "EKTA" \
  -font "$FONT_BOLD" -pointsize 22 -fill "#a7f3d0" -gravity center -annotate +0+175 "SANSTHA" \
  -font "$FONT_BOLD" -pointsize 15 -fill "#ca8a04" -gravity center -annotate +0+205 "KALAMNURI" \
  public/icon-512x512.png

echo "Creating 192x192 icon..."
convert public/icon-512x512.png -resize 192x192 public/icon-192x192.png

echo "Creating maskable 512x512 icon (with adaptive safe margin)..."
convert -size 512x512 xc:"#064e3b" \
  \( public/icon-512x512.png -resize 410x410 \) -gravity center -composite \
  public/icon-maskable-512x512.png

echo "Creating maskable 192x192 icon..."
convert public/icon-maskable-512x512.png -resize 192x192 public/icon-maskable-192x192.png

echo "Creating apple-touch-icon and favicons..."
cp public/icon-192x192.png public/apple-touch-icon.png
convert public/icon-192x192.png -resize 48x48 public/favicon.png
convert public/icon-192x192.png -resize 32x32 public/favicon.ico

# Copy to dist as well
cp public/icon-*.png dist/ 2>/dev/null || true
cp public/apple-touch-icon.png dist/ 2>/dev/null || true
cp public/favicon.* dist/ 2>/dev/null || true

# Copy into android project mipmap directories
echo "Updating Android native mipmap launcher icons..."
RES_DIR="android/app/src/main/res"
if [ -d "$RES_DIR" ]; then
  convert public/icon-512x512.png -resize 48x48 "$RES_DIR/mipmap-mdpi/ic_launcher.png"
  convert public/icon-512x512.png -resize 72x72 "$RES_DIR/mipmap-hdpi/ic_launcher.png"
  convert public/icon-512x512.png -resize 96x96 "$RES_DIR/mipmap-xhdpi/ic_launcher.png"
  convert public/icon-512x512.png -resize 144x144 "$RES_DIR/mipmap-xxhdpi/ic_launcher.png"
  convert public/icon-512x512.png -resize 192x192 "$RES_DIR/mipmap-xxxhdpi/ic_launcher.png"

  convert public/icon-maskable-512x512.png -resize 48x48 "$RES_DIR/mipmap-mdpi/ic_launcher_round.png"
  convert public/icon-maskable-512x512.png -resize 72x72 "$RES_DIR/mipmap-hdpi/ic_launcher_round.png"
  convert public/icon-maskable-512x512.png -resize 96x96 "$RES_DIR/mipmap-xhdpi/ic_launcher_round.png"
  convert public/icon-maskable-512x512.png -resize 144x144 "$RES_DIR/mipmap-xxhdpi/ic_launcher_round.png"
  convert public/icon-maskable-512x512.png -resize 192x192 "$RES_DIR/mipmap-xxxhdpi/ic_launcher_round.png"
fi

echo "All icons generated successfully!"
ls -lh public/icon-*.png
