import { db, hashPassword, verifyPassword, getNextMemberId, getNextReceiptNumber } from '../server/db.js';
import crypto from 'node:crypto';

async function runTests() {
  console.log('--- RUNNING FULL SYSTEM TEST SUITE: EKTA SEVA BHAVI SANSTHA ---');
  let passed = 0;
  let failed = 0;

  function assert(condition: boolean, msg: string) {
    if (condition) {
      console.log(`  ✓ PASS: ${msg}`);
      passed++;
    } else {
      console.error(`  ✗ FAIL: ${msg}`);
      failed++;
    }
  }

  // TEST 1: Password hashing & verification
  console.log('\n[Test Group 1: Authentication & Hashing]');
  const pass = 'admin123';
  const { hash, salt } = hashPassword(pass);
  assert(verifyPassword(pass, hash, salt), 'Password matches hash with scrypt');
  assert(!verifyPassword('wrongpass', hash, salt), 'Wrong password rejected');

  // TEST 2: Admin user existence & login
  console.log('\n[Test Group 2: Admin Bootstrap]');
  const admin = db.findUserByLogin('admin@ektasanstha.org');
  assert(!!admin, 'Admin account exists');
  assert(admin?.role === 'admin', 'Admin has admin role');
  assert(verifyPassword('admin123', admin!.passwordHash, admin!.salt), 'Admin can log in with default credentials');

  // TEST 3: Sequential Member ID generation
  console.log('\n[Test Group 3: Member Management]');
  const currentMembers = db.getMembers();
  const nextId = getNextMemberId(currentMembers);
  assert(/^M\d{3}$/.test(nextId), `Next member ID is correctly formatted: ${nextId}`);

  // Create test member
  const newMember = db.createMember(
    {
      fullName: 'Devidas Narayanrao Mali',
      mobile: '9811223344',
      email: 'devidas.mali@example.com',
      address: 'Mali Galli, Kalamnuri',
      joiningDate: '2026-10-01',
      monthlyContributionPaise: 100000,
      status: 'active',
      notes: 'Test member',
    },
    'USR-ADMIN-1',
    'Santoshrao Mali'
  );
  assert(newMember.memberId === nextId, `Created member has expected ID: ${newMember.memberId}`);
  assert(newMember.monthlyContributionPaise === 100000, 'Member monthly contribution is ₹1,000 (100000 paise)');

  // TEST 4: Monthly Dues Generation & Duplicate Prevention
  console.log('\n[Test Group 4: Monthly Dues System]');
  const testMonth = '2026-11';
  const genResult = db.generateMonthlyDues(testMonth, 'USR-ADMIN-1', 'Santoshrao Mali');
  assert(genResult.generatedCount > 0, `Generated ${genResult.generatedCount} dues for ${testMonth}`);

  // Try generating again - should not duplicate!
  const genResult2 = db.generateMonthlyDues(testMonth, 'USR-ADMIN-1', 'Santoshrao Mali');
  assert(genResult2.generatedCount === 0, 'Duplicate generation prevented for same month');
  assert(genResult2.alreadyExistingCount > 0, 'Existing dues recognized and skipped');

  // TEST 5: Cash Payment Entry & Ledger Update
  console.log('\n[Test Group 5: Cash Payment & Receipts]');
  const beforeStats = db.getDashboardStats();
  const cashRes = db.recordCashPayment({
    memberId: newMember.memberId,
    monthYear: testMonth,
    amountPaise: 100000,
    paymentDate: new Date().toISOString(),
    receivedByAdminName: 'Santoshrao Mali',
    notes: 'Full payment received',
    actorId: 'USR-ADMIN-1',
    actorName: 'Santoshrao Mali',
  });

  assert(cashRes.payment.status === 'verified', 'Cash payment status is verified');
  assert(cashRes.payment.paymentMethod === 'cash', 'Payment method is cash');
  assert(cashRes.receipt.receiptNumber.startsWith('ESBS-'), `Receipt number starts with ESBS-: ${cashRes.receipt.receiptNumber}`);
  assert(cashRes.receipt.amountPaise === 100000, 'Receipt amount is exactly 100000 paise');

  const afterStats = db.getDashboardStats();
  assert(
    afterStats.cashCollectionPaise === beforeStats.cashCollectionPaise + 100000,
    'Cash collection total accurately updated by ₹1,000'
  );

  // TEST 6: Online Payment & HMAC Signature Verification
  console.log('\n[Test Group 6: Online Payment HMAC Verification]');
  const orderId = 'order_test_999';
  const paymentId = 'pay_test_999';
  const settings = db.getSettings();
  const hmac = crypto.createHmac('sha256', settings.razorpayKeySecret);
  hmac.update(`${orderId}|${paymentId}`);
  const validSignature = hmac.digest('hex');

  const onlineRes = db.verifyAndCreditOnlinePayment({
    memberId: newMember.memberId,
    monthYear: '2026-12',
    amountPaise: 100000,
    gatewayOrderId: orderId,
    gatewayPaymentId: paymentId,
    gatewaySignature: validSignature,
    verifiedByServer: true,
  });

  assert(onlineRes.payment.status === 'verified', 'Online payment verified');
  assert(onlineRes.payment.paymentMethod === 'online_upi', 'Online payment method recorded as online_upi');
  assert(onlineRes.payment.gatewayPaymentId === paymentId, 'Payment ID accurately recorded');

  // Duplicate online payment prevention
  const duplicateOnline = db.verifyAndCreditOnlinePayment({
    memberId: newMember.memberId,
    monthYear: '2026-12',
    amountPaise: 100000,
    gatewayOrderId: orderId,
    gatewayPaymentId: paymentId,
    gatewaySignature: validSignature,
    verifiedByServer: true,
  });
  assert(duplicateOnline.payment.id === onlineRes.payment.id, 'Duplicate online payment prevented via idempotency');

  // TEST 7: Payment Reversal with Audit Trail
  console.log('\n[Test Group 7: Payment Reversal & Audit]');
  const reversedPay = db.reversePayment(
    onlineRes.payment.id,
    'Duplicate bank transaction test correction',
    'USR-ADMIN-1',
    'Santoshrao Mali'
  );
  assert(reversedPay.status === 'reversed', 'Payment status marked as reversed');
  assert(Boolean(reversedPay.reversalReason?.includes('Duplicate')), 'Reversal reason recorded');

  // Verify dashboard excludes reversed transactions
  const reversedStats = db.getDashboardStats();
  const verifiedOnlinePayments = db.getPayments().filter((p) => p.status === 'verified' && p.paymentMethod === 'online_upi');
  const sumVerifiedOnline = verifiedOnlinePayments.reduce((s, p) => s + p.amountPaise, 0);
  assert(reversedStats.onlineCollectionPaise === sumVerifiedOnline, 'Reversed payment excluded from verified collection totals');

  // Check audit log
  const auditLogs = db.getAuditLogs();
  assert(auditLogs.some((l) => l.action === 'REVERSE_PAYMENT'), 'Audit log contains REVERSE_PAYMENT entry');

  // Summary
  console.log(`\n========================================`);
  console.log(`TEST RESULTS: ${passed} PASSED, ${failed} FAILED`);
  console.log(`========================================\n`);

  if (failed > 0) {
    process.exit(1);
  }
}

runTests().catch((err) => {
  console.error('Test execution error:', err);
  process.exit(1);
});
