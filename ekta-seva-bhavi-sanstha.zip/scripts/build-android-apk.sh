#!/usr/bin/env bash
set -e

APP_DIR="/app/applet"
TOOLS_DIR="$APP_DIR/tools"
SDK_DIR="$TOOLS_DIR/android-sdk"
JDK_DIR="$TOOLS_DIR/jdk21"

echo "=== 1. Checking Java 21 ==="
if [ ! -f "$JDK_DIR/bin/java" ]; then
  echo "Downloading OpenJDK 21 Temurin..."
  mkdir -p "$JDK_DIR"
  curl -sSL https://github.com/adoptium/temurin21-binaries/releases/download/jdk-21.0.5%2B11/OpenJDK21U-jdk_x64_linux_hotspot_21.0.5_11.tar.gz | tar -xz -C "$JDK_DIR" --strip-components=1
fi

export JAVA_HOME="$JDK_DIR"
export PATH="$JDK_DIR/bin:$PATH"
java -version

echo "=== 2. Setting up Android SDK in $SDK_DIR ==="
mkdir -p "$SDK_DIR/cmdline-tools"

if [ ! -d "$SDK_DIR/cmdline-tools/latest" ]; then
  echo "Downloading Android Command-line Tools..."
  curl -sS -o /tmp/cmdline-tools.zip https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
  mkdir -p /tmp/cmdline-unzip
  unzip -q /tmp/cmdline-tools.zip -d /tmp/cmdline-unzip
  mv /tmp/cmdline-unzip/cmdline-tools "$SDK_DIR/cmdline-tools/latest"
  rm -rf /tmp/cmdline-tools.zip /tmp/cmdline-unzip
fi

export ANDROID_HOME="$SDK_DIR"
export PATH="$SDK_DIR/cmdline-tools/latest/bin:$SDK_DIR/platform-tools:$PATH"

echo "sdk.dir=$SDK_DIR" > "$APP_DIR/android/local.properties"

echo "Accepting Android Licenses..."
yes | "$SDK_DIR/cmdline-tools/latest/bin/sdkmanager" --sdk_root="$SDK_DIR" --licenses >/dev/null 2>&1 || true

echo "Installing platforms;android-34, platforms;android-36, and build-tools;34.0.0, build-tools;35.0.0..."
"$SDK_DIR/cmdline-tools/latest/bin/sdkmanager" --sdk_root="$SDK_DIR" \
  "platforms;android-34" \
  "platforms;android-36" \
  "build-tools;34.0.0" \
  "build-tools;35.0.0" \
  "platform-tools"

echo "=== 3. Syncing Capacitor Android ==="
cd "$APP_DIR"
npm run build
npx cap sync android

echo "=== 4. Compiling Android Debug APK with Gradle ==="
cd "$APP_DIR/android"
chmod +x ./gradlew
./gradlew assembleDebug --stacktrace


echo "=== 5. Checking Generated APK ==="
APK_PATH="$APP_DIR/android/app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK_PATH" ]; then
  echo "SUCCESS! APK Generated at: $APK_PATH"
  ls -lh "$APK_PATH"
  mkdir -p "$APP_DIR/dist" "$APP_DIR/public"
  cp "$APK_PATH" "$APP_DIR/dist/app-debug.apk"
  cp "$APK_PATH" "$APP_DIR/public/app-debug.apk"
  echo "Copied to $APP_DIR/dist/app-debug.apk and $APP_DIR/public/app-debug.apk for instant HTTP download."
else
  echo "ERROR: APK was not found at $APK_PATH"
  exit 1
fi
