#!/usr/bin/env bash
set -e

echo "=== Setting up Android SDK ==="
mkdir -p /opt/android-sdk/cmdline-tools

if [ ! -d "/opt/android-sdk/cmdline-tools/latest" ]; then
  echo "Downloading Android command-line tools..."
  curl -sS -o /tmp/cmdline-tools.zip https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
  
  echo "Extracting tools..."
  mkdir -p /tmp/cmdline-unzip
  unzip -q /tmp/cmdline-tools.zip -d /tmp/cmdline-unzip
  mv /tmp/cmdline-unzip/cmdline-tools /opt/android-sdk/cmdline-tools/latest
  rm -rf /tmp/cmdline-tools.zip /tmp/cmdline-unzip
fi

export ANDROID_HOME=/opt/android-sdk
export PATH=$PATH:/opt/android-sdk/cmdline-tools/latest/bin:/opt/android-sdk/platform-tools

echo "Accepting SDK licenses..."
yes | /opt/android-sdk/cmdline-tools/latest/bin/sdkmanager --sdk_root=/opt/android-sdk --licenses >/dev/null 2>&1 || true

echo "Installing platforms;android-34 and build-tools;34.0.0..."
/opt/android-sdk/cmdline-tools/latest/bin/sdkmanager --sdk_root=/opt/android-sdk "platforms;android-34" "build-tools;34.0.0" "platform-tools"

echo "Setting up local.properties..."
echo "sdk.dir=/opt/android-sdk" > /app/applet/android/local.properties

echo "=== Android SDK setup completed successfully ==="
