import fs from 'node:fs';
import path from 'node:path';
import { Resvg } from '@resvg/resvg-js';

const publicDir = path.resolve(process.cwd(), 'public');
const distDir = path.resolve(process.cwd(), 'dist');
if (!fs.existsSync(publicDir)) fs.mkdirSync(publicDir, { recursive: true });
if (!fs.existsSync(distDir)) fs.mkdirSync(distDir, { recursive: true });

// The EXACT SVG emblem from SansthaLogo.tsx
const standardSvg = `<svg viewBox="0 0 100 100" width="512" height="512" fill="none" xmlns="http://www.w3.org/2000/svg">
  <!-- Outer circle -->
  <circle cx="50" cy="50" r="48" fill="#1E40AF" stroke="#F59E0B" stroke-width="3" />
  <circle cx="50" cy="50" r="44" stroke="#60A5FA" stroke-width="1" stroke-dasharray="3 3" />

  <!-- Sun rays at top -->
  <path
    d="M50 12 L50 20 M38 15 L42 22 M62 15 L58 22 M27 24 L34 28 M73 24 L66 28"
    stroke="#F59E0B"
    stroke-width="2"
    stroke-linecap="round"
  />

  <!-- Banyan Tree / Unity emblem in center -->
  <path
    d="M50 32 C42 32 36 38 36 45 C36 48 38 51 40 53 C38 56 38 60 42 62 C44 63 46 63 48 62 L48 70 L44 76 L48 76 L50 72 L52 76 L56 76 L52 70 L52 62 C54 63 56 63 58 62 C62 60 62 56 60 53 C62 51 64 48 64 45 C64 38 58 32 50 32 Z"
    fill="#34D399"
  />

  <!-- Supporting open hands at bottom representing Seva & Unity -->
  <path
    d="M24 66 C28 62 34 60 40 62 C43 63 44 66 42 69 C37 69 33 71 28 75 C25 78 22 75 24 66 Z"
    fill="#FBBF24"
  />
  <path
    d="M76 66 C72 62 66 60 60 62 C57 63 56 66 58 69 C63 69 67 71 72 75 C75 78 78 75 76 66 Z"
    fill="#FBBF24"
  />

  <!-- Center Rupee symbol -->
  <circle cx="50" cy="48" r="6" fill="#FFFFFF" />
  <text
    x="50"
    y="50.5"
    text-anchor="middle"
    dominant-baseline="middle"
    fill="#1E40AF"
    font-size="7"
    font-weight="bold"
    font-family="DejaVu Sans, Arial, sans-serif"
  >
    ₹
  </text>

  <!-- Bottom Banner ribbon with Sanstha text -->
  <path
    d="M26 82 L74 82 L70 88 L30 88 Z"
    fill="#F59E0B"
  />
  <text
    x="50"
    y="86.5"
    text-anchor="middle"
    dominant-baseline="middle"
    fill="#1E3A8A"
    font-size="4.5"
    font-weight="bold"
    letter-spacing="0.5"
    font-family="DejaVu Sans, Arial, sans-serif"
  >
    एकता सेवा
  </text>
</svg>`;

// Maskable SVG with safe margin (80% scale centered on matching #1E40AF royal blue background)
const maskableSvg = `<svg viewBox="0 0 100 100" width="512" height="512" xmlns="http://www.w3.org/2000/svg">
  <rect width="100" height="100" fill="#1E40AF" />
  <g transform="translate(10, 10) scale(0.8)">
    <!-- Outer circle -->
    <circle cx="50" cy="50" r="48" fill="#1E40AF" stroke="#F59E0B" stroke-width="3" />
    <circle cx="50" cy="50" r="44" stroke="#60A5FA" stroke-width="1" stroke-dasharray="3 3" />

    <!-- Sun rays at top -->
    <path
      d="M50 12 L50 20 M38 15 L42 22 M62 15 L58 22 M27 24 L34 28 M73 24 L66 28"
      stroke="#F59E0B"
      stroke-width="2"
      stroke-linecap="round"
    />

    <!-- Banyan Tree / Unity emblem in center -->
    <path
      d="M50 32 C42 32 36 38 36 45 C36 48 38 51 40 53 C38 56 38 60 42 62 C44 63 46 63 48 62 L48 70 L44 76 L48 76 L50 72 L52 76 L56 76 L52 70 L52 62 C54 63 56 63 58 62 C62 60 62 56 60 53 C62 51 64 48 64 45 C64 38 58 32 50 32 Z"
      fill="#34D399"
    />

    <!-- Supporting open hands at bottom representing Seva & Unity -->
    <path
      d="M24 66 C28 62 34 60 40 62 C43 63 44 66 42 69 C37 69 33 71 28 75 C25 78 22 75 24 66 Z"
      fill="#FBBF24"
    />
    <path
      d="M76 66 C72 62 66 60 60 62 C57 63 56 66 58 69 C63 69 67 71 72 75 C75 78 78 75 76 66 Z"
      fill="#FBBF24"
    />

    <!-- Center Rupee symbol -->
    <circle cx="50" cy="48" r="6" fill="#FFFFFF" />
    <text
      x="50"
      y="50.5"
      text-anchor="middle"
      dominant-baseline="middle"
      fill="#1E40AF"
      font-size="7"
      font-weight="bold"
      font-family="DejaVu Sans, Arial, sans-serif"
    >
      ₹
    </text>

    <!-- Bottom Banner ribbon with Sanstha text -->
    <path
      d="M26 82 L74 82 L70 88 L30 88 Z"
      fill="#F59E0B"
    />
    <text
      x="50"
      y="86.5"
      text-anchor="middle"
      dominant-baseline="middle"
      fill="#1E3A8A"
      font-size="4.5"
      font-weight="bold"
      letter-spacing="0.5"
      font-family="DejaVu Sans, Arial, sans-serif"
    >
      एकता सेवा
    </text>
  </g>
</svg>`;

// Write master SVG
fs.writeFileSync(path.join(publicDir, 'icon.svg'), standardSvg);
if (fs.existsSync(distDir)) {
  fs.writeFileSync(path.join(distDir, 'icon.svg'), standardSvg);
}

function renderPng(svgString, size) {
  const resvg = new Resvg(svgString, {
    fitTo: {
      mode: 'width',
      value: size,
    },
  });
  const pngData = resvg.render();
  return pngData.asPng();
}

console.log('Rendering 512x512 PNG...');
const png512 = renderPng(standardSvg, 512);
fs.writeFileSync(path.join(publicDir, 'icon-512x512.png'), png512);

console.log('Rendering 192x192 PNG...');
const png192 = renderPng(standardSvg, 192);
fs.writeFileSync(path.join(publicDir, 'icon-192x192.png'), png192);

console.log('Rendering maskable 512x512 PNG...');
const maskable512 = renderPng(maskableSvg, 512);
fs.writeFileSync(path.join(publicDir, 'icon-maskable-512x512.png'), maskable512);

console.log('Rendering maskable 192x192 PNG...');
const maskable192 = renderPng(maskableSvg, 192);
fs.writeFileSync(path.join(publicDir, 'icon-maskable-192x192.png'), maskable192);

console.log('Rendering apple-touch-icon (180x180)...');
const appleIcon = renderPng(standardSvg, 180);
fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), appleIcon);

console.log('Rendering favicons (48x48 & 32x32)...');
const favicon48 = renderPng(standardSvg, 48);
fs.writeFileSync(path.join(publicDir, 'favicon.png'), favicon48);
const favicon32 = renderPng(standardSvg, 32);
fs.writeFileSync(path.join(publicDir, 'favicon.ico'), favicon32);

// Copy to dist
for (const file of [
  'icon-512x512.png',
  'icon-192x192.png',
  'icon-maskable-512x512.png',
  'icon-maskable-192x192.png',
  'apple-touch-icon.png',
  'favicon.png',
  'favicon.ico',
]) {
  fs.copyFileSync(path.join(publicDir, file), path.join(distDir, file));
}

// Copy to Android project mipmap directories
const resDir = path.resolve(process.cwd(), 'android/app/src/main/res');
if (fs.existsSync(resDir)) {
  console.log('Updating Android mipmap drawables...');
  const mipmapSizes = [
    { dir: 'mipmap-mdpi', size: 48 },
    { dir: 'mipmap-hdpi', size: 72 },
    { dir: 'mipmap-xhdpi', size: 96 },
    { dir: 'mipmap-xxhdpi', size: 144 },
    { dir: 'mipmap-xxxhdpi', size: 192 },
  ];

  for (const m of mipmapSizes) {
    const targetFolder = path.join(resDir, m.dir);
    if (fs.existsSync(targetFolder)) {
      const standardIcon = renderPng(standardSvg, m.size);
      const roundIcon = renderPng(maskableSvg, m.size);
      fs.writeFileSync(path.join(targetFolder, 'ic_launcher.png'), standardIcon);
      fs.writeFileSync(path.join(targetFolder, 'ic_launcher_round.png'), roundIcon);
    }
  }
}

console.log('PWA icons successfully generated from existing Home Page SansthaLogo design!');
