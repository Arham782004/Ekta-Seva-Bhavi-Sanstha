#!/usr/bin/env bash
set -e

echo "=== Generating all Ekta Seva Bhavi Sanstha App & Android Assets ==="

SVG_FILE="public/icon.svg"
FONT="/usr/share/fonts/truetype/freefont/FreeSansBold.ttf"

if [ ! -f "$SVG_FILE" ]; then
  echo "Error: $SVG_FILE not found!"
  exit 1
fi

mkdir -p public
mkdir -p dist

# 1. Master PNG generation directly from SVG
echo "[1/4] Rendering Master 512x512 logo PNG from SVG..."
rsvg-convert -w 512 -h 512 "$SVG_FILE" -o public/icon-512x512.png

echo "[2/4] Generating PWA and Web launcher icons..."
convert public/icon-512x512.png -resize 192x192 public/icon-192x192.png

# Maskable icons: 80% safe zone with clean solid/transparent padding
convert -size 512x512 xc:"#1E40AF" \
  \( public/icon-512x512.png -resize 410x410 \) -gravity center -composite \
  public/icon-maskable-512x512.png

convert public/icon-maskable-512x512.png -resize 192x192 public/icon-maskable-192x192.png

# Apple Touch Icon & Favicons
cp public/icon-192x192.png public/apple-touch-icon.png
convert public/icon-192x192.png -resize 48x48 public/favicon.png
convert public/icon-192x192.png -resize 32x32 public/favicon.ico

# Copy to dist if dist exists
mkdir -p dist
cp public/icon-*.png dist/ 2>/dev/null || true
cp public/icon.svg dist/ 2>/dev/null || true
cp public/apple-touch-icon.png dist/ 2>/dev/null || true
cp public/favicon.* dist/ 2>/dev/null || true

# 3. Android Mipmap Launcher Icons
RES_DIR="android/app/src/main/res"
if [ -d "$RES_DIR" ]; then
  echo "[3/4] Generating Android native launcher icon assets across all densities..."

  # Density configs: dir_name launcher_size foreground_canvas_size foreground_icon_size
  densities=(
    "mipmap-mdpi 48 108 72"
    "mipmap-hdpi 72 162 108"
    "mipmap-xhdpi 96 216 144"
    "mipmap-xxhdpi 144 324 216"
    "mipmap-xxxhdpi 192 432 288"
  )

  for entry in "${densities[@]}"; do
    read -r dir l_size f_canvas f_logo <<< "$entry"
    mkdir -p "$RES_DIR/$dir"

    # Standard launcher icon
    convert public/icon-512x512.png -resize "${l_size}x${l_size}" "$RES_DIR/$dir/ic_launcher.png"

    # Circular launcher icon
    convert public/icon-512x512.png -resize "${l_size}x${l_size}" "$RES_DIR/$dir/ic_launcher_round.png"

    # Adaptive foreground icon (centered within 66% viewport on transparent canvas)
    convert -size "${f_canvas}x${f_canvas}" xc:none \
      \( public/icon-512x512.png -resize "${f_logo}x${f_logo}" \) -gravity center -composite \
      "$RES_DIR/$dir/ic_launcher_foreground.png"
  done

  # 4. Android Splash Screens
  echo "[4/4] Generating Android splash screen assets with exact logo and name..."

  # Helper function for portrait splash
  generate_port_splash() {
    local outfile="$1"
    local w="$2"
    local h="$3"
    local icon_size="$4"
    local top_offset="$5"
    local text1_y="$6"
    local text2_y="$7"
    local text3_y="$8"
    local pt1="$9"
    local pt2="${10}"
    local pt3="${11}"

    mkdir -p "$(dirname "$outfile")"
    convert -size "${w}x${h}" "xc:#0f172a" \
      \( public/icon-512x512.png -resize "${icon_size}x${icon_size}" \) -gravity north -geometry "+0+${top_offset}" -composite \
      -font "$FONT" -pointsize "$pt1" -fill "#ffffff" -gravity north -annotate "+0+${text1_y}" "Ekta Seva Bhavi Sanstha" \
      -font "$FONT" -pointsize "$pt2" -fill "#fbbf24" -gravity north -annotate "+0+${text2_y}" "एकता सेवा भावी संस्था, कळमनुरी" \
      -font "$FONT" -pointsize "$pt3" -fill "#94a3b8" -gravity north -annotate "+0+${text3_y}" "Reg. No: MAH/KLM/1048/2022" \
      "$outfile"
  }

  # Helper function for landscape splash
  generate_land_splash() {
    local outfile="$1"
    local w="$2"
    local h="$3"
    local icon_size="$4"
    local top_offset="$5"
    local text1_y="$6"
    local text2_y="$7"
    local text3_y="$8"
    local pt1="$9"
    local pt2="${10}"
    local pt3="${11}"

    mkdir -p "$(dirname "$outfile")"
    convert -size "${w}x${h}" "xc:#0f172a" \
      \( public/icon-512x512.png -resize "${icon_size}x${icon_size}" \) -gravity north -geometry "+0+${top_offset}" -composite \
      -font "$FONT" -pointsize "$pt1" -fill "#ffffff" -gravity north -annotate "+0+${text1_y}" "Ekta Seva Bhavi Sanstha" \
      -font "$FONT" -pointsize "$pt2" -fill "#fbbf24" -gravity north -annotate "+0+${text2_y}" "एकता सेवा भावी संस्था, कळमनुरी" \
      -font "$FONT" -pointsize "$pt3" -fill "#94a3b8" -gravity north -annotate "+0+${text3_y}" "Reg. No: MAH/KLM/1048/2022" \
      "$outfile"
  }

  # Portrait Splashes
  generate_port_splash "$RES_DIR/drawable-port-mdpi/splash.png"    320  480  120 100 235 260 282 16 11 9
  generate_port_splash "$RES_DIR/drawable-port-hdpi/splash.png"    480  800  180 180 380 415 445 23 15 11
  generate_port_splash "$RES_DIR/drawable-port-xhdpi/splash.png"   720 1280  260 300 580 630 670 33 21 14
  generate_port_splash "$RES_DIR/drawable-port-xxhdpi/splash.png"  960 1600  340 400 770 830 880 42 27 18
  generate_port_splash "$RES_DIR/drawable-port-xxxhdpi/splash.png" 1280 1920 440 480 960 1030 1090 54 34 22
  generate_port_splash "$RES_DIR/drawable/splash.png"              480  800  180 180 380 415 445 23 15 11

  # Landscape Splashes
  generate_land_splash "$RES_DIR/drawable-land-mdpi/splash.png"    480  320  100  40 155 180 200 16 11 9
  generate_land_splash "$RES_DIR/drawable-land-hdpi/splash.png"    800  480  140  70 230 260 285 22 14 10
  generate_land_splash "$RES_DIR/drawable-land-xhdpi/splash.png"   1280  720 200 120 345 390 425 32 20 14
  generate_land_splash "$RES_DIR/drawable-land-xxhdpi/splash.png"  1600  960 260 180 470 530 575 40 25 17
  generate_land_splash "$RES_DIR/drawable-land-xxxhdpi/splash.png" 1920 1280 340 240 620 690 750 48 30 20

  echo "Android mipmaps and splash screens updated successfully!"
fi

echo "=== All assets generated and verified successfully! ==="
