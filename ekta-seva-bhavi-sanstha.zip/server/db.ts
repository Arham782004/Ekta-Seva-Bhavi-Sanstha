import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {
  User,
  Member,
  MonthlyDue,
  Payment,
  Receipt,
  AppNotification,
  AuditLog,
  OrganizationSettings,
  DashboardStats,
  MonthlyChartData,
  SansthaUpdate,
  SansthaExpense,
  SharedSansthaFinancials,
  MemberAttendanceSummary,
  StaffPermissions,
} from '../src/types/index.js';
import { inrToWords } from '../src/utils/formatters.js';

interface DatabaseSchema {
  version: number;
  settings: OrganizationSettings;
  users: User[];
  members: Member[];
  dues: MonthlyDue[];
  payments: Payment[];
  receipts: Receipt[];
  notifications: AppNotification[];
  auditLogs: AuditLog[];
  processedWebhookEventIds: string[];
  updates: SansthaUpdate[];
  expenses: SansthaExpense[];
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'sanstha_database.json');

// Password hashing utility using Node.js scrypt
export function hashPassword(password: string, salt?: string): { hash: string; salt: string } {
  const chosenSalt = salt || crypto.randomBytes(16).toString('hex');
  const derivedKey = crypto.scryptSync(password, chosenSalt, 64);
  return {
    hash: derivedKey.toString('hex'),
    salt: chosenSalt,
  };
}

export function verifyPassword(password: string, hash: string, salt: string): boolean {
  try {
    const derivedKey = crypto.scryptSync(password, salt, 64);
    const keyBuffer = Buffer.from(hash, 'hex');
    return crypto.timingSafeEqual(derivedKey, keyBuffer);
  } catch {
    return false;
  }
}

// Generate unique sequential Member ID
export function getNextMemberId(existingMembers: Member[]): string {
  let maxNum = 0;
  for (const m of existingMembers) {
    const match = m.memberId.match(/^M(\d+)$/i);
    if (match) {
      const num = parseInt(match[1], 10);
      if (num > maxNum) maxNum = num;
    }
  }
  return `M${String(maxNum + 1).padStart(3, '0')}`;
}

// Generate unique Receipt Number
export function getNextReceiptNumber(existingReceipts: Receipt[], prefix: string = 'ESBS'): string {
  const year = new Date().getFullYear();
  let maxSeq = 0;
  for (const r of existingReceipts) {
    const parts = r.receiptNumber.split('-');
    if (parts.length >= 3 && parts[1] === String(year)) {
      const seq = parseInt(parts[2], 10);
      if (!isNaN(seq) && seq > maxSeq) maxSeq = seq;
    }
  }
  return `${prefix}-${year}-${String(maxSeq + 1).padStart(4, '0')}`;
}

class SansthaDatabase {
  private data: DatabaseSchema;

  constructor() {
    this.data = this.loadOrInit();
  }

  private loadOrInit(): DatabaseSchema {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }

    if (fs.existsSync(DB_FILE)) {
      try {
        const content = fs.readFileSync(DB_FILE, 'utf-8');
        const loaded = JSON.parse(content) as DatabaseSchema;
        let modified = false;
        if (!loaded.updates || !Array.isArray(loaded.updates)) {
          loaded.updates = this.getInitialUpdates();
          modified = true;
        }
        if (!loaded.expenses || !Array.isArray(loaded.expenses)) {
          loaded.expenses = this.getInitialExpenses();
          modified = true;
        }
        if (loaded.settings) {
          if (loaded.settings.showFinancialSummaryToMembers === undefined) loaded.settings.showFinancialSummaryToMembers = true;
          if (loaded.settings.presidentName === undefined) loaded.settings.presidentName = 'Santoshrao Mali';
          if (loaded.settings.appSubtitle === undefined) loaded.settings.appSubtitle = 'माळी गल्ली, कळमनुरी - मासिक योगदान आणि सदस्य निधी व्यवस्थापन पोर्टल';
          if (loaded.settings.themePrimaryColor === undefined) loaded.settings.themePrimaryColor = '#1e3a8a';
          if (loaded.settings.themeSecondaryColor === undefined) loaded.settings.themeSecondaryColor = '#d97706';
          if (loaded.settings.themeAccentColor === undefined) loaded.settings.themeAccentColor = '#059669';
          if (loaded.settings.allowStaffLogin === undefined) loaded.settings.allowStaffLogin = true;
          if (loaded.settings.allowMemberLogin === undefined) loaded.settings.allowMemberLogin = true;
          if (loaded.settings.sessionTimeoutMinutes === undefined) loaded.settings.sessionTimeoutMinutes = 120;
          if (loaded.settings.requirePasswordMinLength === undefined) loaded.settings.requirePasswordMinLength = 6;
          if (loaded.settings.maxFailedLoginAttempts === undefined) loaded.settings.maxFailedLoginAttempts = 5;
          if (loaded.settings.memberIdPrefix === undefined) loaded.settings.memberIdPrefix = 'M';
          if (loaded.settings.memberIdDigits === undefined) loaded.settings.memberIdDigits = 3;
          if (loaded.settings.autoAssignMemberId === undefined) loaded.settings.autoAssignMemberId = true;
          if (loaded.settings.requireEmailForMembers === undefined) loaded.settings.requireEmailForMembers = false;
          if (loaded.settings.requireAddressForMembers === undefined) loaded.settings.requireAddressForMembers = true;
          if (loaded.settings.enableCashPayments === undefined) loaded.settings.enableCashPayments = true;
          if (loaded.settings.enableUpiPayments === undefined) loaded.settings.enableUpiPayments = true;
          if (loaded.settings.enableBankTransfer === undefined) loaded.settings.enableBankTransfer = true;
          if (loaded.settings.bankName === undefined) loaded.settings.bankName = 'State Bank of India, Kalamnuri Branch';
          if (loaded.settings.bankAccountNumber === undefined) loaded.settings.bankAccountNumber = '30489218491';
          if (loaded.settings.bankIfsc === undefined) loaded.settings.bankIfsc = 'SBIN0001234';
          if (loaded.settings.receiptStartNumber === undefined) loaded.settings.receiptStartNumber = 1001;
          if (loaded.settings.receiptFooterNote === undefined) loaded.settings.receiptFooterNote = 'ही संगणकीय पावती आहे. स्वाक्षरीची आवश्यकता नाही.';
          if (loaded.settings.receiptIssuedBy === undefined) loaded.settings.receiptIssuedBy = 'कार्यालय व्यवस्थापक / Admin Office';
          if (loaded.settings.receiptPresidentName === undefined) loaded.settings.receiptPresidentName = 'Santoshrao Mali';
          if (loaded.settings.enablePaymentReminders === undefined) loaded.settings.enablePaymentReminders = true;
          if (loaded.settings.reminderDaysBeforeDue === undefined) loaded.settings.reminderDaysBeforeDue = 3;
          if (loaded.settings.enablePaymentConfirmationSms === undefined) loaded.settings.enablePaymentConfirmationSms = true;
          if (loaded.settings.enableOverdueAlerts === undefined) loaded.settings.enableOverdueAlerts = true;
          if (loaded.settings.enableAdminPaymentAlerts === undefined) loaded.settings.enableAdminPaymentAlerts = true;
          modified = true;
        }
        if (!loaded.users.some((u) => u.role === 'staff')) {
          const staffSalt = crypto.randomBytes(16).toString('hex');
          const staffHash = crypto.scryptSync('staff123', staffSalt, 64).toString('hex');
          loaded.users.push({
            id: 'USR-STAFF-1',
            email: 'staff@ektasanstha.org',
            mobile: '9876500000',
            name: 'Kalamnuri Sanstha Staff (व्यवस्थापक)',
            role: 'staff',
            passwordHash: staffHash,
            salt: staffSalt,
            status: 'active',
            createdAt: '2026-01-01T00:00:00.000Z',
            updatedAt: '2026-01-01T00:00:00.000Z',
          });
          modified = true;
        }
        if (modified) {
          this.saveImmediate(loaded);
        }
        return loaded;
      } catch (err) {
        console.error('Failed to load database file, creating fresh backup and re-seeding:', err);
      }
    }

    const initial = this.seedDatabase();
    this.saveImmediate(initial);
    return initial;
  }

  public getInitialUpdates(): SansthaUpdate[] {
    return [
      {
        id: 'UPD-001',
        title: 'मासिक सर्वसाधारण बैठक (Monthly General Meeting)',
        content: 'ऑक्टोबर २०२६ महिन्याचे जमा-खर्च आढावा, चालू प्रकल्प आणि दिवाळी निमित्त समाजोपयोगी उपक्रमांवर चर्चा करण्यासाठी सर्व सभासदांची उपस्थिती आवश्यक आहे.',
        category: 'meeting',
        date: '2026-10-18',
        time: '18:00',
        venue: 'संस्था कार्यालय, माळी गल्ली, कळमनुरी',
        isImportant: true,
        isPublished: true,
        authorId: 'USR-ADMIN',
        authorName: 'Santosh Jadhav (Secretary)',
        attendanceSummary: {
          totalInvited: 6,
          presentCount: 5,
          absentCount: 1,
        },
        attendance: [
          { memberId: 'M001', memberName: 'Ramesh Balaji Patil', status: 'present' },
          { memberId: 'M002', memberName: 'Ganesh Shrikant Deshmukh', status: 'present' },
          { memberId: 'M003', memberName: 'Pravin Digambar Shinde', status: 'present' },
          { memberId: 'M004', memberName: 'Santosh Pandurang Jadhav', status: 'present' },
          { memberId: 'M005', memberName: 'Vijay Annasaheb Kulkarni', status: 'present' },
          { memberId: 'M006', memberName: 'Aniket Dnyaneshwar Mali', status: 'absent' },
        ],
        createdAt: '2026-10-01T10:00:00.000Z',
        updatedAt: '2026-10-01T10:00:00.000Z',
      },
      {
        id: 'UPD-002',
        title: 'यशस्वी सामाजिक उपक्रम: वृक्षारोपण व स्वच्छता मोहीम',
        content: 'संस्थेच्या सामाजिक उपक्रमांतर्गत माळी गल्ली व कळमनुरी मंदिर परिसरात ५० वृक्षांचे रोपण यशस्वीरित्या पूर्ण झाले. सहभागी सर्व सभासदांचे मनःपूर्वक आभार.',
        category: 'activity',
        date: '2026-09-20',
        venue: 'माळी गल्ली व परिसर, कळमनुरी',
        isImportant: false,
        isPublished: true,
        authorId: 'USR-ADMIN',
        authorName: 'Santosh Jadhav (Secretary)',
        createdAt: '2026-09-21T09:30:00.000Z',
        updatedAt: '2026-09-21T09:30:00.000Z',
      },
      {
        id: 'UPD-003',
        title: 'महत्त्वाची सूचना: मासिक वर्गणी व डिजिटल पावत्या',
        content: 'चालू महिन्याचे मासिक योगदान (₹1,000) प्रत्येक महिन्याच्या १० तारखेपूर्वी जमा करावे. भरणा केल्यावर आपली डिजिटल पावती तात्काळ या पोर्टलवरून डाऊनलोड करता येईल.',
        category: 'notice',
        date: '2026-10-01',
        isImportant: true,
        isPublished: true,
        authorId: 'USR-ADMIN',
        authorName: 'Santosh Jadhav (Secretary)',
        createdAt: '2026-10-01T08:00:00.000Z',
        updatedAt: '2026-10-01T08:00:00.000Z',
      },
    ];
  }

  public getInitialExpenses(): SansthaExpense[] {
    return [
      {
        id: 'EXP-001',
        title: 'वृक्षारोपण रोपे व खत खरेदी',
        category: 'welfare',
        amountPaise: 150000,
        expenseDate: '2026-09-20',
        receiptVoucherNo: 'VCH-2026-01',
        recordedByAdminId: 'USR-ADMIN',
        recordedByAdminName: 'Santosh Jadhav',
        isVerified: true,
        notes: 'स्थानिक रोपवाटिका पावती संलग्न',
        createdAt: '2026-09-20T16:00:00.000Z',
      },
      {
        id: 'EXP-002',
        title: 'संस्था कार्यालय नोंदवही व स्टेशनरी',
        category: 'office',
        amountPaise: 65000,
        expenseDate: '2026-09-28',
        receiptVoucherNo: 'VCH-2026-02',
        recordedByAdminId: 'USR-ADMIN',
        recordedByAdminName: 'Santosh Jadhav',
        isVerified: true,
        notes: 'पावती पुस्तक व रजिस्टर खरेदी',
        createdAt: '2026-09-28T14:30:00.000Z',
      },
      {
        id: 'EXP-003',
        title: 'मासिक सभा व्यवस्था व चहापान',
        category: 'event',
        amountPaise: 45000,
        expenseDate: '2026-10-05',
        receiptVoucherNo: 'VCH-2026-03',
        recordedByAdminId: 'USR-ADMIN',
        recordedByAdminName: 'Santosh Jadhav',
        isVerified: true,
        notes: 'बैठक व्यवस्था',
        createdAt: '2026-10-05T19:00:00.000Z',
      },
    ];
  }

  private saveImmediate(dataToSave: DatabaseSchema) {
    try {
      const tempFile = `${DB_FILE}.tmp.${Date.now()}`;
      fs.writeFileSync(tempFile, JSON.stringify(dataToSave, null, 2), 'utf-8');
      fs.renameSync(tempFile, DB_FILE);
    } catch (err) {
      console.error('Error saving database:', err);
    }
  }

  public save() {
    this.saveImmediate(this.data);
  }

  private seedDatabase(): DatabaseSchema {
    console.log('Seeding initial database for Ekta Seva Bhavi Sanstha...');

    const adminSalt = crypto.randomBytes(16).toString('hex');
    const adminHash = crypto.scryptSync('admin123', adminSalt, 64).toString('hex');

    const memberPassSalt = crypto.randomBytes(16).toString('hex');
    const memberPassHash = crypto.scryptSync('member123', memberPassSalt, 64).toString('hex');

    const adminUser: User = {
      id: 'USR-ADMIN-1',
      email: 'admin@ektasanstha.org',
      mobile: '9876543210',
      name: 'Santoshrao Mali (अध्यक्ष)',
      role: 'admin',
      passwordHash: adminHash,
      salt: adminSalt,
      status: 'active',
      createdAt: '2026-01-01T00:00:00.000Z',
      updatedAt: '2026-01-01T00:00:00.000Z',
    };

    const staffSalt = crypto.randomBytes(16).toString('hex');
    const staffHash = crypto.scryptSync('staff123', staffSalt, 64).toString('hex');

    const staffUser: User = {
      id: 'USR-STAFF-1',
      email: 'staff@ektasanstha.org',
      mobile: '9876500000',
      name: 'Kalamnuri Sanstha Staff (व्यवस्थापक)',
      role: 'staff',
      passwordHash: staffHash,
      salt: staffSalt,
      status: 'active',
      createdAt: '2026-01-01T00:00:00.000Z',
      updatedAt: '2026-01-01T00:00:00.000Z',
    };

    const initialMembers: Member[] = [
      {
        id: 'MEM-001',
        memberId: 'M001',
        fullName: 'Ramesh Balaji Patil',
        mobile: '9822110022',
        email: 'ramesh.patil@example.com',
        address: 'Mali Galli, Near Maruti Mandir, Kalamnuri',
        joiningDate: '2026-01-10',
        monthlyContributionPaise: 100000, // ₹1,000
        status: 'active',
        userId: 'USR-MEM-1',
        notes: 'Founder member, regular contributor',
        createdAt: '2026-01-10T10:00:00.000Z',
        updatedAt: '2026-01-10T10:00:00.000Z',
      },
      {
        id: 'MEM-002',
        memberId: 'M002',
        fullName: 'Ganesh Digambar Shinde',
        mobile: '9822334455',
        email: 'ganesh.shinde@example.com',
        address: 'Main Bazar Road, Kalamnuri',
        joiningDate: '2026-01-15',
        monthlyContributionPaise: 100000,
        status: 'active',
        userId: 'USR-MEM-2',
        notes: 'Prefers online UPI payments',
        createdAt: '2026-01-15T11:00:00.000Z',
        updatedAt: '2026-01-15T11:00:00.000Z',
      },
      {
        id: 'MEM-003',
        memberId: 'M003',
        fullName: 'Sunita Prabhakar Deshmukh',
        mobile: '9421556677',
        email: 'sunita.d@example.com',
        address: 'Mali Galli, Kalamnuri',
        joiningDate: '2026-02-01',
        monthlyContributionPaise: 100000,
        status: 'active',
        userId: 'USR-MEM-3',
        notes: 'Treasurer assistance',
        createdAt: '2026-02-01T09:30:00.000Z',
        updatedAt: '2026-02-01T09:30:00.000Z',
      },
      {
        id: 'MEM-004',
        memberId: 'M004',
        fullName: 'Santosh Pandurang Jadhav',
        mobile: '9923887766',
        email: 'santosh.jadhav@example.com',
        address: 'Old Post Office Lane, Kalamnuri',
        joiningDate: '2026-03-05',
        monthlyContributionPaise: 100000,
        status: 'active',
        userId: 'USR-MEM-4',
        notes: 'Cash payment on 5th of each month',
        createdAt: '2026-03-05T14:20:00.000Z',
        updatedAt: '2026-03-05T14:20:00.000Z',
      },
      {
        id: 'MEM-005',
        memberId: 'M005',
        fullName: 'Vijay Annasaheb Kulkarni',
        mobile: '9860443322',
        email: 'vijay.k@example.com',
        address: 'Mali Galli, Kalamnuri',
        joiningDate: '2026-04-12',
        monthlyContributionPaise: 100000,
        status: 'active',
        userId: 'USR-MEM-5',
        notes: 'Active social worker',
        createdAt: '2026-04-12T16:00:00.000Z',
        updatedAt: '2026-04-12T16:00:00.000Z',
      },
      {
        id: 'MEM-006',
        memberId: 'M006',
        fullName: 'Aniket Dnyaneshwar Mali',
        mobile: '9763221199',
        email: 'aniket.mali@example.com',
        address: 'Mali Galli, Kalamnuri',
        joiningDate: '2026-05-01',
        monthlyContributionPaise: 100000,
        status: 'active',
        userId: 'USR-MEM-6',
        notes: 'Youth coordinator',
        createdAt: '2026-05-01T10:15:00.000Z',
        updatedAt: '2026-05-01T10:15:00.000Z',
      },
      {
        id: 'MEM-007',
        memberId: 'M007',
        fullName: 'Mahesh Tulshiram Shinde',
        mobile: '9881665544',
        email: 'mahesh.shinde@example.com',
        address: 'Mali Galli, Kalamnuri',
        joiningDate: '2026-09-20',
        monthlyContributionPaise: 100000,
        status: 'pending_approval',
        notes: 'Submitted online registration form',
        createdAt: '2026-09-20T12:00:00.000Z',
        updatedAt: '2026-09-20T12:00:00.000Z',
      },
    ];

    const memberUsers: User[] = initialMembers.slice(0, 6).map((m, idx) => ({
      id: `USR-MEM-${idx + 1}`,
      email: m.email || `member${m.memberId}@ektasanstha.org`,
      mobile: m.mobile,
      name: m.fullName,
      role: 'member',
      passwordHash: memberPassHash,
      salt: memberPassSalt,
      memberId: m.memberId,
      status: 'active',
      createdAt: m.createdAt,
      updatedAt: m.updatedAt,
    }));

    // Seed historical monthly dues for Aug 2026, Sep 2026, Oct 2026
    const months = [
      { key: '2026-08', label: 'August 2026', due: '2026-08-10' },
      { key: '2026-09', label: 'September 2026', due: '2026-09-10' },
      { key: '2026-10', label: 'October 2026', due: '2026-10-10' },
    ];

    const dues: MonthlyDue[] = [];
    const payments: Payment[] = [];
    const receipts: Receipt[] = [];

    let rcpSeq = 1;
    let paySeq = 1;

    for (const m of initialMembers.slice(0, 6)) {
      for (const mo of months) {
        const dueId = `DUE-${m.memberId}-${mo.key}`;
        // Aug & Sep are paid; Oct has some paid, some unpaid
        let isPaid = true;
        let method: 'cash' | 'online_upi' = m.memberId === 'M002' || m.memberId === 'M006' ? 'online_upi' : 'cash';

        if (mo.key === '2026-10') {
          // Ramesh M001 & Ganesh M002 paid for October, others still pending
          isPaid = m.memberId === 'M001' || m.memberId === 'M002';
        }

        const amountDue = m.monthlyContributionPaise;
        const amountPaid = isPaid ? amountDue : 0;
        const remaining = amountDue - amountPaid;
        const status = isPaid ? 'paid' : (mo.key === '2026-10' ? 'unpaid' : 'overdue');

        dues.push({
          id: dueId,
          memberId: m.memberId,
          monthYear: mo.key,
          monthLabel: mo.label,
          amountDuePaise: amountDue,
          amountPaidPaise: amountPaid,
          remainingPaise: remaining,
          dueDate: mo.due,
          status,
          lastPaymentDate: isPaid ? `${mo.key}-05T11:00:00.000Z` : null,
          createdAt: `${mo.key}-01T00:00:00.000Z`,
          updatedAt: `${mo.key}-05T11:00:00.000Z`,
        });

        if (isPaid) {
          const rcpNum = `ESBS-2026-${String(rcpSeq++).padStart(4, '0')}`;
          const payId = `PAY-2026-${String(paySeq++).padStart(4, '0')}`;
          const payDate = `${mo.key}-05T11:00:00.000Z`;

          const p: Payment = {
            id: payId,
            receiptNumber: rcpNum,
            memberId: m.memberId,
            memberName: m.fullName,
            dueId,
            monthYear: mo.key,
            amountPaise: amountDue,
            paymentMethod: method,
            paymentDate: payDate,
            status: 'verified',
            receivedByAdminName: 'Santoshrao Mali',
            notes: method === 'online_upi' ? 'Online verified UPI transfer' : 'Monthly contribution received in cash',
            gatewayOrderId: method === 'online_upi' ? `order_test_${paySeq}` : null,
            gatewayPaymentId: method === 'online_upi' ? `pay_test_${paySeq}` : null,
            gatewaySignature: method === 'online_upi' ? `sig_test_${paySeq}` : null,
            createdAt: payDate,
          };
          payments.push(p);

          receipts.push({
            id: `RCP-${payId}`,
            receiptNumber: rcpNum,
            paymentId: payId,
            memberId: m.memberId,
            memberName: m.fullName,
            memberMobile: m.mobile,
            monthYear: mo.key,
            monthLabel: mo.label,
            amountPaise: amountDue,
            amountInWords: inrToWords(amountDue, 'en'),
            paymentMethod: method,
            paymentDate: payDate,
            transactionRef: method === 'online_upi' ? `UPI/${m.mobile}/2026` : 'CASH-VOUCHER',
            remainingBalancePaise: 0,
            issuedBy: 'Santoshrao Mali (अध्यक्ष)',
            status: 'verified',
            organizationName: 'Ekta Seva Bhavi Sanstha',
            organizationAddress: 'Mali Galli, Kalamnuri, Maharashtra, India',
            createdAt: payDate,
          });
        }
      }
    }

    const notifications: AppNotification[] = [
      {
        id: 'NOTIF-1',
        targetUserId: null,
        type: 'announcement',
        title: 'मासिक बैठक आणि हप्ता जमा सूचना',
        message: 'संस्थेची मासिक सभा दर महिन्याच्या ५ तारखेस माळी गल्ली, कळमनुरी येथे आयोजित केली जाते. सर्व सदस्यांनी वेळेवर उपस्थित राहावे.',
        isRead: false,
        createdAt: '2026-10-01T08:00:00.000Z',
      },
      {
        id: 'NOTIF-2',
        targetUserId: 'USR-MEM-1',
        memberId: 'M001',
        type: 'payment_cash',
        title: 'ऑक्टोबर २०२६ चा हप्ता जमा झाला',
        message: 'आपला ऑक्टोबर २०२६ महिन्याचा ₹१,००० चा हप्ता रोख स्वरूपात जमा झाला असून पावती ESBS-2026-0005 तयार झाली आहे.',
        isRead: true,
        createdAt: '2026-10-05T11:05:00.000Z',
      },
      {
        id: 'NOTIF-3',
        targetUserId: 'USR-MEM-2',
        memberId: 'M002',
        type: 'payment_online',
        title: 'ऑनलाइन UPI पेमेंट पडताळणी यशस्वी',
        message: 'आपला ऑक्टोबर २०२६ महिन्याचा ₹१,००० चा हप्ता ऑनलाइन UPI द्वारे प्राप्त व पडताळला गेला आहे. धन्यवाद!',
        isRead: true,
        createdAt: '2026-10-05T11:30:00.000Z',
      },
      {
        id: 'NOTIF-4',
        targetUserId: null,
        memberId: 'M007',
        type: 'member_registered',
        title: 'नवीन सदस्य नोंदणी अर्ज',
        message: 'महेश तुळशीराम शिंदे (M007) यांनी नवीन सदस्यत्वासाठी अर्ज केला आहे. प्रशासक मंजुरी प्रलंबित आहे.',
        isRead: false,
        createdAt: '2026-09-20T12:05:00.000Z',
      },
    ];

    const auditLogs: AuditLog[] = [
      {
        id: 'AUD-001',
        actorId: 'USR-ADMIN-1',
        actorName: 'Santoshrao Mali',
        action: 'SYSTEM_BOOTSTRAP',
        details: 'Ekta Seva Bhavi Sanstha portal initialized with default settings and ledger.',
        timestamp: '2026-01-01T00:00:00.000Z',
      },
      {
        id: 'AUD-002',
        actorId: 'USR-ADMIN-1',
        actorName: 'Santoshrao Mali',
        action: 'GENERATE_MONTHLY_DUES',
        details: 'Generated monthly dues for billing cycle October 2026 (₹1,000 per member).',
        timestamp: '2026-10-01T00:00:00.000Z',
      },
    ];

    const settings: OrganizationSettings = {
      orgName: 'Ekta Seva Bhavi Sanstha',
      marathiName: 'एकता सेवाभावी संस्था',
      hindiName: 'एकता सेवा भावी संस्था',
      address: 'Mali Galli, Kalamnuri, Maharashtra, India',
      registrationNumber: 'MAH/KLM/1048/2022',
      contactPhone: '+91 98765 43210',
      contactEmail: 'info@ektasanstha.org',
      standardContributionPaise: 100000,
      dueDayOfMonth: 10,
      upiId: 'ektasanstha@upi',
      razorpayKeyId: 'rzp_test_ekta_kalamnuri',
      razorpayKeySecret: 'secret_ekta_kalamnuri_sandbox_2026',
      razorpayWebhookSecret: 'whsec_ekta_kalamnuri_verified',
      isSandbox: true,
      receiptPrefix: 'ESBS',
      defaultLanguage: 'hi',
    };

    return {
      version: 1,
      settings,
      users: [adminUser, staffUser, ...memberUsers],
      members: initialMembers,
      dues,
      payments,
      receipts,
      notifications,
      auditLogs,
      processedWebhookEventIds: [],
      updates: this.getInitialUpdates(),
      expenses: this.getInitialExpenses(),
    };
  }

  // Settings
  public getSettings(): OrganizationSettings {
    return this.data.settings;
  }

  public updateSettings(partial: Partial<OrganizationSettings>, actorId: string, actorName: string): OrganizationSettings {
    this.data.settings = { ...this.data.settings, ...partial };
    this.addAuditLog(actorId, actorName, 'UPDATE_SETTINGS', `Updated organization settings: ${Object.keys(partial).join(', ')}`);
    this.save();
    return this.data.settings;
  }

  // Users & Auth
  public findUserById(id: string): User | undefined {
    return this.data.users.find((u) => u.id === id);
  }

  public findUserByLogin(login: string): User | undefined {
    const clean = login.trim().toLowerCase();
    return this.data.users.find(
      (u) =>
        u.email.toLowerCase() === clean ||
        u.mobile === clean ||
        (u.memberId && u.memberId.toLowerCase() === clean)
    );
  }

  public createUser(user: User): User {
    this.data.users.push(user);
    this.save();
    return user;
  }

  public getStaffUsers(): Omit<User, 'passwordHash' | 'salt'>[] {
    return this.data.users
      .filter((u) => u.role === 'staff' || u.role === 'admin')
      .map(({ passwordHash, salt, ...safeUser }) => safeUser);
  }

  public createStaffUser(
    params: { email: string; mobile: string; name: string; password?: string; permissions?: StaffPermissions },
    actorId: string,
    actorName: string
  ): Omit<User, 'passwordHash' | 'salt'> {
    const cleanEmail = params.email.trim().toLowerCase();
    const cleanMobile = params.mobile.trim();
    if (this.data.users.some((u) => u.email.toLowerCase() === cleanEmail || u.mobile === cleanMobile)) {
      throw new Error('या ईमेल किंवा मोबाईल क्रमांकाने वापरकर्ता आधीच अस्तित्वात आहे');
    }
    const { hash, salt } = hashPassword(params.password || 'staff123');
    const now = new Date().toISOString();
    const newUser: User = {
      id: `USR-STAFF-${Date.now()}`,
      email: cleanEmail,
      mobile: cleanMobile,
      name: params.name.trim(),
      role: 'staff',
      passwordHash: hash,
      salt,
      status: 'active',
      permissions: params.permissions || {
        canManageMembers: true,
        canCollectPayments: true,
        canViewReports: true,
        canSendNotifications: true,
        canGenerateDues: true,
      },
      createdAt: now,
      updatedAt: now,
    };
    this.data.users.push(newUser);
    this.addAuditLog(actorId, actorName, 'CREATE_STAFF_USER', `Created staff user ${newUser.name} (${newUser.email})`);
    this.save();
    const { passwordHash: _, salt: __, ...safe } = newUser;
    return safe;
  }

  public updateStaffUser(
    id: string,
    updates: { name?: string; mobile?: string; email?: string; status?: 'active' | 'suspended'; permissions?: StaffPermissions },
    actorId: string,
    actorName: string
  ): Omit<User, 'passwordHash' | 'salt'> | null {
    const user = this.findUserById(id);
    if (!user) return null;
    if (updates.name) user.name = updates.name.trim();
    if (updates.mobile) user.mobile = updates.mobile.trim();
    if (updates.email) user.email = updates.email.trim().toLowerCase();
    if (updates.status) user.status = updates.status;
    if (updates.permissions) user.permissions = { ...(user.permissions || {}), ...updates.permissions };
    user.updatedAt = new Date().toISOString();
    this.addAuditLog(actorId, actorName, 'UPDATE_STAFF_USER', `Updated staff user ${user.name} (${user.id})`);
    this.save();
    const { passwordHash: _, salt: __, ...safe } = user;
    return safe;
  }

  public resetStaffPassword(id: string, newPass: string, actorId: string, actorName: string): boolean {
    const user = this.findUserById(id);
    if (!user) return false;
    const { hash, salt } = hashPassword(newPass);
    user.passwordHash = hash;
    user.salt = salt;
    user.updatedAt = new Date().toISOString();
    this.addAuditLog(actorId, actorName, 'RESET_STAFF_PASSWORD', `Reset password for staff user ${user.name} (${user.id})`);
    this.save();
    return true;
  }

  public getDatabaseBackup(): any {
    return {
      exportedAt: new Date().toISOString(),
      version: this.data.version,
      settings: this.getSettings(),
      membersCount: this.data.members.length,
      members: this.data.members,
      duesCount: this.data.dues.length,
      dues: this.data.dues,
      paymentsCount: this.data.payments.length,
      payments: this.data.payments,
      receiptsCount: this.data.receipts.length,
      receipts: this.data.receipts,
      updatesCount: this.data.updates.length,
      updates: this.data.updates,
      expensesCount: this.data.expenses.length,
      expenses: this.data.expenses,
      auditLogsCount: this.data.auditLogs.length,
      auditLogs: this.data.auditLogs,
      usersCount: this.data.users.length,
      users: this.data.users.map(({ passwordHash: _, salt: __, ...u }) => u),
    };
  }

  public updateUserPassword(userId: string, newPassword: string): boolean {
    const user = this.findUserById(userId);
    if (!user) return false;
    const { hash, salt } = hashPassword(newPassword);
    user.passwordHash = hash;
    user.salt = salt;
    user.updatedAt = new Date().toISOString();
    this.save();
    return true;
  }

  // Members
  public getMembers(): Member[] {
    return this.data.members;
  }

  public findMemberByMemberId(memberId: string): Member | undefined {
    return this.data.members.find((m) => m.memberId.toUpperCase() === memberId.toUpperCase());
  }

  public findMemberById(id: string): Member | undefined {
    return this.data.members.find((m) => m.id === id);
  }

  public createMember(
    params: Omit<Member, 'id' | 'memberId' | 'createdAt' | 'updatedAt'>,
    actorId: string,
    actorName: string
  ): Member {
    const newMemberId = getNextMemberId(this.data.members);
    const now = new Date().toISOString();
    const newMember: Member = {
      ...params,
      id: `MEM-${Date.now()}`,
      memberId: newMemberId,
      monthlyContributionPaise: params.monthlyContributionPaise || this.data.settings.standardContributionPaise,
      createdAt: now,
      updatedAt: now,
    };
    this.data.members.push(newMember);

    // If active, also create a User login for this member with default password 'member123'
    if (newMember.status === 'active') {
      const { hash, salt } = hashPassword('member123');
      const newUser: User = {
        id: `USR-${newMember.memberId}`,
        email: newMember.email || `${newMember.memberId.toLowerCase()}@ektasanstha.org`,
        mobile: newMember.mobile,
        name: newMember.fullName,
        role: 'member',
        passwordHash: hash,
        salt,
        memberId: newMember.memberId,
        status: 'active',
        createdAt: now,
        updatedAt: now,
      };
      this.data.users.push(newUser);
      newMember.userId = newUser.id;
    }

    this.addAuditLog(actorId, actorName, 'CREATE_MEMBER', `Created member ${newMember.memberId} (${newMember.fullName})`);
    this.save();
    return newMember;
  }

  public updateMember(id: string, updates: Partial<Member>, actorId: string, actorName: string): Member | null {
    const idx = this.data.members.findIndex((m) => m.id === id || m.memberId === id);
    if (idx === -1) return null;
    const existing = this.data.members[idx];
    this.data.members[idx] = {
      ...existing,
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    this.addAuditLog(actorId, actorName, 'UPDATE_MEMBER', `Updated member details for ${existing.memberId}`);
    this.save();
    return this.data.members[idx];
  }

  public setMemberStatus(memberId: string, status: Member['status'], actorId: string, actorName: string): Member | null {
    const member = this.findMemberByMemberId(memberId);
    if (!member) return null;
    const oldStatus = member.status;
    member.status = status;
    member.updatedAt = new Date().toISOString();

    // If approving a pending member, make sure user account exists
    if (status === 'active' && !member.userId) {
      const { hash, salt } = hashPassword('member123');
      const now = new Date().toISOString();
      const newUser: User = {
        id: `USR-${member.memberId}`,
        email: member.email || `${member.memberId.toLowerCase()}@ektasanstha.org`,
        mobile: member.mobile,
        name: member.fullName,
        role: 'member',
        passwordHash: hash,
        salt,
        memberId: member.memberId,
        status: 'active',
        createdAt: now,
        updatedAt: now,
      };
      this.data.users.push(newUser);
      member.userId = newUser.id;

      this.addNotification({
        targetUserId: newUser.id,
        memberId: member.memberId,
        type: 'member_approved',
        title: 'सदस्यत्व मंजूर झाले (Membership Approved)',
        message: `अभिनंदन! आपले सदस्यत्व मंजूर करण्यात आले आहे. आपला सदस्य आयडी ${member.memberId} आहे. सुरुवातीचा पासवर्ड 'member123' आहे.`,
      });
    }

    this.addAuditLog(actorId, actorName, 'MEMBER_STATUS_CHANGE', `Member ${member.memberId} status changed from ${oldStatus} to ${status}`);
    this.save();
    return member;
  }

  // Monthly Dues
  public getDues(filter?: { memberId?: string; monthYear?: string; status?: string }): MonthlyDue[] {
    let result = [...this.data.dues];
    if (filter?.memberId) {
      result = result.filter((d) => d.memberId.toUpperCase() === filter.memberId?.toUpperCase());
    }
    if (filter?.monthYear) {
      result = result.filter((d) => d.monthYear === filter.monthYear);
    }
    if (filter?.status) {
      result = result.filter((d) => d.status === filter.status);
    }
    return result.sort((a, b) => b.monthYear.localeCompare(a.monthYear));
  }

  public generateMonthlyDues(monthYear: string, actorId: string, actorName: string): { generatedCount: number; alreadyExistingCount: number } {
    // monthYear is YYYY-MM e.g. "2026-11"
    const [yearStr, monthStr] = monthYear.split('-');
    const year = parseInt(yearStr, 10);
    const monthIndex = parseInt(monthStr, 10) - 1;
    const dateObj = new Date(year, monthIndex, 1);
    const monthLabel = dateObj.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
    const dueDay = this.data.settings.dueDayOfMonth || 10;
    const dueDate = `${monthYear}-${String(dueDay).padStart(2, '0')}`;

    let generatedCount = 0;
    let alreadyExistingCount = 0;

    const activeMembers = this.data.members.filter((m) => m.status === 'active');
    const now = new Date().toISOString();

    for (const m of activeMembers) {
      const existing = this.data.dues.find((d) => d.memberId === m.memberId && d.monthYear === monthYear);
      if (existing) {
        alreadyExistingCount++;
        continue;
      }

      const duePaise = m.monthlyContributionPaise || this.data.settings.standardContributionPaise;
      const newDue: MonthlyDue = {
        id: `DUE-${m.memberId}-${monthYear}`,
        memberId: m.memberId,
        monthYear,
        monthLabel,
        amountDuePaise: duePaise,
        amountPaidPaise: 0,
        remainingPaise: duePaise,
        dueDate,
        status: 'unpaid',
        lastPaymentDate: null,
        createdAt: now,
        updatedAt: now,
      };

      this.data.dues.push(newDue);
      generatedCount++;

      // Create reminder notification for member
      this.addNotification({
        targetUserId: m.userId || null,
        memberId: m.memberId,
        type: 'due_reminder',
        title: `${monthLabel} महिन्याचा हप्ता`,
        message: `${m.fullName}, आपल्या चालू महिन्याचा ₹${(duePaise / 100).toLocaleString('en-IN')} चा हप्ता ${dueDate} पूर्वी जमा करा.`,
      });
    }

    this.addAuditLog(actorId, actorName, 'GENERATE_MONTHLY_DUES', `Generated ${generatedCount} dues for ${monthYear} (${alreadyExistingCount} already existed).`);
    this.save();
    return { generatedCount, alreadyExistingCount };
  }

  // Payments & Receipts (ACID Transaction Logic)
  public recordCashPayment(params: {
    memberId: string;
    monthYear: string;
    amountPaise: number;
    paymentDate: string;
    receivedByAdminName: string;
    notes?: string;
    actorId: string;
    actorName: string;
  }): { payment: Payment; receipt: Receipt } {
    const member = this.findMemberByMemberId(params.memberId);
    if (!member) throw new Error(`Member ${params.memberId} not found`);

    if (params.amountPaise <= 0) {
      throw new Error('Payment amount must be greater than zero');
    }

    // Find or create monthly due
    let due = this.data.dues.find((d) => d.memberId === member.memberId && d.monthYear === params.monthYear);
    const now = new Date().toISOString();

    if (!due) {
      const [yearStr, monthStr] = params.monthYear.split('-');
      const dateObj = new Date(parseInt(yearStr, 10), parseInt(monthStr, 10) - 1, 1);
      const monthLabel = dateObj.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
      const dueDay = this.data.settings.dueDayOfMonth || 10;
      const dueDate = `${params.monthYear}-${String(dueDay).padStart(2, '0')}`;

      due = {
        id: `DUE-${member.memberId}-${params.monthYear}`,
        memberId: member.memberId,
        monthYear: params.monthYear,
        monthLabel,
        amountDuePaise: member.monthlyContributionPaise || this.data.settings.standardContributionPaise,
        amountPaidPaise: 0,
        remainingPaise: member.monthlyContributionPaise || this.data.settings.standardContributionPaise,
        dueDate,
        status: 'unpaid',
        createdAt: now,
        updatedAt: now,
      };
      this.data.dues.push(due);
    }

    // Update dues ledger with integer paise math
    const newPaidPaise = due.amountPaidPaise + params.amountPaise;
    const remainingPaise = Math.max(0, due.amountDuePaise - newPaidPaise);
    due.amountPaidPaise = newPaidPaise;
    due.remainingPaise = remainingPaise;
    due.lastPaymentDate = params.paymentDate || now;
    due.status = remainingPaise === 0 ? 'paid' : 'partially_paid';
    due.updatedAt = now;

    // Generate unique receipt number
    const receiptNumber = getNextReceiptNumber(this.data.receipts, this.data.settings.receiptPrefix || 'ESBS');
    const paymentId = `PAY-${Date.now()}`;

    const payment: Payment = {
      id: paymentId,
      receiptNumber,
      memberId: member.memberId,
      memberName: member.fullName,
      dueId: due.id,
      monthYear: params.monthYear,
      amountPaise: params.amountPaise,
      paymentMethod: 'cash',
      paymentDate: params.paymentDate || now,
      status: 'verified',
      receivedByAdminName: params.receivedByAdminName || params.actorName,
      notes: params.notes || 'Cash payment received at Sanstha office',
      createdAt: now,
    };
    this.data.payments.push(payment);

    const receipt: Receipt = {
      id: `RCP-${paymentId}`,
      receiptNumber,
      paymentId,
      memberId: member.memberId,
      memberName: member.fullName,
      memberMobile: member.mobile,
      monthYear: params.monthYear,
      monthLabel: due.monthLabel,
      amountPaise: params.amountPaise,
      amountInWords: inrToWords(params.amountPaise, 'en'),
      paymentMethod: 'cash',
      paymentDate: params.paymentDate || now,
      transactionRef: 'CASH-LEDGER-ENTRY',
      remainingBalancePaise: remainingPaise,
      issuedBy: `${params.receivedByAdminName || params.actorName} (Ekta Seva Bhavi Sanstha)`,
      status: 'verified',
      organizationName: this.data.settings.orgName,
      organizationAddress: this.data.settings.address,
      createdAt: now,
    };
    this.data.receipts.push(receipt);

    // Add notification for the member
    this.addNotification({
      targetUserId: member.userId || null,
      memberId: member.memberId,
      type: 'payment_cash',
      title: `रोख पावती जमा: ${due.monthLabel}`,
      message: `आपला ${due.monthLabel} महिन्याचा ₹${(params.amountPaise / 100).toLocaleString('en-IN')} चा हप्ता रोखीने जमा झाला. पावती क्र: ${receiptNumber}.`,
    });

    this.addAuditLog(
      params.actorId,
      params.actorName,
      'RECORD_CASH_PAYMENT',
      `Recorded cash deposit of ₹${params.amountPaise / 100} for member ${member.memberId} (${due.monthLabel}). Receipt: ${receiptNumber}`
    );

    this.save();
    return { payment, receipt };
  }

  // Online Payment Verification
  public verifyAndCreditOnlinePayment(params: {
    memberId: string;
    monthYear: string;
    amountPaise: number;
    gatewayOrderId: string;
    gatewayPaymentId: string;
    gatewaySignature: string;
    verifiedByServer: boolean;
  }): { payment: Payment; receipt: Receipt } {
    if (!params.verifiedByServer) {
      throw new Error('Payment signature verification failed. Cannot credit unverified transaction.');
    }

    const member = this.findMemberByMemberId(params.memberId);
    if (!member) throw new Error(`Member ${params.memberId} not found`);

    // Check for duplicate payment transaction ID
    const duplicate = this.data.payments.find(
      (p) => p.gatewayPaymentId && p.gatewayPaymentId === params.gatewayPaymentId && p.status === 'verified'
    );
    if (duplicate) {
      const existingReceipt = this.data.receipts.find((r) => r.paymentId === duplicate.id);
      if (existingReceipt) {
        return { payment: duplicate, receipt: existingReceipt };
      }
    }

    let due = this.data.dues.find((d) => d.memberId === member.memberId && d.monthYear === params.monthYear);
    const now = new Date().toISOString();

    if (!due) {
      const [yearStr, monthStr] = params.monthYear.split('-');
      const dateObj = new Date(parseInt(yearStr, 10), parseInt(monthStr, 10) - 1, 1);
      const monthLabel = dateObj.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
      const dueDay = this.data.settings.dueDayOfMonth || 10;
      const dueDate = `${params.monthYear}-${String(dueDay).padStart(2, '0')}`;

      due = {
        id: `DUE-${member.memberId}-${params.monthYear}`,
        memberId: member.memberId,
        monthYear: params.monthYear,
        monthLabel,
        amountDuePaise: member.monthlyContributionPaise || this.data.settings.standardContributionPaise,
        amountPaidPaise: 0,
        remainingPaise: member.monthlyContributionPaise || this.data.settings.standardContributionPaise,
        dueDate,
        status: 'unpaid',
        createdAt: now,
        updatedAt: now,
      };
      this.data.dues.push(due);
    }

    const newPaidPaise = due.amountPaidPaise + params.amountPaise;
    const remainingPaise = Math.max(0, due.amountDuePaise - newPaidPaise);
    due.amountPaidPaise = newPaidPaise;
    due.remainingPaise = remainingPaise;
    due.lastPaymentDate = now;
    due.status = remainingPaise === 0 ? 'paid' : 'partially_paid';
    due.updatedAt = now;

    const receiptNumber = getNextReceiptNumber(this.data.receipts, this.data.settings.receiptPrefix || 'ESBS');
    const paymentId = `PAY-${Date.now()}`;

    const payment: Payment = {
      id: paymentId,
      receiptNumber,
      memberId: member.memberId,
      memberName: member.fullName,
      dueId: due.id,
      monthYear: params.monthYear,
      amountPaise: params.amountPaise,
      paymentMethod: 'online_upi',
      paymentDate: now,
      status: 'verified',
      receivedByAdminName: 'Razorpay PG / UPI Auto-Verification',
      notes: `Verified online transaction (Ref: ${params.gatewayPaymentId})`,
      gatewayOrderId: params.gatewayOrderId,
      gatewayPaymentId: params.gatewayPaymentId,
      gatewaySignature: params.gatewaySignature,
      createdAt: now,
    };
    this.data.payments.push(payment);

    const receipt: Receipt = {
      id: `RCP-${paymentId}`,
      receiptNumber,
      paymentId,
      memberId: member.memberId,
      memberName: member.fullName,
      memberMobile: member.mobile,
      monthYear: params.monthYear,
      monthLabel: due.monthLabel,
      amountPaise: params.amountPaise,
      amountInWords: inrToWords(params.amountPaise, 'en'),
      paymentMethod: 'online_upi',
      paymentDate: now,
      transactionRef: params.gatewayPaymentId,
      remainingBalancePaise: remainingPaise,
      issuedBy: 'Digital Gateway (Ekta Seva Bhavi Sanstha)',
      status: 'verified',
      organizationName: this.data.settings.orgName,
      organizationAddress: this.data.settings.address,
      createdAt: now,
    };
    this.data.receipts.push(receipt);

    this.addNotification({
      targetUserId: member.userId || null,
      memberId: member.memberId,
      type: 'payment_online',
      title: 'ऑनलाइन UPI पेमेंट यशस्वी',
      message: `आपला ${due.monthLabel} चा ₹${(params.amountPaise / 100).toLocaleString('en-IN')} चा हप्ता यशस्वीरित्या पडताळला गेला आहे. पावती क्र: ${receiptNumber}.`,
    });

    this.addAuditLog(
      'GATEWAY',
      'System',
      'VERIFY_ONLINE_PAYMENT',
      `Verified online payment of ₹${params.amountPaise / 100} for member ${member.memberId}. Payment ID: ${params.gatewayPaymentId}, Receipt: ${receiptNumber}`
    );

    this.save();
    return { payment, receipt };
  }

  // Payment Reversal / Refund (Preserves audit trail, never deletes financial history)
  public reversePayment(paymentId: string, reason: string, actorId: string, actorName: string): Payment {
    const payment = this.data.payments.find((p) => p.id === paymentId);
    if (!payment) throw new Error('Payment not found');
    if (payment.status === 'reversed') throw new Error('Payment has already been reversed');

    payment.status = 'reversed';
    payment.reversedAt = new Date().toISOString();
    payment.reversalReason = reason;

    // Reverse the due balance
    if (payment.dueId) {
      const due = this.data.dues.find((d) => d.id === payment.dueId);
      if (due) {
        due.amountPaidPaise = Math.max(0, due.amountPaidPaise - payment.amountPaise);
        due.remainingPaise = due.amountDuePaise - due.amountPaidPaise;
        due.status = due.remainingPaise <= 0 ? 'paid' : (due.amountPaidPaise > 0 ? 'partially_paid' : 'unpaid');
        due.updatedAt = new Date().toISOString();
      }
    }

    // Update receipt status
    const receipt = this.data.receipts.find((r) => r.paymentId === paymentId);
    if (receipt) {
      receipt.status = 'reversed';
    }

    this.addNotification({
      targetUserId: null,
      memberId: payment.memberId,
      type: 'reversal',
      title: 'व्यवहार उलटवला / दुरुस्त केला (Payment Reversal)',
      message: `पावती क्र. ${payment.receiptNumber} चा ₹${(payment.amountPaise / 100).toLocaleString('en-IN')} चा व्यवहार प्रशासकाद्वारे दुरुस्त / उलटवला गेला आहे. कारण: ${reason}`,
    });

    this.addAuditLog(
      actorId,
      actorName,
      'REVERSE_PAYMENT',
      `Reversed payment ${payment.id} (Receipt: ${payment.receiptNumber}, Amount: ₹${payment.amountPaise / 100}). Reason: ${reason}`
    );

    this.save();
    return payment;
  }

  // Receipts
  public getReceipts(filter?: { memberId?: string }): Receipt[] {
    let result = [...this.data.receipts];
    if (filter?.memberId) {
      result = result.filter((r) => r.memberId.toUpperCase() === filter.memberId?.toUpperCase());
    }
    return result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  public getReceiptById(idOrNumber: string): Receipt | undefined {
    return this.data.receipts.find((r) => r.id === idOrNumber || r.receiptNumber === idOrNumber);
  }

  public getPayments(filter?: { memberId?: string }): Payment[] {
    let result = [...this.data.payments];
    if (filter?.memberId) {
      result = result.filter((p) => p.memberId.toUpperCase() === filter.memberId?.toUpperCase());
    }
    return result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  // Notifications
  public getNotifications(userId?: string, memberId?: string): AppNotification[] {
    return this.data.notifications
      .filter((n) => {
        if (!n.targetUserId && !n.memberId) return true; // broadcast
        if (userId && n.targetUserId === userId) return true;
        if (memberId && n.memberId === memberId) return true;
        return false;
      })
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  public addNotification(n: Omit<AppNotification, 'id' | 'createdAt' | 'isRead'>): AppNotification {
    const notif: AppNotification = {
      ...n,
      id: `NOTIF-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      isRead: false,
      createdAt: new Date().toISOString(),
    };
    this.data.notifications.push(notif);
    this.save();
    return notif;
  }

  public markNotificationAsRead(id: string): boolean {
    const notif = this.data.notifications.find((n) => n.id === id);
    if (notif) {
      notif.isRead = true;
      this.save();
      return true;
    }
    return false;
  }

  public markAllNotificationsAsRead(userId?: string, memberId?: string): void {
    for (const n of this.data.notifications) {
      if (!n.targetUserId || (userId && n.targetUserId === userId) || (memberId && n.memberId === memberId)) {
        n.isRead = true;
      }
    }
    this.save();
  }

  // Audit Logs
  public addAuditLog(actorId: string, actorName: string, action: string, details: string, ip?: string): void {
    const log: AuditLog = {
      id: `AUD-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      actorId,
      actorName,
      action,
      details,
      ipAddress: ip || '127.0.0.1',
      timestamp: new Date().toISOString(),
    };
    this.data.auditLogs.unshift(log);
    // keep latest 500 logs
    if (this.data.auditLogs.length > 500) {
      this.data.auditLogs = this.data.auditLogs.slice(0, 500);
    }
    this.save();
  }

  public getAuditLogs(): AuditLog[] {
    return this.data.auditLogs;
  }

  // Webhooks
  public isWebhookProcessed(eventId: string): boolean {
    return this.data.processedWebhookEventIds.includes(eventId);
  }

  public markWebhookProcessed(eventId: string): void {
    this.data.processedWebhookEventIds.push(eventId);
    if (this.data.processedWebhookEventIds.length > 1000) {
      this.data.processedWebhookEventIds = this.data.processedWebhookEventIds.slice(-1000);
    }
    this.save();
  }

  // Dashboard & Reports Statistics (Calculated strictly from database, never mock)
  public getDashboardStats(): DashboardStats {
    const totalMembers = this.data.members.length;
    const activeMembers = this.data.members.filter((m) => m.status === 'active').length;
    const pendingApprovals = this.data.members.filter((m) => m.status === 'pending_approval').length;

    // Verified payments only (exclude reversed, pending, failed)
    const verifiedPayments = this.data.payments.filter((p) => p.status === 'verified');
    const totalVerifiedCollectionPaise = verifiedPayments.reduce((sum, p) => sum + p.amountPaise, 0);
    const cashCollectionPaise = verifiedPayments
      .filter((p) => p.paymentMethod === 'cash')
      .reduce((sum, p) => sum + p.amountPaise, 0);
    const onlineCollectionPaise = verifiedPayments
      .filter((p) => p.paymentMethod === 'online_upi' || p.paymentMethod === 'bank_transfer')
      .reduce((sum, p) => sum + p.amountPaise, 0);

    // Current month dues
    const currentMonthKey = new Date().toISOString().slice(0, 7); // e.g. "2026-10"
    const currentMonthDues = this.data.dues.filter((d) => d.monthYear === currentMonthKey);
    const pendingMonthlyDuesPaise = currentMonthDues.reduce((sum, d) => sum + d.remainingPaise, 0);
    const thisMonthCollectionPaise = currentMonthDues.reduce((sum, d) => sum + d.amountPaidPaise, 0);
    const thisMonthTargetPaise = currentMonthDues.reduce((sum, d) => sum + d.amountDuePaise, 0);

    // Overdue dues and distinct members with overdue dues
    const overdueDues = this.data.dues.filter((d) => d.remainingPaise > 0 && d.monthYear < currentMonthKey);
    const overdueMembersSet = new Set(overdueDues.map((d) => d.memberId));
    const overdueMembers = overdueMembersSet.size;

    return {
      totalMembers,
      activeMembers,
      pendingApprovals,
      overdueMembers,
      totalVerifiedCollectionPaise,
      cashCollectionPaise,
      onlineCollectionPaise,
      pendingMonthlyDuesPaise,
      overdueDuesCount: overdueDues.length,
      thisMonthCollectionPaise,
      thisMonthTargetPaise,
    };
  }

  public getMonthlyTrends(): MonthlyChartData[] {
    // Group verified payments by monthYear
    const map = new Map<string, { cash: number; online: number }>();

    for (const p of this.data.payments) {
      if (p.status !== 'verified') continue;
      const key = p.monthYear || p.paymentDate.slice(0, 7);
      const existing = map.get(key) || { cash: 0, online: 0 };
      if (p.paymentMethod === 'cash') {
        existing.cash += p.amountPaise;
      } else {
        existing.online += p.amountPaise;
      }
      map.set(key, existing);
    }

    const sortedKeys = Array.from(map.keys()).sort();
    return sortedKeys.map((key) => {
      const data = map.get(key)!;
      const [yearStr, monthStr] = key.split('-');
      const d = new Date(parseInt(yearStr, 10), parseInt(monthStr, 10) - 1, 1);
      const monthLabel = d.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
      return {
        monthYear: key,
        monthLabel,
        cashPaise: data.cash,
        onlinePaise: data.online,
        totalPaise: data.cash + data.online,
      };
    });
  }

  // ==========================================
  // SANSTHA UPDATES, MEETINGS & ANNOUNCEMENTS
  // ==========================================

  public getUpdates(onlyPublished: boolean = true): SansthaUpdate[] {
    if (!this.data.updates) this.data.updates = this.getInitialUpdates();
    const list = onlyPublished ? this.data.updates.filter((u) => u.isPublished) : this.data.updates;
    return list.slice().sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  public getUpdateById(id: string): SansthaUpdate | undefined {
    if (!this.data.updates) this.data.updates = this.getInitialUpdates();
    return this.data.updates.find((u) => u.id === id);
  }

  public createUpdate(
    params: Omit<SansthaUpdate, 'id' | 'createdAt' | 'updatedAt'>,
    actorId: string,
    actorName: string
  ): SansthaUpdate {
    if (!this.data.updates) this.data.updates = this.getInitialUpdates();
    const now = new Date().toISOString();
    const newUpdate: SansthaUpdate = {
      ...params,
      id: `UPD-${Date.now()}`,
      createdAt: now,
      updatedAt: now,
    };
    this.data.updates.unshift(newUpdate);
    this.addAuditLog(actorId, actorName, 'CREATE_UPDATE', `Published Sanstha update: "${newUpdate.title}" (${newUpdate.category})`);

    // Broadcast notification
    this.addNotification({
      targetUserId: null,
      type: 'announcement',
      title: newUpdate.title,
      message: newUpdate.content.slice(0, 150),
    });

    this.save();
    return newUpdate;
  }

  public updateSansthaUpdate(
    id: string,
    updates: Partial<SansthaUpdate>,
    actorId: string,
    actorName: string
  ): SansthaUpdate | null {
    if (!this.data.updates) this.data.updates = this.getInitialUpdates();
    const idx = this.data.updates.findIndex((u) => u.id === id);
    if (idx === -1) return null;
    this.data.updates[idx] = {
      ...this.data.updates[idx],
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    this.addAuditLog(actorId, actorName, 'UPDATE_SANSTHA_UPDATE', `Updated Sanstha update: "${this.data.updates[idx].title}"`);
    this.save();
    return this.data.updates[idx];
  }

  public deleteSansthaUpdate(id: string, actorId: string, actorName: string): boolean {
    if (!this.data.updates) this.data.updates = this.getInitialUpdates();
    const idx = this.data.updates.findIndex((u) => u.id === id);
    if (idx === -1) return false;
    const removed = this.data.updates.splice(idx, 1)[0];
    this.addAuditLog(actorId, actorName, 'DELETE_SANSTHA_UPDATE', `Deleted Sanstha update: "${removed.title}"`);
    this.save();
    return true;
  }

  // ==========================================
  // SANSTHA EXPENSES
  // ==========================================

  public getExpenses(): SansthaExpense[] {
    if (!this.data.expenses) this.data.expenses = this.getInitialExpenses();
    return this.data.expenses.slice().sort((a, b) => new Date(b.expenseDate).getTime() - new Date(a.expenseDate).getTime());
  }

  public createExpense(
    params: Omit<SansthaExpense, 'id' | 'createdAt'>,
    actorId: string,
    actorName: string
  ): SansthaExpense {
    if (!this.data.expenses) this.data.expenses = this.getInitialExpenses();
    const newExp: SansthaExpense = {
      ...params,
      id: `EXP-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    this.data.expenses.unshift(newExp);
    this.addAuditLog(actorId, actorName, 'CREATE_EXPENSE', `Recorded expense: ${newExp.title} (₹${newExp.amountPaise / 100})`);
    this.save();
    return newExp;
  }

  public deleteExpense(id: string, actorId: string, actorName: string): boolean {
    if (!this.data.expenses) this.data.expenses = this.getInitialExpenses();
    const idx = this.data.expenses.findIndex((e) => e.id === id);
    if (idx === -1) return false;
    const removed = this.data.expenses.splice(idx, 1)[0];
    this.addAuditLog(actorId, actorName, 'DELETE_EXPENSE', `Deleted expense: ${removed.title} (₹${removed.amountPaise / 100})`);
    this.save();
    return true;
  }

  // ==========================================
  // INSTITUTION-WIDE VERIFIED FINANCIAL SUMMARY
  // ==========================================

  public getSharedFinancialSummary(): SharedSansthaFinancials {
    if (!this.data.expenses) this.data.expenses = this.getInitialExpenses();

    const isAuthorized = this.data.settings.showFinancialSummaryToMembers !== false;
    const verifiedPayments = this.data.payments.filter((p) => p.status === 'verified');
    const totalContributionsPaise = verifiedPayments.reduce((sum, p) => sum + p.amountPaise, 0);

    const verifiedExpenses = this.data.expenses.filter((e) => e.isVerified);
    const totalExpensesPaise = verifiedExpenses.reduce((sum, e) => sum + e.amountPaise, 0);

    const remainingBalancePaise = totalContributionsPaise - totalExpensesPaise;

    const currentMonthPrefix = new Date().toISOString().slice(0, 7);
    const thisMonthCollectionPaise = verifiedPayments
      .filter((p) => (p.monthYear === currentMonthPrefix) || p.paymentDate.startsWith(currentMonthPrefix))
      .reduce((sum, p) => sum + p.amountPaise, 0);

    const thisMonthExpensesPaise = verifiedExpenses
      .filter((e) => e.expenseDate.startsWith(currentMonthPrefix))
      .reduce((sum, e) => sum + e.amountPaise, 0);

    return {
      isAuthorized,
      totalContributionsPaise,
      totalExpensesPaise,
      remainingBalancePaise,
      thisMonthCollectionPaise,
      thisMonthExpensesPaise,
      verifiedExpensesCount: verifiedExpenses.length,
      verifiedCollectionsCount: verifiedPayments.length,
      lastUpdated: new Date().toISOString(),
    };
  }

  // ==========================================
  // MEMBER ATTENDANCE RECORDS
  // ==========================================

  public getMemberAttendance(memberId: string): MemberAttendanceSummary[] {
    if (!this.data.updates) this.data.updates = this.getInitialUpdates();
    const results: MemberAttendanceSummary[] = [];
    for (const u of this.data.updates) {
      if (u.category === 'meeting' && u.attendance) {
        const found = u.attendance.find((a) => a.memberId === memberId);
        if (found) {
          results.push({
            meetingId: u.id,
            meetingTitle: u.title,
            date: u.date,
            venue: u.venue,
            status: found.status,
          });
        }
      }
    }
    return results;
  }
}

export const db = new SansthaDatabase();
