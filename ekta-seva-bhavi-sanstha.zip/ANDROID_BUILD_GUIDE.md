# Ekta Seva Bhavi Sanstha — Android Build & Packaging Guide

This guide details how to build, test, and release the native Android APK and Google Play Store Android App Bundle (AAB) for **Ekta Seva Bhavi Sanstha** (`org.ektasanstha.kalamnuri`).

---

## 1. Prerequisites

- **Node.js**: v18+ or v20+
- **Java Development Kit (JDK)**: OpenJDK 17 or 21
- **Android SDK**: API 34 (Android 14) platform tools & build tools (34.0.0+)
- **Android Studio** or command-line Gradle

---

## 2. Web Shortcut vs. Native Android APK Launcher Icon

> **Important Clarification for Mobile Users:**
> - **Website Shortcut ("Add to Home screen" in Chrome)**: Creates a browser-managed bookmark or WebAPK on your home screen. It runs inside the mobile browser engine and is not a stand-alone compiled native application package.
> - **Native Android APK Launcher Icon**: Compiles into the Android application binary using the assets in `android/app/src/main/res/mipmap-*/`. It installs as an independent native Android package (`org.ektasanstha.kalamnuri`) with full native lifecycle, custom launcher icon, and native splash screen.
> - An installable native APK file (`.apk`) **does not exist until it is actually compiled** via Gradle (locally) or via a Cloud CI/CD pipeline (e.g. GitHub Actions runner).

---

## 3. Project Configuration Overview

- **App Name**: Ekta Seva Bhavi Sanstha
- **Package ID**: `org.ektasanstha.kalamnuri`
- **Main Activity**: `org.ektasanstha.kalamnuri.MainActivity`
- **Capacitor Config**: `capacitor.config.ts`
- **Android Manifest**: `android-packaging/AndroidManifest.xml`
- **Web Build Target**: `dist/`

---

## 3. Step-by-Step Build Instructions

### Step 1: Build the Web App Distribution
```bash
npm run build
```

### Step 2: Initialize / Sync Android Platform with Capacitor
```bash
npx cap add android
npx cap sync android
```
*(If the `android` folder already exists, running `npx cap sync android` copies the latest web build into `android/app/src/main/assets/public`)*

---

### Step 3: Compiling Debug APK (For Testing on Physical Devices)

To compile an un-signed Debug APK directly from the terminal:
```bash
cd android
./gradlew assembleDebug
```

**Output APK location:**
```
android/app/build/outputs/apk/debug/app-debug.apk
```

You can install this directly on an Android phone using:
```bash
adb install android/app/build/outputs/apk/debug/app-debug.apk
```

---

### Step 4: Compiling Release APK

To create an optimized Release APK:
```bash
cd android
./gradlew assembleRelease
```

**Output APK location:**
```
android/app/build/outputs/apk/release/app-release-unsigned.apk
```

---

### Step 5: Building Android App Bundle (AAB) for Google Play Store

Google Play requires the `.aab` format for publishing:
```bash
cd android
./gradlew bundleRelease
```

**Output AAB location:**
```
android/app/build/outputs/bundle/release/app-release.aab
```

---

## 4. Keystore Generation & Release Signing

Generate a release keystore:
```bash
keytool -genkey -v -keystore ekta-sanstha-release.keystore \
  -alias ekta-release-key \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -dname "CN=Santoshrao Mali, OU=Management, O=Ekta Seva Bhavi Sanstha, L=Kalamnuri, ST=Maharashtra, C=IN"
```

Sign the APK using `apksigner`:
```bash
apksigner sign --ks ekta-sanstha-release.keystore \
  --out app-release-signed.apk \
  android/app/build/outputs/apk/release/app-release-unsigned.apk
```

Verify signature:
```bash
apksigner verify app-release-signed.apk
```

---

## 5. Device Native Features Configured

1. **Android Back Button**: Handled cleanly with Capacitor app listener.
2. **Offline-friendly Caching**: Persistent local database and offline UI state.
3. **Receipt Downloads**: Formatted for standard Indian mobile PDF viewers.
4. **Network Security**: Strict HTTPS communication with payment gateways and server proxy.
