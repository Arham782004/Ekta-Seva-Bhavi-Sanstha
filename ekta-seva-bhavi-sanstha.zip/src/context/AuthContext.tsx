import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Member, OrganizationSettings } from '../types/index.js';
import { api, authStorage } from '../services/api.js';

interface AuthContextType {
  user: User | null;
  member: Member | null;
  settings: OrganizationSettings | null;
  isLoading: boolean;
  isAdmin: boolean;
  isStaff: boolean;
  isMember: boolean;
  login: (loginId: string, pass: string) => Promise<{ success: boolean; role: 'admin' | 'staff' | 'member'; memberId?: string }>;
  logout: () => void;
  refreshUser: () => Promise<void>;
  updateSettingsState: (settings: OrganizationSettings) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [member, setMember] = useState<Member | null>(null);
  const [settings, setSettings] = useState<OrganizationSettings | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const fetchCurrentUser = async () => {
    const token = authStorage.getToken();
    if (!token) {
      setUser(null);
      setMember(null);
      setIsLoading(false);
      return;
    }

    try {
      const data = await api.auth.me();
      setUser(data.user);
      setMember(data.member || null);
      setSettings(data.settings);
    } catch (err) {
      console.warn('Session expired or invalid:', err);
      authStorage.clearToken();
      setUser(null);
      setMember(null);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchCurrentUser();
  }, []);

  const login = async (loginId: string, pass: string) => {
    setIsLoading(true);
    try {
      const res = await api.auth.login(loginId, pass);
      setUser(res.user);
      setMember(res.member || null);
      // fetch settings
      const meData = await api.auth.me();
      setSettings(meData.settings);
      return {
        success: true,
        role: res.user.role,
        memberId: res.user.memberId || undefined,
      };
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    api.auth.logout();
    setUser(null);
    setMember(null);
  };

  const refreshUser = async () => {
    await fetchCurrentUser();
  };

  const updateSettingsState = (newSettings: OrganizationSettings) => {
    setSettings(newSettings);
  };

  const isAdmin = user?.role === 'admin';
  const isStaff = user?.role === 'staff';
  const isMember = user?.role === 'member';

  return (
    <AuthContext.Provider
      value={{
        user,
        member,
        settings,
        isLoading,
        isAdmin,
        isStaff,
        isMember,
        login,
        logout,
        refreshUser,
        updateSettingsState,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
