/**
 * Indian Rupee and date/time formatters with integer-paise precision
 */

export function paiseToInr(paise: number): number {
  return Math.round(paise) / 100;
}

export function inrToPaise(inr: number): number {
  return Math.round(inr * 100);
}

export function formatINR(paise: number, showDecimals: boolean = false): string {
  const amount = paiseToInr(paise);
  const formatted = new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: showDecimals ? 2 : 0,
    maximumFractionDigits: 2,
  }).format(amount);
  return formatted;
}

export function formatDate(dateString: string, lang: 'hi' | 'mr' | 'en' = 'en'): string {
  try {
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return dateString;
    return new Intl.DateTimeFormat(lang === 'en' ? 'en-IN' : 'hi-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      timeZone: 'Asia/Kolkata',
    }).format(date);
  } catch {
    return dateString;
  }
}

export function formatDateTime(dateString: string, lang: 'hi' | 'mr' | 'en' = 'en'): string {
  try {
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return dateString;
    return new Intl.DateTimeFormat(lang === 'en' ? 'en-IN' : 'hi-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
      timeZone: 'Asia/Kolkata',
    }).format(date);
  } catch {
    return dateString;
  }
}

const singleDigits = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine'];
const teens = ['Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

function convertTwoDigits(num: number): string {
  if (num < 10) return singleDigits[num];
  if (num < 20) return teens[num - 10];
  return tens[Math.floor(num / 10)] + (num % 10 !== 0 ? ' ' + singleDigits[num % 10] : '');
}

export function inrToWords(paise: number, lang: 'hi' | 'mr' | 'en' = 'en'): string {
  const inr = Math.floor(paiseToInr(paise));
  if (inr === 0) {
    if (lang === 'hi') return 'शून्य रुपये मात्र';
    if (lang === 'mr') return 'शून्य रुपये फक्त';
    return 'Zero Rupees Only';
  }

  if (lang === 'hi' || lang === 'mr') {
    // For Indian community receipts, English or Devanagari representation
    const suffix = lang === 'mr' ? 'रुपये फक्त' : 'रुपये मात्र';
    if (inr === 1000) return `एक हजार ${suffix}`;
    if (inr === 2000) return `दोन हजार ${suffix}`;
    if (inr === 500) return `पाचशे ${suffix}`;
    if (inr === 1500) return `पंधराशे ${suffix}`;
    if (inr === 3000) return `तीन हजार ${suffix}`;
  }

  // English Indian numbering words
  let rem = inr;
  const parts: string[] = [];

  const crores = Math.floor(rem / 10000000);
  rem %= 10000000;
  if (crores > 0) parts.push(`${convertTwoDigits(crores)} Crore`);

  const lakhs = Math.floor(rem / 100000);
  rem %= 100000;
  if (lakhs > 0) parts.push(`${convertTwoDigits(lakhs)} Lakh`);

  const thousands = Math.floor(rem / 1000);
  rem %= 1000;
  if (thousands > 0) parts.push(`${convertTwoDigits(thousands)} Thousand`);

  const hundreds = Math.floor(rem / 100);
  rem %= 100;
  if (hundreds > 0) parts.push(`${singleDigits[hundreds]} Hundred`);

  if (rem > 0) {
    parts.push(convertTwoDigits(rem));
  }

  return `${parts.join(' ')} Rupees Only`.trim();
}
