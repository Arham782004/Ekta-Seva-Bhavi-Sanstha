import { jsPDF } from 'jspdf';
import { Receipt } from '../types/index.js';
import { formatINR, formatDateTime } from './formatters.js';

export function generateReceiptPdf(receipt: Receipt) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a5', // Standard compact receipt size
  });

  const pageWidth = 148;

  // Header Background bar
  doc.setFillColor(30, 64, 175); // Royal Blue #1E40AF
  doc.rect(0, 0, pageWidth, 28, 'F');

  // Exact Organization Logo Emblem on Left
  const logoX = 15;
  const logoY = 14;
  const logoR = 9;
  // Outer gold circle stroke
  doc.setFillColor(245, 158, 11); // #F59E0B
  doc.circle(logoX, logoY, logoR, 'F');
  // Inner royal blue disc
  doc.setFillColor(30, 64, 175); // #1E40AF
  doc.circle(logoX, logoY, logoR - 0.8, 'F');
  // Center emerald green banyan tree motif
  doc.setFillColor(52, 211, 153); // #34D399
  doc.circle(logoX, logoY - 1.2, 3.5, 'F');
  // Gold supportive hands ribbon
  doc.setFillColor(251, 191, 36); // #FBBF24
  doc.roundedRect(logoX - 5, logoY + 2.8, 10, 2.2, 0.5, 0.5, 'F');
  // Center White Rupee symbol disc
  doc.setFillColor(255, 255, 255);
  doc.circle(logoX, logoY - 1.2, 1.6, 'F');
  doc.setTextColor(30, 64, 175);
  doc.setFontSize(5.5);
  doc.setFont('helvetica', 'bold');
  doc.text('₹', logoX, logoY - 0.5, { align: 'center' });

  // Header Title
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.text(receipt.organizationName || 'EKTA SEVA BHAVI SANSTHA', (pageWidth + 10) / 2, 10, { align: 'center' });

  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.text(receipt.organizationAddress || 'Mali Galli, Kalamnuri, Maharashtra, India', (pageWidth + 10) / 2, 16, {
    align: 'center',
  });
  doc.text('Reg. No: MAH/KLM/1048/2022 | Monthly Contribution Receipt', (pageWidth + 10) / 2, 21, {
    align: 'center',
  });

  // Receipt Number & Date Banner
  doc.setFillColor(243, 244, 246);
  doc.rect(8, 32, pageWidth - 16, 12, 'F');
  doc.setDrawColor(229, 231, 235);
  doc.rect(8, 32, pageWidth - 16, 12, 'S');

  doc.setTextColor(31, 41, 55);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.text(`Receipt No: ${receipt.receiptNumber}`, 12, 39);

  doc.setFont('helvetica', 'normal');
  const dateStr = formatDateTime(receipt.paymentDate);
  doc.text(`Date: ${dateStr}`, pageWidth - 12, 39, { align: 'right' });

  // Member & Payment Details Table
  let y = 52;
  const col1 = 12;
  const col2 = 55;

  const addRow = (label: string, value: string, isBold: boolean = false) => {
    doc.setTextColor(107, 114, 128); // slate-500
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.text(label, col1, y);

    doc.setTextColor(17, 24, 39); // slate-900
    doc.setFont('helvetica', isBold ? 'bold' : 'normal');
    doc.text(value, col2, y);

    // subtle separator line
    doc.setDrawColor(243, 244, 246);
    doc.line(col1, y + 2, pageWidth - 12, y + 2);
    y += 8;
  };

  addRow('Member ID:', receipt.memberId, true);
  addRow('Member Name:', receipt.memberName, true);
  addRow('Mobile Number:', receipt.memberMobile || 'N/A');
  addRow('Billing Month:', receipt.monthLabel || receipt.monthYear, true);
  addRow('Payment Method:', receipt.paymentMethod.toUpperCase(), false);
  addRow('Transaction Ref:', receipt.transactionRef || 'N/A', false);
  addRow('Verification Status:', receipt.status.toUpperCase(), true);

  // Amount Highlight Box
  y += 2;
  doc.setFillColor(238, 242, 255); // soft indigo
  doc.setDrawColor(199, 210, 254);
  doc.rect(col1, y, pageWidth - 24, 16, 'FD');

  doc.setTextColor(30, 64, 175);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.text('AMOUNT RECEIVED:', col1 + 4, y + 6);
  doc.setFontSize(12);
  doc.text(formatINR(receipt.amountPaise), col1 + 4, y + 12);

  doc.setFontSize(8);
  doc.setFont('helvetica', 'italic');
  doc.setTextColor(75, 85, 99);
  doc.text(`In words: ${receipt.amountInWords}`, pageWidth - 16, y + 10, { align: 'right' });

  y += 24;

  // Remaining Balance note
  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(107, 114, 128);
  doc.text(
    `Remaining Balance for this Month: ${formatINR(receipt.remainingBalancePaise)}`,
    col1,
    y
  );

  // Signatures & Stamp area
  y += 18;

  // Left: Sanstha Stamp Seal placeholder
  doc.setDrawColor(14, 165, 233);
  doc.setLineWidth(0.5);
  doc.circle(col1 + 18, y + 4, 12);
  doc.setFontSize(6);
  doc.setTextColor(14, 165, 233);
  doc.setFont('helvetica', 'bold');
  doc.text('EKTA SEVA BHAVI', col1 + 18, y + 2, { align: 'center' });
  doc.text('SANSTHA', col1 + 18, y + 5, { align: 'center' });
  doc.text('KALAMNURI', col1 + 18, y + 8, { align: 'center' });

  // Right: Authorized Signatory
  const rightX = pageWidth - 16;
  doc.setDrawColor(156, 163, 175);
  doc.line(rightX - 45, y + 6, rightX, y + 6);

  doc.setFontSize(8);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(31, 41, 55);
  doc.text(receipt.issuedBy || 'Authorized Signatory', rightX, y + 11, { align: 'right' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  doc.setTextColor(107, 114, 128);
  doc.text('Ekta Seva Bhavi Sanstha, Kalamnuri', rightX, y + 15, { align: 'right' });

  // Footer Disclaimer
  doc.setFontSize(6.5);
  doc.setTextColor(156, 163, 175);
  doc.text(
    'This is a computer-generated verified receipt issued by Ekta Seva Bhavi Sanstha, Mali Galli, Kalamnuri.',
    pageWidth / 2,
    202,
    { align: 'center' }
  );

  // Save PDF
  doc.save(`${receipt.receiptNumber}_EktaSanstha.pdf`);
}
