export type SupportedLanguage = 'hi' | 'mr' | 'en';

export interface Translations {
  appName: string;
  orgAddress: string;
  tagline: string;
  currencySymbol: string;

  // Nav & common
  dashboard: string;
  members: string;
  dues: string;
  payments: string;
  receipts: string;
  notifications: string;
  reports: string;
  settings: string;
  auditLogs: string;
  logout: string;
  login: string;
  register: string;
  profile: string;
  search: string;
  filter: string;
  all: string;
  active: string;
  inactive: string;
  pending: string;
  overdue: string;
  paid: string;
  unpaid: string;
  partiallyPaid: string;
  save: string;
  cancel: string;
  delete: string;
  confirm: string;
  viewDetails: string;
  downloadPdf: string;
  print: string;
  close: string;
  actions: string;
  status: string;
  total: string;
  amount: string;
  date: string;
  method: string;
  cash: string;
  onlineUpi: string;
  bankTransfer: string;
  notes: string;
  success: string;
  error: string;
  loading: string;
  back: string;

  // Splash & Auth
  welcomeTitle: string;
  welcomeSubtitle: string;
  adminLogin: string;
  staffLogin: string;
  memberLogin: string;
  loginAsAdmin: string;
  loginAsStaff: string;
  loginAsMember: string;
  emailOrMobile: string;
  staffEmailOrMobile: string;
  memberIdOrMobile: string;
  password: string;
  forgotPassword: string;
  resetPassword: string;
  noAccountRegister: string;
  alreadyHaveAccount: string;
  registerTitle: string;
  registerDesc: string;
  fullName: string;
  mobileNumber: string;
  emailAddress: string;
  addressLabel: string;
  joiningDate: string;
  monthlyContribution: string;
  registrationSuccessMsg: string;
  approvalPendingMsg: string;

  // Admin Dashboard
  totalMembersCount: string;
  totalVerifiedCollection: string;
  cashCollectionTotal: string;
  onlineCollectionTotal: string;
  pendingMonthlyPayments: string;
  overdueMembersCount: string;
  quickActions: string;
  addMemberBtn: string;
  monthlyDepositBtn: string;
  generateDuesBtn: string;
  recentTransactions: string;
  monthlyCollectionChart: string;
  collectionBreakdown: string;

  // Member Management
  memberListTitle: string;
  addNewMemberTitle: string;
  memberId: string;
  viewHistory: string;
  deactivateMember: string;
  activateMember: string;
  approveMember: string;
  rejectMember: string;
  outstandingBalance: string;
  totalPaid: string;
  memberDetails: string;

  // Dues & Cash Deposit
  monthlyDuesTitle: string;
  monthYear: string;
  amountDue: string;
  amountPaid: string;
  remainingAmount: string;
  dueDate: string;
  recordCashDeposit: string;
  selectMember: string;
  selectMonth: string;
  receivedBy: string;
  depositSuccess: string;
  payNow: string;

  // Online Checkout
  onlinePaymentTitle: string;
  onlinePaymentDesc: string;
  verifyAndPay: string;
  testSandboxNotice: string;
  paymentSuccessful: string;
  paymentFailed: string;

  // Receipts
  receiptTitle: string;
  receiptNumber: string;
  receiptOfContribution: string;
  amountInWords: string;
  authorizedSignatory: string;
  officialStamp: string;
  searchReceipts: string;

  // Reports
  collectionReportsTitle: string;
  exportCsv: string;
  exportExcel: string;
  printReport: string;
  dateRange: string;
  summaryByMonth: string;
  paymentMethodComparison: string;

  // Member Dashboard
  myDashboard: string;
  myDues: string;
  myReceipts: string;
  myContributions: string;
  currentMonthStatus: string;
  noDuesPending: string;
}

export const translations: Record<SupportedLanguage, Translations> = {
  hi: {
    appName: 'एकता सेवा भावी संस्था',
    orgAddress: 'माळी गल्ली, कळमनुरी, महाराष्ट्र',
    tagline: 'पारदर्शक आणि विश्वासार्ह संस्था व्यवस्थापन प्रणाली',
    currencySymbol: '₹',

    dashboard: 'डॅशबोर्ड',
    members: 'सदस्य',
    dues: 'मासिक देय (हप्ते)',
    payments: 'जमा रक्कम',
    receipts: 'पावती (Receipts)',
    notifications: 'सूचना (Notifications)',
    reports: 'अहवाल (Reports)',
    settings: 'सेटिंग्ज',
    auditLogs: 'ऑडिट लॉग',
    logout: 'लॉगआउट',
    login: 'लॉगिन',
    register: 'नोंदणी करा',
    profile: 'माझे प्रोफाइल',
    search: 'शोधा (नाव, आयडी, मोबाईल)...',
    filter: 'फिल्टर करा',
    all: 'सर्व',
    active: 'सक्रिय',
    inactive: 'निष्क्रिय',
    pending: 'प्रलंबित',
    overdue: 'थकबाकीदार',
    paid: 'पूर्ण भरलेले',
    unpaid: 'बाकी',
    partiallyPaid: 'अंशतः भरलेले',
    save: 'जतन करा',
    cancel: 'रद्द करा',
    delete: 'हटवा',
    confirm: 'निश्चित करा',
    viewDetails: 'तपशील पहा',
    downloadPdf: 'PDF डाउनलोड करा',
    print: 'प्रिंट करा',
    close: 'बंद करा',
    actions: 'क्रिया',
    status: 'स्थिती',
    total: 'एकूण',
    amount: 'रक्कम',
    date: 'तारीख',
    method: 'माध्यम',
    cash: 'रोख (Cash)',
    onlineUpi: 'ऑनलाइन (UPI)',
    bankTransfer: 'बँक ट्रान्सफर',
    notes: 'नोंद / टीप',
    success: 'यशस्वी!',
    error: 'त्रुटी',
    loading: 'लोड होत आहे...',
    back: 'मागे जा',

    welcomeTitle: 'एकता सेवा भावी संस्था, कळमनुरी',
    welcomeSubtitle: 'माळी गल्ली, कळमनुरी - मासिक योगदान आणि सदस्य निधी व्यवस्थापन पोर्टल',
    adminLogin: 'प्रशासक लॉगिन (Admin)',
    staffLogin: 'स्टाफ लॉगिन (Staff)',
    memberLogin: 'सदस्य लॉगिन (Member Login)',
    loginAsAdmin: 'प्रशासक म्हणून लॉगिन',
    loginAsStaff: 'स्टाफ म्हणून लॉगिन',
    loginAsMember: 'सदस्य म्हणून लॉगिन',
    emailOrMobile: 'ईमेल किंवा मोबाईल नंबर',
    staffEmailOrMobile: 'स्टाफ ईमेल किंवा मोबाईल नंबर',
    memberIdOrMobile: 'सदस्य आयडी (उदा. M001) किंवा मोबाईल',
    password: 'पासवर्ड',
    forgotPassword: 'पासवर्ड विसरलात?',
    resetPassword: 'पासवर्ड रीसेट करा',
    noAccountRegister: 'नवीन सदस्य? येथे नोंदणी करा',
    alreadyHaveAccount: 'आधीच खाते आहे? लॉगिन करा',
    registerTitle: 'नवीन सदस्य नोंदणी',
    registerDesc: 'कृपया आपली अचूक माहिती भरा. प्रशासकाच्या मंजुरीनंतर आपले सदस्यत्व सुरू होईल.',
    fullName: 'पूर्ण नाव',
    mobileNumber: 'मोबाईल नंबर',
    emailAddress: 'ईमेल पत्ता (ऐच्छिक)',
    addressLabel: 'पत्ता',
    joiningDate: 'जोडल्याची तारीख',
    monthlyContribution: 'मासिक योगदान (रुपये)',
    registrationSuccessMsg: 'नोंदणी यशस्वीरीत्या स्वीकारली आहे! प्रशासकाच्या मंजुरीनंतर लॉगिन करता येईल.',
    approvalPendingMsg: 'आपले खाते मंजुरीच्या प्रतीक्षेत आहे.',

    totalMembersCount: 'एकूण सदस्य',
    totalVerifiedCollection: 'एकूण जमा निधी (Verified)',
    cashCollectionTotal: 'रोख जमा (Cash)',
    onlineCollectionTotal: 'ऑनलाइन जमा (UPI/QR)',
    pendingMonthlyPayments: 'चालू महिन्याची बाकी',
    overdueMembersCount: 'थकबाकीदार सदस्य',
    quickActions: 'जलद कृती (Quick Actions)',
    addMemberBtn: 'नवीन सदस्य जोडा',
    monthlyDepositBtn: 'रोख रक्कम जमा करा',
    generateDuesBtn: 'चालू महिन्याचे हप्ते तयार करा',
    recentTransactions: 'अलीकडील व्यवहार',
    monthlyCollectionChart: 'मासिक वसुली आलेख',
    collectionBreakdown: 'जमा पद्धतीचे विभाजन',

    memberListTitle: 'संस्थेचे सर्व सदस्य',
    addNewMemberTitle: 'नवीन सदस्य जोडा',
    memberId: 'सदस्य आयडी',
    viewHistory: 'इतिहास पहा',
    deactivateMember: 'निष्क्रिय करा',
    activateMember: 'सक्रिय करा',
    approveMember: 'मंजूर करा',
    rejectMember: 'नाकारात करा',
    outstandingBalance: 'एकूण बाकी रक्कम',
    totalPaid: 'एकूण भरलेली रक्कम',
    memberDetails: 'सदस्य तपशील',

    monthlyDuesTitle: 'मासिक हप्ते (Dues)',
    monthYear: 'महिना / वर्ष',
    amountDue: 'देय रक्कम',
    amountPaid: 'भरलेली रक्कम',
    remainingAmount: 'शिल्लक बाकी',
    dueDate: 'देय तारीख',
    recordCashDeposit: 'रोख पावती जमा नोंद',
    selectMember: 'सदस्य निवडा',
    selectMonth: 'महिना निवडा',
    receivedBy: 'स्वीकारकर्ता (प्रशासक)',
    depositSuccess: 'रक्कम यशस्वीरित्या जमा झाली व पावती तयार झाली!',
    payNow: 'आता भरा (Pay Now)',

    onlinePaymentTitle: 'ऑनलाइन UPI द्वारे हप्ता भरा',
    onlinePaymentDesc: 'सुरक्षित Razorpay गेटवे किंवा थेट UPI द्वारे एका क्लिकवर त्वरित हप्ता जमा करा.',
    verifyAndPay: 'पडताळणी करा आणि पैसे भरा',
    testSandboxNotice: 'सँडबॉक्स / चाचणी मोड सक्रिय आहे. चाचणी पेमेंटसाठी उपलब्ध आहे.',
    paymentSuccessful: 'पेमेंट यशस्वीरित्या पडताळले गेले आहे!',
    paymentFailed: 'पेमेंट अयशस्वी किंवा रद्द झाले.',

    receiptTitle: 'योगदान पावती',
    receiptNumber: 'पावती क्रमांक',
    receiptOfContribution: 'मासिक वर्गणी / योगदान पावती',
    amountInWords: 'अक्षरी रक्कम',
    authorizedSignatory: 'अधिकृत स्वाक्षरीकार',
    officialStamp: 'संस्थेचा शिक्का',
    searchReceipts: 'पावती शोधा...',

    collectionReportsTitle: 'एकूण जमा अहवाल आणि विश्लेषण',
    exportCsv: 'CSV डाउनलोड',
    exportExcel: 'Excel स्वरूप',
    printReport: 'अहवाल प्रिंट करा',
    dateRange: 'कालावधी',
    summaryByMonth: 'महिन्यानुसार सारांश',
    paymentMethodComparison: 'रोख विरुद्ध ऑनलाइन तुलना',

    myDashboard: 'माझे सदस्य पोर्टल',
    myDues: 'माझे मासिक हप्ते',
    myReceipts: 'माझ्या पावत्या',
    myContributions: 'माझे एकूण योगदान',
    currentMonthStatus: 'चालू महिन्याची स्थिती',
    noDuesPending: 'अभिनंदन! चालू महिन्याचा हप्ता पूर्ण भरलेला आहे.',
  },

  mr: {
    appName: 'एकता सेवाभावी संस्था',
    orgAddress: 'माळी गल्ली, कळमनुरी, महाराष्ट्र',
    tagline: 'पारदर्शक आणि विश्वासार्ह संस्था व्यवस्थापन प्रणाली',
    currencySymbol: '₹',

    dashboard: 'डॅशबोर्ड',
    members: 'सदस्य यादी',
    dues: 'मासिक वर्गणी',
    payments: 'जमा नोंदी',
    receipts: 'पावत्या (Receipts)',
    notifications: 'सूचना (Notifications)',
    reports: 'अहवाल (Reports)',
    settings: 'सेटिंग्ज',
    auditLogs: 'ऑडिट लॉग',
    logout: 'लॉगआउट',
    login: 'लॉगिन',
    register: 'नोंदणी करा',
    profile: 'माझे प्रोफाईल',
    search: 'शोधा (नाव, आयडी, मोबाईल)...',
    filter: 'फिल्टर',
    all: 'सर्व',
    active: 'सक्रिय',
    inactive: 'निष्क्रिय',
    pending: 'प्रलंबित',
    overdue: 'थकबाकीदार',
    paid: 'पूर्ण भरलेले',
    unpaid: 'बाकी',
    partiallyPaid: 'अंशतः भरलेले',
    save: 'जतन करा',
    cancel: 'रद्द करा',
    delete: 'हटवा',
    confirm: 'निश्चित करा',
    viewDetails: 'तपशील पहा',
    downloadPdf: 'PDF डाउनलोड',
    print: 'प्रिंट करा',
    close: 'बंद करा',
    actions: 'क्रिया',
    status: 'स्थिती',
    total: 'एकूण',
    amount: 'रक्कम',
    date: 'दिनांक',
    method: 'माध्यम',
    cash: 'रोख (Cash)',
    onlineUpi: 'ऑनलाइन (UPI)',
    bankTransfer: 'बँक ट्रान्सफर',
    notes: 'नोंद',
    success: 'यशस्वी!',
    error: 'त्रुटी',
    loading: 'लोड होत आहे...',
    back: 'मागे जा',

    welcomeTitle: 'एकता सेवाभावी संस्था, कळमनुरी',
    welcomeSubtitle: 'माळी गल्ली, कळमनुरी - मासिक वर्गणी व सदस्य निधी व्यवस्थापन',
    adminLogin: 'प्रशासक लॉगिन (Admin)',
    staffLogin: 'स्टाफ लॉगिन (Staff)',
    memberLogin: 'सदस्य लॉगिन (Member Login)',
    loginAsAdmin: 'प्रशासक म्हणून लॉगिन',
    loginAsStaff: 'स्टाफ म्हणून लॉगिन',
    loginAsMember: 'सदस्य म्हणून लॉगिन',
    emailOrMobile: 'ईमेल किंवा मोबाईल नंबर',
    staffEmailOrMobile: 'स्टाफ ईमेल किंवा मोबाईल नंबर',
    memberIdOrMobile: 'सदस्य आयडी किंवा मोबाईल',
    password: 'पासवर्ड',
    forgotPassword: 'पासवर्ड विसरलात?',
    resetPassword: 'पासवर्ड बदला',
    noAccountRegister: 'नवीन आहात? नोंदणी करा',
    alreadyHaveAccount: 'खाते आहे? लॉगिन करा',
    registerTitle: 'नवीन सदस्य नोंदणी',
    registerDesc: 'कृपया अचूक माहिती भरा. मंजुरीनंतर सदस्यत्व सुरू होईल.',
    fullName: 'पूर्ण नाव',
    mobileNumber: 'मोबाईल नंबर',
    emailAddress: 'ईमेल पत्ता (ऐच्छिक)',
    addressLabel: 'पत्ता',
    joiningDate: 'सामील तारीख',
    monthlyContribution: 'मासिक वर्गणी (₹)',
    registrationSuccessMsg: 'नोंदणी यशस्वी! प्रशासकीय मंजुरीची वाट पहा.',
    approvalPendingMsg: 'खाते मंजुरीच्या प्रतीक्षेत आहे.',

    totalMembersCount: 'एकूण सदस्य',
    totalVerifiedCollection: 'एकूण जमा निधी',
    cashCollectionTotal: 'रोख जमा (Cash)',
    onlineCollectionTotal: 'ऑनलाइन जमा (UPI)',
    pendingMonthlyPayments: 'चालू महिन्याची बाकी',
    overdueMembersCount: 'थकबाकीदार सदस्य',
    quickActions: 'त्वरित कृती (Quick Actions)',
    addMemberBtn: 'नवीन सदस्य जोडा',
    monthlyDepositBtn: 'रोख जमा नोंदवा',
    generateDuesBtn: 'चालू महिन्याचे हप्ते तयार करा',
    recentTransactions: 'अलीकडील व्यवहार',
    monthlyCollectionChart: 'मासिक वसुली आलेख',
    collectionBreakdown: 'जमा पद्धत विश्लेषण',

    memberListTitle: 'संस्थेचे सदस्य',
    addNewMemberTitle: 'नवीन सदस्य जोडा',
    memberId: 'सदस्य आयडी',
    viewHistory: 'इतिहास पहा',
    deactivateMember: 'निष्क्रिय करा',
    activateMember: 'सक्रिय करा',
    approveMember: 'मंजूर करा',
    rejectMember: 'नाकारा',
    outstandingBalance: 'एकूण बाकी',
    totalPaid: 'एकूण भरलेली रक्कम',
    memberDetails: 'सदस्य तपशील',

    monthlyDuesTitle: 'मासिक वर्गणी हप्ते',
    monthYear: 'महिना / वर्ष',
    amountDue: 'देय रक्कम',
    amountPaid: 'भरलेली रक्कम',
    remainingAmount: 'शिल्लक बाकी',
    dueDate: 'शेवटची तारीख',
    recordCashDeposit: 'रोख पावती जमा करा',
    selectMember: 'सदस्य निवडा',
    selectMonth: 'महिना निवडा',
    receivedBy: 'स्वीकारकर्ता प्रशासक',
    depositSuccess: 'रक्कम जमा झाली व पावती जनरेट झाली!',
    payNow: 'आता भरा (Pay Now)',

    onlinePaymentTitle: 'ऑनलाइन UPI द्वारे वर्गणी भरा',
    onlinePaymentDesc: 'सुरक्षित Razorpay किंवा थेट UPI द्वारे घरबसल्या वर्गणी भरा.',
    verifyAndPay: 'पडताळणी करा आणि भरा',
    testSandboxNotice: 'सँडबॉक्स चाचणी मोड सक्रिय आहे.',
    paymentSuccessful: 'पेमेंट यशस्वीरित्या पूर्ण झाले!',
    paymentFailed: 'पेमेंट अयशस्वी झाले.',

    receiptTitle: 'वर्गणी पावती',
    receiptNumber: 'पावती क्रमांक',
    receiptOfContribution: 'मासिक वर्गणी पावती',
    amountInWords: 'अक्षरी रक्कम',
    authorizedSignatory: 'अधिकृत स्वाक्षरी',
    officialStamp: 'संस्थेचा शिक्का',
    searchReceipts: 'पावती शोधा...',

    collectionReportsTitle: 'एकूण जमा अहवाल',
    exportCsv: 'CSV डाउनलोड',
    exportExcel: 'Excel डाऊनलोड',
    printReport: 'प्रिंट अहवाल',
    dateRange: 'कालावधी',
    summaryByMonth: 'महिन्यानुसार गोषवारा',
    paymentMethodComparison: 'रोख विरुद्ध ऑनलाइन',

    myDashboard: 'माझे सदस्य पोर्टल',
    myDues: 'माझी देय वर्गणी',
    myReceipts: 'माझ्या पावत्या',
    myContributions: 'माझे एकूण योगदान',
    currentMonthStatus: 'चालू महिन्याची स्थिती',
    noDuesPending: 'अभिनंदन! चालू महिन्याची वर्गणी पूर्ण भरलेली आहे.',
  },

  en: {
    appName: 'Ekta Seva Bhavi Sanstha',
    orgAddress: 'Mali Galli, Kalamnuri, Maharashtra, India',
    tagline: 'Transparent & Reliable Sanstha Management System',
    currencySymbol: '₹',

    dashboard: 'Dashboard',
    members: 'Members',
    dues: 'Monthly Dues',
    payments: 'Collections',
    receipts: 'Receipts',
    notifications: 'Notifications',
    reports: 'Reports',
    settings: 'Settings',
    auditLogs: 'Audit Logs',
    logout: 'Logout',
    login: 'Login',
    register: 'Register',
    profile: 'My Profile',
    search: 'Search by name, ID, or mobile...',
    filter: 'Filter',
    all: 'All',
    active: 'Active',
    inactive: 'Inactive',
    pending: 'Pending Approval',
    overdue: 'Overdue',
    paid: 'Paid',
    unpaid: 'Unpaid',
    partiallyPaid: 'Partially Paid',
    save: 'Save',
    cancel: 'Cancel',
    delete: 'Delete',
    confirm: 'Confirm',
    viewDetails: 'View Details',
    downloadPdf: 'Download PDF',
    print: 'Print',
    close: 'Close',
    actions: 'Actions',
    status: 'Status',
    total: 'Total',
    amount: 'Amount',
    date: 'Date',
    method: 'Method',
    cash: 'Cash',
    onlineUpi: 'Online UPI',
    bankTransfer: 'Bank Transfer',
    notes: 'Notes / Remarks',
    success: 'Success!',
    error: 'Error',
    loading: 'Loading...',
    back: 'Back',

    welcomeTitle: 'Ekta Seva Bhavi Sanstha, Kalamnuri',
    welcomeSubtitle: 'Mali Galli, Kalamnuri — Monthly contribution ledger & community fund portal',
    adminLogin: 'प्रशासक लॉगिन (Admin)',
    staffLogin: 'स्टाफ लॉगिन (Staff)',
    memberLogin: 'सदस्य लॉगिन (Member Login)',
    loginAsAdmin: 'Login as Administrator',
    loginAsStaff: 'Login as Staff',
    loginAsMember: 'Login as Member',
    emailOrMobile: 'Admin Email or Mobile Number',
    staffEmailOrMobile: 'Staff Email or Mobile Number',
    memberIdOrMobile: 'Member ID (e.g. M001) or Mobile',
    password: 'Password',
    forgotPassword: 'Forgot Password?',
    resetPassword: 'Reset Password',
    noAccountRegister: 'New Member? Register Here',
    alreadyHaveAccount: 'Already have an account? Login',
    registerTitle: 'New Member Registration',
    registerDesc: 'Fill out your accurate details. Your membership will activate upon administrator verification.',
    fullName: 'Full Name',
    mobileNumber: 'Mobile Number',
    emailAddress: 'Email Address (Optional)',
    addressLabel: 'Residential Address',
    joiningDate: 'Joining Date',
    monthlyContribution: 'Monthly Contribution (₹)',
    registrationSuccessMsg: 'Registration submitted successfully! You can login once approved by the administrator.',
    approvalPendingMsg: 'Your account is pending administrator verification.',

    totalMembersCount: 'Total Members',
    totalVerifiedCollection: 'Total Verified Collection',
    cashCollectionTotal: 'Cash Collection',
    onlineCollectionTotal: 'Online Collection (UPI)',
    pendingMonthlyPayments: 'Pending Dues (This Month)',
    overdueMembersCount: 'Overdue Members',
    quickActions: 'Quick Actions',
    addMemberBtn: 'Add Member',
    monthlyDepositBtn: 'Record Cash Deposit',
    generateDuesBtn: 'Generate Monthly Dues',
    recentTransactions: 'Recent Transactions',
    monthlyCollectionChart: 'Monthly Collection Trend',
    collectionBreakdown: 'Payment Method Breakdown',

    memberListTitle: 'Sanstha Members Directory',
    addNewMemberTitle: 'Add New Member',
    memberId: 'Member ID',
    viewHistory: 'View History',
    deactivateMember: 'Deactivate Member',
    activateMember: 'Activate Member',
    approveMember: 'Approve Member',
    rejectMember: 'Reject Member',
    outstandingBalance: 'Outstanding Balance',
    totalPaid: 'Total Contributed',
    memberDetails: 'Member Details',

    monthlyDuesTitle: 'Monthly Contribution Ledger',
    monthYear: 'Month & Year',
    amountDue: 'Amount Due',
    amountPaid: 'Amount Paid',
    remainingAmount: 'Balance',
    dueDate: 'Due Date',
    recordCashDeposit: 'Record Cash Contribution',
    selectMember: 'Select Member',
    selectMonth: 'Select Billing Month',
    receivedBy: 'Received By (Admin)',
    depositSuccess: 'Cash payment recorded and official receipt generated!',
    payNow: 'Pay Now (Online UPI)',

    onlinePaymentTitle: 'Online UPI Contribution Checkout',
    onlinePaymentDesc: 'Make your monthly Sanstha contribution instantly and securely using UPI or card.',
    verifyAndPay: 'Verify & Pay Securely',
    testSandboxNotice: 'Test Sandbox Mode Active. Server signature verification is fully enabled.',
    paymentSuccessful: 'Payment verified and credited successfully!',
    paymentFailed: 'Payment was not completed or failed verification.',

    receiptTitle: 'Official Contribution Receipt',
    receiptNumber: 'Receipt Number',
    receiptOfContribution: 'Monthly Contribution Receipt',
    amountInWords: 'Amount in Words',
    authorizedSignatory: 'Authorized Signatory',
    officialStamp: 'Sanstha Official Seal',
    searchReceipts: 'Search receipts by number or member...',

    collectionReportsTitle: 'Total Collection Reports & Analytics',
    exportCsv: 'Export to CSV',
    exportExcel: 'Export to Excel',
    printReport: 'Print Full Report',
    dateRange: 'Date Range',
    summaryByMonth: 'Month-by-Month Summary',
    paymentMethodComparison: 'Cash vs Online Breakdown',

    myDashboard: 'My Member Dashboard',
    myDues: 'My Contribution Dues',
    myReceipts: 'My Receipts',
    myContributions: 'Total Verified Contributions',
    currentMonthStatus: 'Current Month Status',
    noDuesPending: 'All caught up! No dues pending for this month.',
  },
};
