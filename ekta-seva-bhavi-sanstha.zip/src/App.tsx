import React, { useState } from 'react';
import { LanguageProvider, useLanguage } from './context/LanguageContext.js';
import { AuthProvider, useAuth } from './context/AuthContext.js';
import { Navbar } from './components/common/Navbar.js';
import { AuthScreen } from './components/auth/AuthScreen.js';
import { AdminDashboard } from './components/dashboard/AdminDashboard.js';
import { MemberList } from './components/members/MemberList.js';
import { MemberDetails } from './components/members/MemberDetails.js';
import { AddMemberModal } from './components/members/AddMemberModal.js';
import { MonthlyDuesScreen } from './components/dues/MonthlyDuesScreen.js';
import { GenerateDuesModal } from './components/dues/GenerateDuesModal.js';
import { CashDepositModal } from './components/payments/CashDepositModal.js';
import { OnlinePaymentModal } from './components/payments/OnlinePaymentModal.js';
import { ReceiptsListScreen } from './components/receipts/ReceiptsListScreen.js';
import { ReceiptModal } from './components/receipts/ReceiptModal.js';
import { ReportsScreen } from './components/reports/ReportsScreen.js';
import { NotificationsScreen } from './components/notifications/NotificationsScreen.js';
import { SettingsScreen } from './components/settings/SettingsScreen.js';
import { MemberPortal } from './components/member-portal/MemberPortal.js';
import { AndroidGuideModal } from './components/common/AndroidGuideModal.js';
import { SplashScreen } from './components/common/SplashScreen.js';
import { Member, Receipt } from './types/index.js';
import { RefreshCw } from 'lucide-react';

const AppContent: React.FC = () => {
  const { user, member, isAdmin, isStaff, isLoading } = useAuth();
  const { t } = useLanguage();

  const hasManagerAccess = isAdmin || isStaff;

  const [currentTab, setCurrentTab] = useState<string>('dashboard');
  const [selectedMemberId, setSelectedMemberId] = useState<string | null>(null);

  // Modals state
  const [isAddMemberOpen, setIsAddMemberOpen] = useState(false);
  const [isCashDepositOpen, setIsCashDepositOpen] = useState(false);
  const [cashDepositMemberId, setCashDepositMemberId] = useState<string | undefined>();
  const [cashDepositMonthYear, setCashDepositMonthYear] = useState<string | undefined>();

  const [isOnlinePaymentOpen, setIsOnlinePaymentOpen] = useState(false);
  const [onlinePayMemberId, setOnlinePayMemberId] = useState<string | undefined>();
  const [onlinePayMonthYear, setOnlinePayMonthYear] = useState<string | undefined>();

  const [isGenerateDuesOpen, setIsGenerateDuesOpen] = useState(false);
  const [activeReceipt, setActiveReceipt] = useState<Receipt | null>(null);
  const [isReceiptModalOpen, setIsReceiptModalOpen] = useState(false);

  const [isAndroidGuideOpen, setIsAndroidGuideOpen] = useState(false);

  // Loading initial session -> Show professional branded splash screen
  if (isLoading) {
    return <SplashScreen />;
  }

  // Not logged in -> Show Splash & Login screen
  if (!user) {
    return (
      <>
        <AuthScreen onOpenAndroidGuide={() => setIsAndroidGuideOpen(true)} />
        <AndroidGuideModal
          isOpen={isAndroidGuideOpen}
          onClose={() => setIsAndroidGuideOpen(false)}
        />
      </>
    );
  }

  const handleSelectMember = (memberId: string) => {
    setSelectedMemberId(memberId);
    setCurrentTab('member-details');
  };

  const handleOpenCashDeposit = (memberId?: string, monthYear?: string) => {
    setCashDepositMemberId(memberId);
    setCashDepositMonthYear(monthYear);
    setIsCashDepositOpen(true);
  };

  const handleOpenOnlinePayment = (memberId?: string, monthYear?: string) => {
    setOnlinePayMemberId(memberId);
    setOnlinePayMonthYear(monthYear);
    setIsOnlinePaymentOpen(true);
  };

  const handleViewReceipt = (rcp: Receipt) => {
    setActiveReceipt(rcp);
    setIsReceiptModalOpen(true);
  };

  const handlePaymentSuccess = (rcp: Receipt) => {
    setActiveReceipt(rcp);
    setIsReceiptModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-900 antialiased">
      {/* Top Navigation */}
      <Navbar
        currentTab={currentTab}
        setCurrentTab={(tab) => {
          if (tab === 'deposit') {
            handleOpenCashDeposit();
          } else {
            setCurrentTab(tab);
          }
        }}
        onOpenNotifications={() => setCurrentTab('notifications')}
        onOpenAndroidGuide={() => setIsAndroidGuideOpen(true)}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Manager (Admin or Staff) Navigation routes */}
        {hasManagerAccess && (
          <>
            {currentTab === 'dashboard' && (
              <AdminDashboard
                onNavigate={setCurrentTab}
                onOpenCashDeposit={() => handleOpenCashDeposit()}
                onOpenAddMember={() => setIsAddMemberOpen(true)}
                onViewReceipt={handleViewReceipt}
                onOpenGenerateDuesModal={() => setIsGenerateDuesOpen(true)}
              />
            )}

            {currentTab === 'members' && (
              <MemberList
                onSelectMember={handleSelectMember}
                onOpenAddMember={() => setIsAddMemberOpen(true)}
                onOpenCashDepositForMember={(mId) => handleOpenCashDeposit(mId)}
              />
            )}

            {currentTab === 'member-details' && selectedMemberId && (
              <MemberDetails
                memberId={selectedMemberId}
                onBack={() => setCurrentTab('members')}
                onOpenCashDeposit={handleOpenCashDeposit}
                onOpenOnlinePayment={handleOpenOnlinePayment}
                onViewReceipt={handleViewReceipt}
              />
            )}

            {currentTab === 'dues' && (
              <MonthlyDuesScreen
                onOpenCashDeposit={handleOpenCashDeposit}
                onOpenOnlinePayment={handleOpenOnlinePayment}
                onViewReceipt={handleViewReceipt}
                onOpenGenerateDuesModal={() => setIsGenerateDuesOpen(true)}
              />
            )}

            {currentTab === 'receipts' && (
              <ReceiptsListScreen onViewReceipt={handleViewReceipt} />
            )}

            {currentTab === 'reports' && <ReportsScreen />}

            {currentTab === 'notifications' && <NotificationsScreen />}

            {isAdmin && currentTab === 'settings' && <SettingsScreen />}
          </>
        )}

        {/* Regular Member Navigation routes */}
        {!hasManagerAccess && (
          <>
            {currentTab === 'member-portal' && (
              <MemberPortal
                onOpenOnlinePayment={handleOpenOnlinePayment}
                onViewReceipt={handleViewReceipt}
              />
            )}

            {currentTab === 'shared-members' && (
              <MemberList
                onSelectMember={handleSelectMember}
                onOpenAddMember={() => {}}
                onOpenCashDepositForMember={() => {}}
              />
            )}

            {currentTab === 'member-details' && selectedMemberId && (
              <MemberDetails
                memberId={selectedMemberId}
                onBack={() => setCurrentTab('shared-members')}
                onOpenCashDeposit={() => {}}
                onOpenOnlinePayment={handleOpenOnlinePayment}
                onViewReceipt={handleViewReceipt}
              />
            )}

            {currentTab === 'my-dues' && (
              <MonthlyDuesScreen
                onOpenCashDeposit={handleOpenCashDeposit}
                onOpenOnlinePayment={handleOpenOnlinePayment}
                onViewReceipt={handleViewReceipt}
                onOpenGenerateDuesModal={() => setIsGenerateDuesOpen(true)}
              />
            )}

            {currentTab === 'my-receipts' && (
              <ReceiptsListScreen onViewReceipt={handleViewReceipt} />
            )}

            {currentTab === 'notifications' && <NotificationsScreen />}
          </>
        )}
      </main>

      {/* Global Modals */}
      <AddMemberModal
        isOpen={isAddMemberOpen}
        onClose={() => setIsAddMemberOpen(false)}
        onMemberAdded={(newMem) => {
          setSelectedMemberId(newMem.memberId);
          setCurrentTab('member-details');
        }}
      />

      <CashDepositModal
        isOpen={isCashDepositOpen}
        onClose={() => setIsCashDepositOpen(false)}
        defaultMemberId={cashDepositMemberId}
        defaultMonthYear={cashDepositMonthYear}
        onPaymentSuccess={handlePaymentSuccess}
      />

      <OnlinePaymentModal
        isOpen={isOnlinePaymentOpen}
        onClose={() => setIsOnlinePaymentOpen(false)}
        memberId={onlinePayMemberId || member?.memberId || ''}
        monthYear={onlinePayMonthYear}
        onPaymentSuccess={handlePaymentSuccess}
      />

      <GenerateDuesModal
        isOpen={isGenerateDuesOpen}
        onClose={() => setIsGenerateDuesOpen(false)}
        onDuesGenerated={() => {
          // refresh tab
          setCurrentTab('dues');
        }}
      />

      <ReceiptModal
        isOpen={isReceiptModalOpen}
        receipt={activeReceipt}
        onClose={() => setIsReceiptModalOpen(false)}
      />

      <AndroidGuideModal
        isOpen={isAndroidGuideOpen}
        onClose={() => setIsAndroidGuideOpen(false)}
      />

      {/* Bottom Sticky Organization Footer */}
      <footer className="border-t border-slate-200 bg-white py-4 print:hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-2">
          <p>
            © 2026 {t.appName} • {t.orgAddress}
          </p>
          <div className="flex items-center gap-4">
            <span>Reg. No: MAH/KLM/1048/2022</span>
            <span>•</span>
            <span>मासिक वर्गणी: ₹१,०००</span>
            <span>•</span>
            <button
              onClick={() => setIsAndroidGuideOpen(true)}
              className="text-emerald-700 font-semibold hover:underline"
            >
              Android App Info
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </LanguageProvider>
  );
}
