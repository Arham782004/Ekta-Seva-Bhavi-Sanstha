import {
  User,
  Member,
  MonthlyDue,
  Payment,
  Receipt,
  AppNotification,
  AuditLog,
  OrganizationSettings,
  DashboardStats,
  MonthlyChartData,
  MemberAttendanceSummary,
  SansthaUpdate,
  SharedSansthaFinancials,
  SansthaExpense,
} from '../types/index.js';

const TOKEN_KEY = 'esbs_auth_token';

export const authStorage = {
  getToken: () => localStorage.getItem(TOKEN_KEY),
  setToken: (token: string) => localStorage.setItem(TOKEN_KEY, token),
  clearToken: () => localStorage.removeItem(TOKEN_KEY),
};

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = authStorage.getToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string>),
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(endpoint, {
    ...options,
    headers,
  });

  if (!response.ok) {
    let errorMsg = 'An error occurred';
    try {
      const errorData = await response.json();
      errorMsg = errorData.error || errorData.message || errorMsg;
    } catch {
      errorMsg = await response.text();
    }
    throw new Error(errorMsg);
  }

  return response.json();
}

export const api = {
  auth: {
    login: async (login: string, password: string) => {
      const res = await request<{
        token: string;
        user: User;
        member?: Member;
      }>('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ login, password }),
      });
      authStorage.setToken(res.token);
      return res;
    },
    register: (data: {
      fullName: string;
      mobile: string;
      email?: string;
      address?: string;
      notes?: string;
    }) =>
      request<{ success: boolean; message: string; memberId: string }>('/api/auth/register', {
        method: 'POST',
        body: JSON.stringify(data),
      }),
    me: () =>
      request<{
        user: User;
        member?: Member;
        settings: OrganizationSettings;
      }>('/api/auth/me'),
    changePassword: (data: { currentPassword: string; newPassword: string }) =>
      request<{ success: boolean; message: string }>('/api/auth/change-password', {
        method: 'POST',
        body: JSON.stringify(data),
      }),
    forgotPassword: (login: string) =>
      request<{ success: boolean; message: string }>('/api/auth/forgot-password', {
        method: 'POST',
        body: JSON.stringify({ login }),
      }),
    logout: () => {
      authStorage.clearToken();
    },
  },

  members: {
    getAll: (params?: { search?: string; status?: string }) => {
      const q = new URLSearchParams();
      if (params?.search) q.set('search', params.search);
      if (params?.status) q.set('status', params.status);
      return request<Member[]>(`/api/members?${q.toString()}`);
    },
    getById: (id: string) =>
      request<{
        member: Member;
        dues: MonthlyDue[];
        payments: Payment[];
        receipts: Receipt[];
        summary: {
          totalPaidPaise: number;
          outstandingBalancePaise: number;
          totalMonthsDues: number;
          paidMonthsCount: number;
        };
      }>(`/api/members/${id}`),
    create: (data: Partial<Member>) =>
      request<Member>('/api/members', {
        method: 'POST',
        body: JSON.stringify(data),
      }),
    update: (id: string, data: Partial<Member>) =>
      request<Member>(`/api/members/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data),
      }),
    setStatus: (id: string, status: Member['status']) =>
      request<Member>(`/api/members/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status }),
      }),
    getAttendance: (memberId: string) =>
      request<MemberAttendanceSummary[]>(`/api/members/${memberId}/attendance`),
  },

  dues: {
    getAll: (params?: { memberId?: string; monthYear?: string; status?: string }) => {
      const q = new URLSearchParams();
      if (params?.memberId) q.set('memberId', params.memberId);
      if (params?.monthYear) q.set('monthYear', params.monthYear);
      if (params?.status) q.set('status', params.status);
      return request<MonthlyDue[]>(`/api/dues?${q.toString()}`);
    },
    generate: (monthYear: string) =>
      request<{ success: boolean; message: string; generatedCount: number; alreadyExistingCount: number }>(
        '/api/dues/generate',
        {
          method: 'POST',
          body: JSON.stringify({ monthYear }),
        }
      ),
  },

  payments: {
    recordCash: (data: {
      memberId: string;
      monthYear: string;
      amountPaise: number;
      paymentDate?: string;
      receivedByAdminName?: string;
      notes?: string;
    }) =>
      request<{
        success: boolean;
        payment: Payment;
        receipt: Receipt;
        message: string;
      }>('/api/payments/cash', {
        method: 'POST',
        body: JSON.stringify(data),
      }),

    createOrder: (data: { memberId?: string; monthYear: string; amountPaise?: number }) =>
      request<{
        orderId: string;
        amountPaise: number;
        currency: string;
        keyId: string;
        orgName: string;
        description: string;
        member: { memberId: string; name: string; mobile: string; email?: string };
        isSandbox: boolean;
      }>('/api/payments/create-order', {
        method: 'POST',
        body: JSON.stringify(data),
      }),

    verifyPayment: (data: {
      memberId?: string;
      monthYear: string;
      amountPaise: number;
      orderId: string;
      paymentId: string;
      signature: string;
    }) =>
      request<{
        success: boolean;
        verified: boolean;
        payment: Payment;
        receipt: Receipt;
        message: string;
      }>('/api/payments/verify', {
        method: 'POST',
        body: JSON.stringify(data),
      }),

    reverse: (paymentId: string, reason: string) =>
      request<{ success: boolean; message: string; payment: Payment }>(`/api/payments/${paymentId}/reverse`, {
        method: 'POST',
        body: JSON.stringify({ reason }),
      }),

    getAll: (params?: { memberId?: string }) => {
      const q = new URLSearchParams();
      if (params?.memberId) q.set('memberId', params.memberId);
      return request<Payment[]>(`/api/payments?${q.toString()}`);
    },
  },

  receipts: {
    getAll: (params?: { memberId?: string }) => {
      const q = new URLSearchParams();
      if (params?.memberId) q.set('memberId', params.memberId);
      return request<Receipt[]>(`/api/receipts?${q.toString()}`);
    },
    getById: (id: string) => request<Receipt>(`/api/receipts/${id}`),
  },

  updates: {
    getAll: () => request<SansthaUpdate[]>('/api/updates'),
    create: (data: Partial<SansthaUpdate>) =>
      request<SansthaUpdate>('/api/updates', {
        method: 'POST',
        body: JSON.stringify(data),
      }),
    update: (id: string, data: Partial<SansthaUpdate>) =>
      request<SansthaUpdate>(`/api/updates/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data),
      }),
    delete: (id: string) =>
      request<{ success: boolean; message: string }>(`/api/updates/${id}`, {
        method: 'DELETE',
      }),
  },

  financials: {
    getShared: () => request<SharedSansthaFinancials>('/api/financials/shared'),
  },

  expenses: {
    getAll: () => request<SansthaExpense[]>('/api/expenses'),
    create: (data: Partial<SansthaExpense>) =>
      request<SansthaExpense>('/api/expenses', {
        method: 'POST',
        body: JSON.stringify(data),
      }),
    delete: (id: string) =>
      request<{ success: boolean }>(`/api/expenses/${id}`, {
        method: 'DELETE',
      }),
  },

  reports: {
    getDashboard: () =>
      request<{
        stats: DashboardStats;
        trends: MonthlyChartData[];
        recentPayments: Payment[];
      }>('/api/reports/dashboard'),
    getExportCsvUrl: () => '/api/reports/export-csv',
  },

  notifications: {
    getAll: () => request<AppNotification[]>('/api/notifications'),
    markRead: (id: string) =>
      request<{ success: boolean }>(`/api/notifications/${id}/read`, { method: 'PATCH' }),
    markAllRead: () =>
      request<{ success: boolean }>('/api/notifications/read-all', { method: 'POST' }),
    sendAnnouncement: (data: { title: string; message: string }) =>
      request<{ success: boolean; notification: AppNotification }>('/api/notifications/announcement', {
        method: 'POST',
        body: JSON.stringify(data),
      }),
  },

  settings: {
    get: () => request<OrganizationSettings>('/api/settings'),
    update: (data: Partial<OrganizationSettings>) =>
      request<OrganizationSettings>('/api/settings', {
        method: 'PUT',
        body: JSON.stringify(data),
      }),
    getAuditLogs: () => request<AuditLog[]>('/api/settings/audit-logs'),
  },

  admin: {
    getStaffUsers: () => request<User[]>('/api/admin/staff-users'),
    createStaffUser: (data: {
      email: string;
      mobile: string;
      name: string;
      password?: string;
      permissions?: any;
    }) =>
      request<User>('/api/admin/staff-users', {
        method: 'POST',
        body: JSON.stringify(data),
      }),
    updateStaffUser: (
      id: string,
      data: {
        name?: string;
        mobile?: string;
        email?: string;
        status?: 'active' | 'suspended';
        permissions?: any;
      }
    ) =>
      request<User>(`/api/admin/staff-users/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data),
      }),
    resetStaffPassword: (id: string, newPassword: string) =>
      request<{ success: boolean; message: string }>(`/api/admin/staff-users/${id}/reset-password`, {
        method: 'POST',
        body: JSON.stringify({ newPassword }),
      }),
    getBackupUrl: () => '/api/admin/backup',
    getMembersCsvUrl: () => '/api/reports/export-members-csv',
  },
};
