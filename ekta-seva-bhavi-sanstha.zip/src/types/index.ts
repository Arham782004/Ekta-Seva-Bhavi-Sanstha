export type UserRole = 'admin' | 'staff' | 'member';

export interface StaffPermissions {
  canManageMembers?: boolean;
  canCollectPayments?: boolean;
  canViewReports?: boolean;
  canSendNotifications?: boolean;
  canGenerateDues?: boolean;
}

export interface User {
  id: string;
  email: string;
  mobile: string;
  name: string;
  role: UserRole;
  passwordHash: string;
  salt: string;
  memberId?: string | null;
  status: 'active' | 'suspended';
  permissions?: StaffPermissions;
  createdAt: string;
  updatedAt: string;
}

export type MemberStatus = 'active' | 'inactive' | 'pending_approval';

export interface Member {
  id: string;
  memberId: string; // e.g. M001, M002
  fullName: string;
  mobile: string;
  email?: string;
  address?: string;
  joiningDate: string; // YYYY-MM-DD
  monthlyContributionPaise: number; // e.g. 100000 = ₹1000
  status: MemberStatus;
  notes?: string;
  userId?: string | null;
  totalDuePaise?: number;
  totalPaidPaise?: number;
  remainingBalancePaise?: number;
  paidMonthsCount?: number;
  createdAt: string;
  updatedAt: string;
}

export type DueStatus = 'unpaid' | 'partially_paid' | 'paid' | 'overdue' | 'waived';

export interface MonthlyDue {
  id: string;
  memberId: string; // references Member.memberId
  monthYear: string; // YYYY-MM
  monthLabel: string; // e.g. "October 2026"
  amountDuePaise: number;
  amountPaidPaise: number;
  remainingPaise: number;
  dueDate: string; // YYYY-MM-DD
  status: DueStatus;
  lastPaymentDate?: string | null;
  createdAt: string;
  updatedAt: string;
}

export type PaymentMethod = 'cash' | 'online_upi' | 'bank_transfer';
export type PaymentStatus = 'verified' | 'pending' | 'failed' | 'reversed';

export interface Payment {
  id: string;
  receiptNumber: string;
  memberId: string;
  memberName: string;
  dueId?: string | null;
  monthYear: string;
  amountPaise: number;
  paymentMethod: PaymentMethod;
  paymentDate: string;
  status: PaymentStatus;
  receivedByAdminName: string;
  notes?: string;
  gatewayOrderId?: string | null;
  gatewayPaymentId?: string | null;
  gatewaySignature?: string | null;
  reversedAt?: string | null;
  reversalReason?: string | null;
  createdAt: string;
}

export interface Receipt {
  id: string;
  receiptNumber: string;
  paymentId: string;
  memberId: string;
  memberName: string;
  memberMobile: string;
  monthYear: string;
  monthLabel: string;
  amountPaise: number;
  amountInWords: string;
  paymentMethod: PaymentMethod;
  paymentDate: string;
  transactionRef: string;
  remainingBalancePaise: number;
  issuedBy: string;
  status: 'verified' | 'reversed';
  organizationName: string;
  organizationAddress: string;
  createdAt: string;
}

export type NotificationType =
  | 'payment_cash'
  | 'payment_online'
  | 'payment_failed'
  | 'due_reminder'
  | 'overdue_alert'
  | 'member_registered'
  | 'member_approved'
  | 'announcement'
  | 'reversal';

export interface AppNotification {
  id: string;
  targetUserId?: string | null; // null = all users
  memberId?: string | null;
  type: NotificationType;
  title: string;
  message: string;
  isRead: boolean;
  createdAt: string;
}

export interface AuditLog {
  id: string;
  actorId: string;
  actorName: string;
  action: string;
  details: string;
  ipAddress?: string;
  timestamp: string;
}

export interface OrganizationSettings {
  orgName: string;
  marathiName: string;
  hindiName: string;
  address: string;
  registrationNumber: string;
  contactPhone: string;
  contactEmail: string;
  presidentName?: string;
  appSubtitle?: string;
  customLogoUrl?: string;
  themePrimaryColor?: string;
  themeSecondaryColor?: string;
  themeAccentColor?: string;

  // Login & Security
  allowStaffLogin?: boolean;
  allowMemberLogin?: boolean;
  sessionTimeoutMinutes?: number;
  requirePasswordMinLength?: number;
  maxFailedLoginAttempts?: number;

  // Member Management
  memberIdPrefix?: string;
  memberIdDigits?: number;
  autoAssignMemberId?: boolean;
  requireEmailForMembers?: boolean;
  requireAddressForMembers?: boolean;

  // Payment & Receipts
  standardContributionPaise: number;
  dueDayOfMonth: number;
  enableCashPayments?: boolean;
  enableUpiPayments?: boolean;
  enableBankTransfer?: boolean;
  upiId: string;
  razorpayKeyId: string;
  razorpayKeySecret: string;
  razorpayWebhookSecret: string;
  isSandbox: boolean;
  bankName?: string;
  bankAccountNumber?: string;
  bankIfsc?: string;
  receiptPrefix: string;
  receiptStartNumber?: number;
  receiptFooterNote?: string;
  receiptIssuedBy?: string;
  receiptPresidentName?: string;

  // Notifications
  enablePaymentReminders?: boolean;
  reminderDaysBeforeDue?: number;
  enablePaymentConfirmationSms?: boolean;
  enableOverdueAlerts?: boolean;
  enableAdminPaymentAlerts?: boolean;

  // Appearance & Language
  defaultLanguage: 'hi' | 'mr' | 'en';
  showFinancialSummaryToMembers?: boolean;
}

export type SansthaUpdateCategory = 'announcement' | 'meeting' | 'activity' | 'notice' | 'event';

export interface AttendanceItem {
  memberId: string;
  memberName: string;
  status: 'present' | 'absent' | 'excused';
}

export interface SansthaUpdate {
  id: string;
  title: string;
  content: string;
  category: SansthaUpdateCategory;
  date: string; // YYYY-MM-DD
  time?: string; // e.g. 17:30
  venue?: string;
  isImportant?: boolean;
  isPublished: boolean;
  authorId: string;
  authorName: string;
  attendance?: AttendanceItem[];
  attendanceSummary?: {
    totalInvited: number;
    presentCount: number;
    absentCount: number;
  };
  createdAt: string;
  updatedAt: string;
}

export interface SansthaExpense {
  id: string;
  title: string;
  category: 'welfare' | 'event' | 'office' | 'maintenance' | 'aid' | 'other';
  amountPaise: number;
  expenseDate: string; // YYYY-MM-DD
  receiptVoucherNo?: string;
  recordedByAdminId: string;
  recordedByAdminName: string;
  isVerified: boolean;
  notes?: string;
  createdAt: string;
}

export interface SharedSansthaFinancials {
  isAuthorized: boolean;
  totalContributionsPaise: number;
  totalExpensesPaise: number;
  remainingBalancePaise: number;
  thisMonthCollectionPaise: number;
  thisMonthExpensesPaise: number;
  verifiedExpensesCount: number;
  verifiedCollectionsCount: number;
  lastUpdated: string;
}

export interface MemberAttendanceSummary {
  meetingId: string;
  meetingTitle: string;
  date: string;
  venue?: string;
  status: 'present' | 'absent' | 'excused';
}

export interface DashboardStats {
  totalMembers: number;
  activeMembers: number;
  pendingApprovals: number;
  overdueMembers: number;
  totalVerifiedCollectionPaise: number;
  cashCollectionPaise: number;
  onlineCollectionPaise: number;
  pendingMonthlyDuesPaise: number;
  overdueDuesCount: number;
  thisMonthCollectionPaise: number;
  thisMonthTargetPaise: number;
}

export interface MonthlyChartData {
  monthYear: string;
  monthLabel: string;
  cashPaise: number;
  onlinePaise: number;
  totalPaise: number;
}
