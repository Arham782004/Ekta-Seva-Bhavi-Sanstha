import React, { useState, useEffect } from 'react';
import { useLanguage } from '../../context/LanguageContext.js';
import { useAuth } from '../../context/AuthContext.js';
import { api } from '../../services/api.js';
import {
  Member,
  MonthlyDue,
  Payment,
  Receipt,
  SansthaUpdate,
  SharedSansthaFinancials,
  MemberAttendanceSummary,
} from '../../types/index.js';
import { formatINR, formatDate, formatDateTime } from '../../utils/formatters.js';
import { generateReceiptPdf } from '../../utils/pdfReceipt.js';
import { SansthaLogo } from '../common/SansthaLogo.js';
import { SharedFinancialCard } from '../updates/SharedFinancialCard.js';
import { SansthaUpdatesSection } from '../updates/SansthaUpdatesSection.js';
import { ManageUpdateModal } from '../updates/ManageUpdateModal.js';
import {
  Wallet,
  Clock,
  CheckCircle,
  AlertCircle,
  CreditCard,
  Download,
  Eye,
  Calendar,
  FileText,
  RefreshCw,
  Sparkles,
  Users,
  CheckCircle2,
  XCircle,
} from 'lucide-react';

interface MemberPortalProps {
  onOpenOnlinePayment: (memberId: string, monthYear: string) => void;
  onViewReceipt: (receipt: Receipt) => void;
}

export const MemberPortal: React.FC<MemberPortalProps> = ({
  onOpenOnlinePayment,
  onViewReceipt,
}) => {
  const { t, language } = useLanguage();
  const { user, member, isAdmin } = useAuth();

  const [memberData, setMemberData] = useState<{
    member: Member;
    dues: MonthlyDue[];
    payments: Payment[];
    receipts: Receipt[];
    summary: {
      totalPaidPaise: number;
      outstandingBalancePaise: number;
      totalMonthsDues: number;
      paidMonthsCount: number;
    };
  } | null>(null);

  const [updates, setUpdates] = useState<SansthaUpdate[]>([]);
  const [financials, setFinancials] = useState<SharedSansthaFinancials | null>(null);
  const [attendanceHistory, setAttendanceHistory] = useState<MemberAttendanceSummary[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [lastSyncTime, setLastSyncTime] = useState<Date>(new Date());

  // Admin update modal state
  const [isUpdateModalOpen, setIsUpdateModalOpen] = useState(false);
  const [selectedUpdateToEdit, setSelectedUpdateToEdit] = useState<SansthaUpdate | null>(null);

  const fetchLiveSansthaData = async (silent = false) => {
    if (!silent) setIsLoading(true);
    else setIsRefreshing(true);

    try {
      // 1. Fetch live updates
      const updatesPromise = api.updates.getAll();
      // 2. Fetch shared institutional financials
      const financialsPromise = api.financials.getShared();

      // 3. Fetch personal member data if memberId present
      const memberId = member?.memberId || user?.memberId;
      const memberPromise = memberId ? api.members.getById(memberId) : Promise.resolve(null);
      const attendancePromise = memberId ? api.members.getAttendance(memberId) : Promise.resolve([]);

      const [updatesRes, financialsRes, memberRes, attendanceRes] = await Promise.all([
        updatesPromise,
        financialsPromise,
        memberPromise,
        attendancePromise,
      ]);

      setUpdates(updatesRes);
      setFinancials(financialsRes);
      if (memberRes) setMemberData(memberRes);
      if (attendanceRes) setAttendanceHistory(attendanceRes);
      setLastSyncTime(new Date());
    } catch (err) {
      console.error('Error fetching live portal data:', err);
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    fetchLiveSansthaData(false);

    // Auto-refresh every 12 seconds so members see real-time updates across devices
    const interval = setInterval(() => {
      fetchLiveSansthaData(true);
    }, 12000);

    return () => clearInterval(interval);
  }, [member?.memberId, user?.memberId]);

  if (isLoading && !memberData && updates.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] gap-3">
        <RefreshCw className="w-8 h-8 text-blue-700 animate-spin" />
        <p className="text-xs text-slate-500 font-semibold">
          {language === 'mr' ? 'संस्था माहिती लोड होत आहे...' : 'Loading live Sanstha dashboard...'}
        </p>
      </div>
    );
  }

  const currentMember = memberData?.member || member;
  const dues = memberData?.dues || [];
  const receipts = memberData?.receipts || [];
  const summary = memberData?.summary || {
    totalPaidPaise: 0,
    outstandingBalancePaise: 0,
    totalMonthsDues: 0,
    paidMonthsCount: 0,
  };

  const currentMonthKey = new Date().toISOString().slice(0, 7);
  const currentMonthDue = dues.find((d) => d.monthYear === currentMonthKey);

  return (
    <div className="space-y-6">
      {/* 1. Welcome Banner */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-blue-800 text-white rounded-3xl p-6 sm:p-8 shadow-lg relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="p-1 bg-white/10 rounded-2xl backdrop-blur-xs border border-white/15 shadow-md flex-shrink-0">
              <SansthaLogo size="lg" light={true} />
            </div>
            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-700/60 text-blue-100 text-xs font-semibold mb-1">
                <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                <span>
                  {language === 'mr' ? 'सभासद थेट पोर्टल (Live Sanstha Hub)' : 'Member Live Portal'}
                </span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
                नमस्ते, {currentMember?.fullName || user?.name}
              </h1>
              <p className="text-xs sm:text-sm text-blue-200 mt-0.5">
                सदस्य आयडी: <span className="font-mono font-bold text-amber-300">{currentMember?.memberId || 'ESBS'}</span> • एकता सेवा भावी संस्था, माळी गल्ली, कळमनुरी
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-start md:self-auto">
            {currentMonthDue && currentMonthDue.remainingPaise > 0 && currentMember?.memberId && (
              <button
                onClick={() => onOpenOnlinePayment(currentMember.memberId, currentMonthDue.monthYear)}
                className="px-5 py-3 bg-teal-500 hover:bg-teal-600 text-slate-950 font-black text-xs sm:text-sm rounded-2xl shadow-lg transition-all flex items-center gap-2 cursor-pointer"
              >
                <CreditCard className="w-5 h-5 text-teal-950" />
                <span>चालू महिन्याचा हप्ता भरा ({formatINR(currentMonthDue.remainingPaise)})</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* 2. Institutional Shared Financial Summary (Requirement 3: Institutional collections, expenses & balance) */}
      <SharedFinancialCard
        financials={financials}
        isLoading={isRefreshing}
        onRefresh={() => fetchLiveSansthaData(true)}
      />

      {/* 3. Sanstha Updates, Meetings & Completed Activities (Requirement 1, 2, 5, 6, 7) */}
      <SansthaUpdatesSection
        updates={updates}
        isLoading={isRefreshing}
        onRefresh={() => fetchLiveSansthaData(true)}
        onOpenAddUpdate={() => {
          setSelectedUpdateToEdit(null);
          setIsUpdateModalOpen(true);
        }}
        onEditUpdate={(u) => {
          setSelectedUpdateToEdit(u);
          setIsUpdateModalOpen(true);
        }}
        lastSyncTime={lastSyncTime}
      />

      {/* 4. Member Personal Ledger & Financial Status (Requirement 4: Detailed personal dues & payment history) */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-extrabold text-blue-950 flex items-center gap-2">
            <Wallet className="w-5 h-5 text-blue-800" />
            <span>{language === 'mr' ? 'माझे वैयक्तिक खाते व हप्ता विवरण' : 'My Personal Ledger & Dues'}</span>
          </h2>
          <span className="text-xs text-slate-500 font-medium">
            सदस्य: {currentMember?.memberId}
          </span>
        </div>

        {/* 3 Personal KPI Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {/* Total Contributed */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
            <div className="flex items-center justify-between text-slate-500 mb-2">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-600">
                {t.myContributions}
              </span>
              <div className="p-2 bg-emerald-50 text-emerald-700 rounded-xl">
                <Wallet className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl font-black text-emerald-800">
              {formatINR(summary.totalPaidPaise)}
            </div>
            <div className="text-[11px] text-emerald-600 font-semibold mt-1">
              {summary.paidMonthsCount} महिने यशस्वीरित्या जमा
            </div>
          </div>

          {/* Current Month Due Status */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
            <div className="flex items-center justify-between text-slate-500 mb-2">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-600">
                {t.currentMonthStatus}
              </span>
              <div className="p-2 bg-blue-50 text-blue-700 rounded-xl">
                <Calendar className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl font-black text-blue-950">
              {currentMonthDue ? (
                currentMonthDue.remainingPaise === 0 ? (
                  <span className="text-emerald-700">पूर्ण भरलेला ✓</span>
                ) : (
                  <span className="text-amber-600">{formatINR(currentMonthDue.remainingPaise)} बाकी</span>
                )
              ) : (
                'हप्ता तयार झालेला नाही'
              )}
            </div>
            <div className="text-[11px] text-slate-500 mt-1">
              {currentMonthDue?.monthLabel || 'Current Month'}
            </div>
          </div>

          {/* Outstanding Total Balance */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
            <div className="flex items-center justify-between text-slate-500 mb-2">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-600">
                {t.outstandingBalance}
              </span>
              <div className="p-2 bg-rose-50 text-rose-700 rounded-xl">
                <AlertCircle className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl font-black text-rose-800">
              {formatINR(summary.outstandingBalancePaise)}
            </div>
            <div className="text-[11px] text-rose-600 font-semibold mt-1">
              {summary.outstandingBalancePaise === 0 ? 'कोणतीही थकबाकी नाही' : 'कृपया वेळेत जमा करा'}
            </div>
          </div>
        </div>
      </div>

      {/* 5. Personal Meeting Attendance Record (Requirement 4: Member attendance history) */}
      {attendanceHistory.length > 0 && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-extrabold text-blue-950 flex items-center gap-2">
              <Users className="w-4 h-4 text-blue-700" />
              <span>{language === 'mr' ? 'माझी बैठकांमधील उपस्थिती नोंद' : 'My Meeting Attendance History'}</span>
            </h3>
            <span className="text-xs text-slate-500 font-medium">
              {attendanceHistory.filter((a) => a.status === 'present').length} / {attendanceHistory.length} {language === 'mr' ? 'उपस्थित' : 'Attended'}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {attendanceHistory.map((att) => (
              <div
                key={att.meetingId}
                className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs"
              >
                <div>
                  <h4 className="font-bold text-slate-900 truncate max-w-[180px]">{att.meetingTitle}</h4>
                  <p className="text-[11px] text-slate-500 mt-0.5">{formatDate(att.date)}</p>
                </div>

                {att.status === 'present' ? (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    <span>उपस्थित</span>
                  </span>
                ) : att.status === 'excused' ? (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800">
                    <span>रजेवर</span>
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800">
                    <XCircle className="w-3 h-3 text-rose-600" />
                    <span>अनुपस्थित</span>
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 6. Monthly Dues & Receipts Table (Requirement 4: Payment history, receipts, PDF) */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
        <h2 className="text-base font-extrabold text-blue-950 mb-4 flex items-center gap-2">
          <FileText className="w-5 h-5 text-blue-800" />
          <span>{t.myDues} व अधिकृत पावत्या</span>
        </h2>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase font-bold tracking-wider">
                <th className="py-3 px-4">{t.monthYear}</th>
                <th className="py-3 px-4">{t.amountDue}</th>
                <th className="py-3 px-4">{t.amountPaid}</th>
                <th className="py-3 px-4">{t.remainingAmount}</th>
                <th className="py-3 px-4">{t.dueDate}</th>
                <th className="py-3 px-4">{t.status}</th>
                <th className="py-3 px-4 text-right">{t.actions}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {dues.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400">
                    अद्याप हप्ते नोंदवलेले नाहीत
                  </td>
                </tr>
              ) : (
                dues.map((d) => {
                  const matchingReceipt = receipts.find((r) => r.monthYear === d.monthYear);
                  return (
                    <tr key={d.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3.5 px-4 font-bold text-blue-950">
                        {d.monthLabel || d.monthYear}
                      </td>
                      <td className="py-3.5 px-4 text-slate-700">
                        {formatINR(d.amountDuePaise)}
                      </td>
                      <td className="py-3.5 px-4 font-bold text-emerald-700">
                        {formatINR(d.amountPaidPaise)}
                      </td>
                      <td className="py-3.5 px-4 font-bold text-rose-700">
                        {formatINR(d.remainingPaise)}
                      </td>
                      <td className="py-3.5 px-4 text-slate-500">
                        {formatDate(d.dueDate)}
                      </td>
                      <td className="py-3.5 px-4">
                        {d.status === 'paid' && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                            <CheckCircle className="w-3 h-3" />
                            <span>{t.paid}</span>
                          </span>
                        )}
                        {d.status === 'partially_paid' && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800">
                            <Clock className="w-3 h-3" />
                            <span>{t.partiallyPaid}</span>
                          </span>
                        )}
                        {d.status === 'unpaid' && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800">
                            <AlertCircle className="w-3 h-3" />
                            <span>{t.unpaid}</span>
                          </span>
                        )}
                        {d.status === 'overdue' && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-200 text-rose-950">
                            <AlertCircle className="w-3 h-3" />
                            <span>{t.overdue}</span>
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {matchingReceipt ? (
                            <>
                              <button
                                onClick={() => onViewReceipt(matchingReceipt)}
                                className="px-2.5 py-1 text-[11px] font-bold text-blue-800 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors inline-flex items-center gap-1 cursor-pointer"
                              >
                                <Eye className="w-3 h-3" />
                                <span>पावती</span>
                              </button>
                              <button
                                onClick={() => generateReceiptPdf(matchingReceipt)}
                                className="p-1 text-slate-500 hover:text-blue-900 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
                                title="Download PDF"
                              >
                                <Download className="w-3.5 h-3.5" />
                              </button>
                            </>
                          ) : d.remainingPaise > 0 && currentMember?.memberId ? (
                            <button
                              onClick={() => onOpenOnlinePayment(currentMember.memberId, d.monthYear)}
                              className="px-3 py-1 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-lg shadow-2xs transition-all flex items-center gap-1 cursor-pointer"
                            >
                              <CreditCard className="w-3 h-3" />
                              <span>{t.payNow}</span>
                            </button>
                          ) : null}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Admin Manage Update Modal */}
      {isAdmin && (
        <ManageUpdateModal
          isOpen={isUpdateModalOpen}
          onClose={() => setIsUpdateModalOpen(false)}
          onSaved={() => fetchLiveSansthaData(true)}
          updateToEdit={selectedUpdateToEdit}
        />
      )}
    </div>
  );
};
