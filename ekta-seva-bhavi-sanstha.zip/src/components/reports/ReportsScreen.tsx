import React, { useState, useEffect } from 'react';
import { useLanguage } from '../../context/LanguageContext.js';
import { api } from '../../services/api.js';
import { DashboardStats, MonthlyChartData, Payment } from '../../types/index.js';
import { formatINR, formatDate } from '../../utils/formatters.js';
import {
  FileText,
  Download,
  Printer,
  Calendar,
  Wallet,
  Banknote,
  Smartphone,
  TrendingUp,
  RefreshCw,
  Users,
  CheckCircle,
  AlertTriangle,
} from 'lucide-react';

export const ReportsScreen: React.FC = () => {
  const { t } = useLanguage();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [trends, setTrends] = useState<MonthlyChartData[]>([]);
  const [recentPayments, setRecentPayments] = useState<Payment[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const data = await api.reports.getDashboard();
      setStats(data.stats);
      setTrends(data.trends);
      setRecentPayments(data.recentPayments);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handlePrint = () => {
    window.print();
  };

  const handleExportCsv = () => {
    window.open(api.reports.getExportCsvUrl(), '_blank');
  };

  const maxVal = trends.reduce((max, t) => Math.max(max, t.totalPaise), 100000);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4 print:border-none print:shadow-none">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-blue-950">
            {t.collectionReportsTitle}
          </h1>
          <p className="text-xs text-slate-500">
            एकता सेवा भावी संस्था, माळी गल्ली, कळमनुरी • सर्वंकष आर्थिक वसुली व विश्लेषण
          </p>
        </div>

        <div className="flex items-center gap-2 print:hidden">
          <button
            onClick={handleExportCsv}
            className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl transition-colors flex items-center gap-1.5 shadow-2xs cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>{t.exportCsv}</span>
          </button>
          <button
            onClick={handlePrint}
            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>{t.printReport}</span>
          </button>
        </div>
      </div>

      {/* Primary KPI Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-600">
              {t.totalVerifiedCollection}
            </span>
            <Wallet className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-black text-emerald-800">
            {formatINR(stats?.totalVerifiedCollectionPaise || 0)}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            १००% पडताळलेली खात्रीशीर जमा
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-600">
              {t.cashCollectionTotal}
            </span>
            <Banknote className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-black text-amber-800">
            {formatINR(stats?.cashCollectionPaise || 0)}
          </div>
          <div className="text-[11px] text-amber-600 font-semibold mt-1">
            संस्था कार्यालयात रोखीने जमा
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-600">
              {t.onlineCollectionTotal}
            </span>
            <Smartphone className="w-4 h-4 text-teal-600" />
          </div>
          <div className="text-2xl font-black text-teal-800">
            {formatINR(stats?.onlineCollectionPaise || 0)}
          </div>
          <div className="text-[11px] text-teal-600 font-semibold mt-1">
            ऑनलाइन UPI द्वारे पडताळलेले
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-600">
              {t.pendingMonthlyPayments}
            </span>
            <AlertTriangle className="w-4 h-4 text-rose-600" />
          </div>
          <div className="text-2xl font-black text-rose-800">
            {formatINR(stats?.pendingMonthlyDuesPaise || 0)}
          </div>
          <div className="text-[11px] text-rose-600 font-semibold mt-1">
            {stats?.overdueMembers || 0} सदस्यांची बाकी
          </div>
        </div>
      </div>

      {/* Month-by-Month Analytics Table */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
        <h2 className="text-base font-extrabold text-blue-950 mb-4 flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-blue-700" />
          <span>{t.summaryByMonth}</span>
        </h2>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase font-bold tracking-wider">
                <th className="py-3 px-4">{t.monthYear}</th>
                <th className="py-3 px-4">रोख जमा (Cash)</th>
                <th className="py-3 px-4">ऑनलाइन जमा (UPI)</th>
                <th className="py-3 px-4">एकूण जमा (Total)</th>
                <th className="py-3 px-4">प्रमाण (Share)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {trends.map((row) => {
                const total = row.totalPaise || 1;
                const cashPercent = Math.round((row.cashPaise / total) * 100);
                const onlinePercent = 100 - cashPercent;

                return (
                  <tr key={row.monthYear} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-4 font-bold text-blue-950">
                      {row.monthLabel} ({row.monthYear})
                    </td>
                    <td className="py-3.5 px-4 font-bold text-amber-800">
                      {formatINR(row.cashPaise)}
                    </td>
                    <td className="py-3.5 px-4 font-bold text-teal-800">
                      {formatINR(row.onlinePaise)}
                    </td>
                    <td className="py-3.5 px-4 font-black text-emerald-800">
                      {formatINR(row.totalPaise)}
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="w-32 h-2.5 bg-slate-100 rounded-full overflow-hidden flex">
                        <div
                          style={{ width: `${cashPercent}%` }}
                          className="bg-amber-500"
                          title={`Cash: ${cashPercent}%`}
                        />
                        <div
                          style={{ width: `${onlinePercent}%` }}
                          className="bg-teal-600"
                          title={`UPI: ${onlinePercent}%`}
                        />
                      </div>
                      <span className="text-[10px] text-slate-400 mt-0.5 block">
                        रोख: {cashPercent}% | UPI: {onlinePercent}%
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
