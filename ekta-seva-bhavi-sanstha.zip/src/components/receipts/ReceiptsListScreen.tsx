import React, { useState, useEffect } from 'react';
import { useLanguage } from '../../context/LanguageContext.js';
import { useAuth } from '../../context/AuthContext.js';
import { api } from '../../services/api.js';
import { Receipt } from '../../types/index.js';
import { formatINR, formatDateTime } from '../../utils/formatters.js';
import { generateReceiptPdf } from '../../utils/pdfReceipt.js';
import {
  FileCheck,
  Search,
  Download,
  Eye,
  CheckCircle,
  RefreshCw,
  Printer,
} from 'lucide-react';

interface ReceiptsListScreenProps {
  onViewReceipt: (receipt: Receipt) => void;
}

export const ReceiptsListScreen: React.FC<ReceiptsListScreenProps> = ({
  onViewReceipt,
}) => {
  const { t } = useLanguage();
  const { isAdmin, member } = useAuth();
  const [receipts, setReceipts] = useState<Receipt[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  const fetchReceipts = async () => {
    setIsLoading(true);
    try {
      const data = await api.receipts.getAll({
        memberId: !isAdmin && member ? member.memberId : undefined,
      });
      setReceipts(data);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchReceipts();
  }, [isAdmin, member]);

  const filteredReceipts = receipts.filter((r) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      r.receiptNumber.toLowerCase().includes(q) ||
      r.memberName.toLowerCase().includes(q) ||
      r.memberId.toLowerCase().includes(q) ||
      r.monthYear.includes(q)
    );
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-blue-950">
            {t.receiptTitle} (Receipts Archive)
          </h1>
          <p className="text-xs text-slate-500">
            सर्व अधिकृत, पडताळलेल्या वर्गणी पावत्यांची नोंदवही व PDF डाउनलोड
          </p>
        </div>

        {/* Search */}
        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t.searchReceipts}
            className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600"
          />
        </div>
      </div>

      {/* Receipts Table */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase font-bold tracking-wider">
                <th className="py-3 px-4">{t.receiptNumber}</th>
                <th className="py-3 px-4">{t.memberId} व नाव</th>
                <th className="py-3 px-4">{t.monthYear}</th>
                <th className="py-3 px-4">{t.amount}</th>
                <th className="py-3 px-4">{t.method}</th>
                <th className="py-3 px-4">{t.date}</th>
                <th className="py-3 px-4">{t.status}</th>
                <th className="py-3 px-4 text-right">{t.actions}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {filteredReceipts.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-400">
                    कोणत्याही पावत्या आढळल्या नाहीत
                  </td>
                </tr>
              ) : (
                filteredReceipts.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-4 font-mono font-black text-blue-900">
                      {r.receiptNumber}
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-900">{r.memberName}</div>
                      <div className="text-[10px] text-slate-400 font-mono">{r.memberId}</div>
                    </td>
                    <td className="py-3.5 px-4 font-bold text-blue-950">
                      {r.monthLabel || r.monthYear}
                    </td>
                    <td className="py-3.5 px-4 font-black text-emerald-700">
                      {formatINR(r.amountPaise)}
                    </td>
                    <td className="py-3.5 px-4">
                      <span
                        className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold ${
                          r.paymentMethod === 'cash'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-teal-100 text-teal-800'
                        }`}
                      >
                        {r.paymentMethod === 'cash' ? 'रोख (Cash)' : 'ऑनलाइन (UPI)'}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-slate-500">
                      {formatDateTime(r.paymentDate)}
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                        <CheckCircle className="w-3 h-3" />
                        <span>पडताळलेले</span>
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => onViewReceipt(r)}
                          className="px-2.5 py-1 text-[11px] font-bold text-blue-800 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors inline-flex items-center gap-1 cursor-pointer"
                          title="View"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>पहा</span>
                        </button>
                        <button
                          onClick={() => generateReceiptPdf(r)}
                          className="p-1 text-slate-500 hover:text-blue-900 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                          title="Download PDF"
                        >
                          <Download className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
