import React from 'react';
import { useLanguage } from '../../context/LanguageContext.js';
import { Receipt } from '../../types/index.js';
import { formatINR, formatDateTime } from '../../utils/formatters.js';
import { generateReceiptPdf } from '../../utils/pdfReceipt.js';
import { SansthaLogo } from '../common/SansthaLogo.js';
import {
  X,
  Download,
  Printer,
  CheckCircle,
  Share2,
  AlertCircle,
  Stamp,
} from 'lucide-react';

interface ReceiptModalProps {
  receipt: Receipt | null;
  isOpen: boolean;
  onClose: () => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({
  receipt,
  isOpen,
  onClose,
}) => {
  const { t } = useLanguage();

  if (!isOpen || !receipt) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadPdf = () => {
    generateReceiptPdf(receipt);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 relative my-8 print:m-0 print:p-0 print:border-none print:shadow-none">
        {/* Close Button (Hidden on Print) */}
        <button
          onClick={onClose}
          className="absolute top-6 right-6 p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-full transition-colors print:hidden cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Top Action Bar (Hidden on Print) */}
        <div className="flex items-center justify-between pb-4 mb-6 border-b border-slate-100 print:hidden">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
            अधिकृत वर्गणी पावती (Official Receipt)
          </span>

          <div className="flex items-center gap-2 pr-8">
            <button
              onClick={handleDownloadPdf}
              className="px-3 py-1.5 text-xs font-bold text-white bg-blue-800 hover:bg-blue-900 rounded-xl transition-colors flex items-center gap-1.5 shadow-2xs cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{t.downloadPdf}</span>
            </button>
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>{t.print}</span>
            </button>
          </div>
        </div>

        {/* RECEIPT PAPER CONTAINER */}
        <div className="border border-blue-900/20 rounded-2xl p-6 bg-radial from-white via-slate-50/50 to-blue-50/20 shadow-xs relative overflow-hidden">
          {/* Watermark in background */}
          <div className="absolute inset-0 flex items-center justify-center opacity-[0.03] pointer-events-none select-none">
            <SansthaLogo size="xl" />
          </div>

          {/* Org Header */}
          <div className="text-center pb-4 border-b border-blue-900/15">
            <div className="flex justify-center mb-2">
              <SansthaLogo size="md" />
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-blue-950 tracking-tight">
              {receipt.organizationName || 'EKTA SEVA BHAVI SANSTHA'}
            </h2>
            <p className="text-xs text-blue-900 font-bold">
              एकता सेवा भावी संस्था • माळी गल्ली, कळमनुरी
            </p>
            <p className="text-[11px] text-slate-500 mt-0.5">
              पत्ता: माळी गल्ली, कळमनुरी, जि. हिंगोली, महाराष्ट्र • नोंदणी क्र. MAH/KLM/1048/2022
            </p>
          </div>

          {/* Receipt Number & Date Banner */}
          <div className="flex items-center justify-between py-3 px-4 my-4 bg-blue-50/70 border border-blue-100 rounded-xl">
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-500 block">
                {t.receiptNumber}
              </span>
              <span className="text-sm font-mono font-black text-blue-900">
                {receipt.receiptNumber}
              </span>
            </div>

            <div className="text-right">
              <span className="text-[10px] uppercase font-bold text-slate-500 block">
                {t.date}
              </span>
              <span className="text-xs font-semibold text-slate-800">
                {formatDateTime(receipt.paymentDate)}
              </span>
            </div>
          </div>

          {/* Table of Details */}
          <div className="space-y-2 text-xs divide-y divide-slate-100">
            <div className="flex justify-between py-1.5">
              <span className="text-slate-500 font-medium">सभासद आयडी (Member ID):</span>
              <span className="font-mono font-bold text-blue-950 bg-blue-100/60 px-2 py-0.5 rounded">
                {receipt.memberId}
              </span>
            </div>

            <div className="flex justify-between py-1.5">
              <span className="text-slate-500 font-medium">{t.fullName}:</span>
              <span className="font-bold text-slate-900">{receipt.memberName}</span>
            </div>

            <div className="flex justify-between py-1.5">
              <span className="text-slate-500 font-medium">{t.mobileNumber}:</span>
              <span className="font-mono text-slate-700">{receipt.memberMobile}</span>
            </div>

            <div className="flex justify-between py-1.5">
              <span className="text-slate-500 font-medium">हप्त्याचा महिना (Billing Month):</span>
              <span className="font-bold text-blue-900">{receipt.monthLabel || receipt.monthYear}</span>
            </div>

            <div className="flex justify-between py-1.5">
              <span className="text-slate-500 font-medium">{t.method}:</span>
              <span className="font-bold capitalize text-slate-800">
                {receipt.paymentMethod === 'cash' ? 'रोख (Cash Payment)' : 'ऑनलाइन UPI (Verified)'}
              </span>
            </div>

            <div className="flex justify-between py-1.5">
              <span className="text-slate-500 font-medium">व्यवहार संदर्भ (Transaction Ref):</span>
              <span className="font-mono text-[11px] text-slate-600">
                {receipt.transactionRef}
              </span>
            </div>

            <div className="flex justify-between py-1.5">
              <span className="text-slate-500 font-medium">पडताळणी स्थिती:</span>
              <span className="inline-flex items-center gap-1 font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full text-[10px]">
                <CheckCircle className="w-3 h-3" />
                <span>पडताळलेले (Verified)</span>
              </span>
            </div>
          </div>

          {/* Amount Box */}
          <div className="mt-4 p-4 rounded-xl bg-blue-900 text-white flex items-center justify-between">
            <div>
              <span className="text-[10px] uppercase font-bold text-blue-200 block">
                प्राप्त रक्कम (Amount Received)
              </span>
              <span className="text-xs text-blue-100 italic mt-0.5 block max-w-xs">
                {receipt.amountInWords}
              </span>
            </div>
            <div className="text-right">
              <span className="text-2xl font-black text-amber-400">
                {formatINR(receipt.amountPaise)}
              </span>
            </div>
          </div>

          {/* Balance remaining */}
          <div className="text-[11px] text-slate-500 text-center mt-3">
            सदर महिन्याची शिल्लक बाकी: <span className="font-bold text-slate-700">{formatINR(receipt.remainingBalancePaise)}</span>
          </div>

          {/* Signatures & Stamp */}
          <div className="mt-8 pt-6 border-t border-slate-200 flex items-end justify-between">
            {/* Sanstha Stamp Seal */}
            <div className="w-24 h-24 rounded-full border-2 border-dashed border-teal-600/70 p-1 flex flex-col items-center justify-center text-center text-teal-800 transform -rotate-12 select-none">
              <span className="text-[8px] font-black uppercase">एकता सेवाभावी</span>
              <span className="text-[9px] font-black uppercase">संस्था</span>
              <span className="text-[7px] text-slate-600">कळमनुरी (हिंगोली)</span>
              <span className="text-[6px] font-bold text-teal-700 mt-0.5">अधिकृत शिक्का</span>
            </div>

            {/* Authorized Signatory */}
            <div className="text-right">
              <div className="w-40 border-b border-slate-400 pb-1 mb-1 font-serif italic text-blue-950 font-bold text-sm">
                Santoshrao Mali
              </div>
              <span className="text-xs font-bold text-slate-900 block">
                {receipt.issuedBy}
              </span>
              <span className="text-[10px] text-slate-500 block">
                अध्यक्ष / कोषाध्यक्ष, एकता संस्था
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
