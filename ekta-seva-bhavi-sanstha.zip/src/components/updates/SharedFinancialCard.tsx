import React from 'react';
import { useLanguage } from '../../context/LanguageContext.js';
import { SharedSansthaFinancials } from '../../types/index.js';
import { formatINR, formatDateTime } from '../../utils/formatters.js';
import {
  Building2,
  TrendingUp,
  TrendingDown,
  ShieldCheck,
  Lock,
  Wallet,
  Clock,
  CheckCircle2,
} from 'lucide-react';

interface SharedFinancialCardProps {
  financials: SharedSansthaFinancials | null;
  isLoading: boolean;
  onRefresh?: () => void;
}

export const SharedFinancialCard: React.FC<SharedFinancialCardProps> = ({
  financials,
  isLoading,
  onRefresh,
}) => {
  const { language } = useLanguage();

  if (isLoading && !financials) {
    return (
      <div className="bg-white rounded-3xl p-6 border border-slate-200 animate-pulse">
        <div className="h-6 bg-slate-200 rounded w-1/3 mb-4"></div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="h-24 bg-slate-100 rounded-2xl"></div>
          <div className="h-24 bg-slate-100 rounded-2xl"></div>
          <div className="h-24 bg-slate-100 rounded-2xl"></div>
        </div>
      </div>
    );
  }

  if (!financials || !financials.isAuthorized) {
    return (
      <div className="bg-amber-50 rounded-3xl p-6 border border-amber-200 text-amber-900 flex items-start gap-3">
        <Lock className="w-5 h-5 text-amber-700 flex-shrink-0 mt-0.5" />
        <div>
          <h4 className="font-bold text-sm">
            {language === 'mr' ? 'संस्था आर्थिक ताळेबंद (अप्रत्यक्ष)' : 'Institutional Financial Summary'}
          </h4>
          <p className="text-xs text-amber-800 mt-1">
            {language === 'mr'
              ? 'संस्थेचे एकत्रित जमा-खर्च आकडेवारी सध्या व्यवस्थापकीय पडताळणी प्रक्रियेत आहे. पडताळणी पूर्ण झाल्यावर येथे उपलब्ध होईल.'
              : 'Institutional financial summary is currently under administrative audit verification and will be visible once approved.'}
          </p>
        </div>
      </div>
    );
  }

  const isNetPositive = financials.remainingBalancePaise >= 0;

  return (
    <div className="bg-gradient-to-br from-slate-900 via-blue-950 to-indigo-950 text-white rounded-3xl p-6 sm:p-7 shadow-lg border border-blue-900/60 relative overflow-hidden">
      {/* Background ambient pattern */}
      <div className="absolute right-0 top-0 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>

      {/* Header */}
      <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6 pb-4 border-b border-blue-800/50">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold mb-1.5 border border-emerald-500/30">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>
              {language === 'mr' ? 'पडताळणीकृत संस्था निधी' : 'Verified Sanstha Ledger'}
            </span>
          </div>
          <h2 className="text-lg sm:text-xl font-black tracking-tight text-white flex items-center gap-2">
            <Building2 className="w-5 h-5 text-amber-400" />
            <span>
              {language === 'mr' ? 'एकता संस्था एकत्रित जमा-खर्च व शिल्लक' : 'Sanstha Verified Financial Summary'}
            </span>
          </h2>
          <p className="text-xs text-blue-200 mt-0.5">
            {language === 'mr'
              ? 'संस्थेच्या सर्व सभासदांच्या माहितीसाठी अधिकृत व पडताळणीकृत आर्थिक स्थिती'
              : 'Official and verified institutional accounts for all registered Sanstha members'}
          </p>
        </div>

        <div className="flex items-center gap-2 text-[11px] text-blue-300 bg-blue-900/40 px-3 py-1.5 rounded-xl border border-blue-700/40 self-start sm:self-auto">
          <Clock className="w-3.5 h-3.5 text-amber-300" />
          <span>
            {language === 'mr' ? 'थेट अपडेट: ' : 'Live Sync: '}
            {formatDateTime(financials.lastUpdated)}
          </span>
        </div>
      </div>

      {/* 3 Main Stat Cards */}
      <div className="relative z-10 grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Total Collections */}
        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-4 sm:p-5 border border-white/10">
          <div className="flex items-center justify-between text-blue-200 mb-2">
            <span className="text-[11px] uppercase tracking-wider font-bold">
              {language === 'mr' ? 'एकूण जमा वर्गणी (Verified)' : 'Total Collections'}
            </span>
            <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-xl">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-emerald-300">
            {formatINR(financials.totalContributionsPaise)}
          </div>
          <p className="text-[11px] text-emerald-200/80 mt-1 flex items-center gap-1 font-medium">
            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
            <span>{financials.verifiedCollectionsCount} {language === 'mr' ? 'पडताळणीकृत पावत्या' : 'verified payments'}</span>
          </p>
        </div>

        {/* Total Expenses */}
        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-4 sm:p-5 border border-white/10">
          <div className="flex items-center justify-between text-blue-200 mb-2">
            <span className="text-[11px] uppercase tracking-wider font-bold">
              {language === 'mr' ? 'एकूण झालेला खर्च (Expenses)' : 'Total Expenses'}
            </span>
            <div className="p-2 bg-rose-500/20 text-rose-400 rounded-xl">
              <TrendingDown className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-rose-300">
            {formatINR(financials.totalExpensesPaise)}
          </div>
          <p className="text-[11px] text-rose-200/80 mt-1 flex items-center gap-1 font-medium">
            <CheckCircle2 className="w-3 h-3 text-rose-400" />
            <span>{financials.verifiedExpensesCount} {language === 'mr' ? 'अधिकृत खर्च व्हाउचर' : 'verified vouchers'}</span>
          </p>
        </div>

        {/* Net Remaining Balance */}
        <div className="bg-gradient-to-br from-amber-500/20 to-amber-700/20 backdrop-blur-md rounded-2xl p-4 sm:p-5 border border-amber-400/30">
          <div className="flex items-center justify-between text-amber-200 mb-2">
            <span className="text-[11px] uppercase tracking-wider font-bold">
              {language === 'mr' ? 'संस्थेची निव्वळ शिल्लक (Net Balance)' : 'Net Sanstha Balance'}
            </span>
            <div className="p-2 bg-amber-400/20 text-amber-300 rounded-xl">
              <Wallet className="w-4 h-4" />
            </div>
          </div>
          <div className={`text-2xl sm:text-3xl font-black ${isNetPositive ? 'text-amber-300' : 'text-rose-300'}`}>
            {formatINR(financials.remainingBalancePaise)}
          </div>
          <p className="text-[11px] text-amber-200 mt-1 font-medium">
            {language === 'mr' ? 'संस्था बँक / रोकड शिल्लक' : 'Available Sanstha reserve'}
          </p>
        </div>
      </div>

      {/* Sub row: Current Month Snapshot */}
      <div className="relative z-10 mt-4 pt-4 border-t border-blue-900/60 flex flex-wrap items-center justify-between gap-3 text-xs text-blue-200">
        <div className="flex items-center gap-4">
          <div>
            <span className="text-blue-300 font-semibold">{language === 'mr' ? 'चालू महिना जमा: ' : 'This Month In: '}</span>
            <span className="font-bold text-emerald-300 font-mono">{formatINR(financials.thisMonthCollectionPaise)}</span>
          </div>
          <div className="text-blue-700">•</div>
          <div>
            <span className="text-blue-300 font-semibold">{language === 'mr' ? 'चालू महिना खर्च: ' : 'This Month Out: '}</span>
            <span className="font-bold text-rose-300 font-mono">{formatINR(financials.thisMonthExpensesPaise)}</span>
          </div>
        </div>

        <div className="text-[11px] text-blue-300/80 italic">
          {language === 'mr'
            ? 'सर्व आकडे प्रत्यक्ष पावत्या व अधिकृत खर्च नोंदींवर आधारित आहेत.'
            : 'All figures derived from verified receipts and approved vouchers.'}
        </div>
      </div>
    </div>
  );
};
