import React, { useState, useEffect } from 'react';
import { useLanguage } from '../../context/LanguageContext.js';
import { api } from '../../services/api.js';
import { SansthaUpdate, SansthaUpdateCategory, Member } from '../../types/index.js';
import {
  X,
  Calendar,
  Clock,
  MapPin,
  Bell,
  Users,
  CheckCircle,
  XCircle,
  FileText,
  AlertCircle,
  Sparkles,
} from 'lucide-react';

interface ManageUpdateModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaved: () => void;
  updateToEdit?: SansthaUpdate | null;
}

export const ManageUpdateModal: React.FC<ManageUpdateModalProps> = ({
  isOpen,
  onClose,
  onSaved,
  updateToEdit,
}) => {
  const { language } = useLanguage();
  const [members, setMembers] = useState<Member[]>([]);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState<SansthaUpdateCategory>('announcement');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [time, setTime] = useState('18:00');
  const [venue, setVenue] = useState('संस्था कार्यालय, माळी गल्ली, कळमनुरी');
  const [isImportant, setIsImportant] = useState(false);
  const [isPublished, setIsPublished] = useState(true);
  const [attendance, setAttendance] = useState<{ memberId: string; memberName: string; status: 'present' | 'absent' | 'excused' }[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!isOpen) return;

    // Load member list for attendance checklist if meeting
    api.members.getAll().then((mList) => {
      setMembers(mList);

      if (updateToEdit) {
        setTitle(updateToEdit.title);
        setContent(updateToEdit.content);
        setCategory(updateToEdit.category);
        setDate(updateToEdit.date);
        setTime(updateToEdit.time || '18:00');
        setVenue(updateToEdit.venue || 'संस्था कार्यालय, माळी गल्ली, कळमनुरी');
        setIsImportant(Boolean(updateToEdit.isImportant));
        setIsPublished(updateToEdit.isPublished !== false);
        if (updateToEdit.attendance && updateToEdit.attendance.length > 0) {
          setAttendance(updateToEdit.attendance);
        } else {
          // Initialize attendance from members
          setAttendance(mList.map((m) => ({ memberId: m.memberId, memberName: m.fullName, status: 'present' })));
        }
      } else {
        // Reset defaults
        setTitle('');
        setContent('');
        setCategory('announcement');
        setDate(new Date().toISOString().slice(0, 10));
        setTime('18:00');
        setVenue('संस्था कार्यालय, माळी गल्ली, कळमनुरी');
        setIsImportant(false);
        setIsPublished(true);
        setAttendance(mList.map((m) => ({ memberId: m.memberId, memberName: m.fullName, status: 'present' })));
      }
    }).catch(console.error);

    setError('');
  }, [isOpen, updateToEdit]);

  if (!isOpen) return null;

  const handleAttendanceToggle = (memberId: string, newStatus: 'present' | 'absent' | 'excused') => {
    setAttendance((prev) =>
      prev.map((item) => (item.memberId === memberId ? { ...item, status: newStatus } : item))
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) {
      setError('Title and content are required');
      return;
    }

    setIsSubmitting(true);
    setError('');

    try {
      const payload: Partial<SansthaUpdate> = {
        title: title.trim(),
        content: content.trim(),
        category,
        date,
        time: time.trim() || undefined,
        venue: venue.trim() || undefined,
        isImportant,
        isPublished,
        attendance: category === 'meeting' ? attendance : undefined,
      };

      if (updateToEdit) {
        await api.updates.update(updateToEdit.id, payload);
      } else {
        await api.updates.create(payload);
      }

      onSaved();
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to save Sanstha update');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-3xl w-full max-w-xl max-h-[90vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-blue-100 text-blue-900 rounded-xl">
              <Sparkles className="w-5 h-5 text-blue-700" />
            </div>
            <div>
              <h3 className="font-extrabold text-slate-900 text-base">
                {updateToEdit
                  ? (language === 'mr' ? 'अपडेट संपादित करा' : 'Edit Sanstha Update')
                  : (language === 'mr' ? 'नवीन घोषणा / बैठक / उपक्रम जोडा' : 'Publish Sanstha Update')}
              </h3>
              <p className="text-xs text-slate-500">
                {language === 'mr' ? 'सर्व सभासदांना थेट डॅशबोर्डवर दिसेल' : 'Visible to all registered members'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-200 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto flex-1">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Category Selector */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              {language === 'mr' ? 'प्रकार (Category)' : 'Category'}
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              {[
                { id: 'announcement', label: language === 'mr' ? 'घोषणा' : 'Announcement' },
                { id: 'meeting', label: language === 'mr' ? 'बैठक' : 'Meeting' },
                { id: 'activity', label: language === 'mr' ? 'उपक्रम' : 'Activity' },
                { id: 'notice', label: language === 'mr' ? 'सूचना' : 'Notice' },
                { id: 'event', label: language === 'mr' ? 'कार्यक्रम' : 'Event' },
              ].map((c) => (
                <button
                  type="button"
                  key={c.id}
                  onClick={() => setCategory(c.id as SansthaUpdateCategory)}
                  className={`py-2 px-2 text-xs font-bold rounded-xl transition-all text-center cursor-pointer ${
                    category === c.id
                      ? 'bg-blue-800 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {c.label}
                </button>
              ))}
            </div>
          </div>

          {/* Title */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {language === 'mr' ? 'शीर्षक (Title) *' : 'Title *'}
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder={language === 'mr' ? 'उदा. मासिक बैठक अथवा उपक्रमाचे नाव' : 'e.g. Monthly General Meeting'}
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm font-semibold text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600"
            />
          </div>

          {/* Date, Time & Venue */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {language === 'mr' ? 'तारीख (Date)' : 'Date'}
              </label>
              <input
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {language === 'mr' ? 'वेळ (Time)' : 'Time'}
              </label>
              <input
                type="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {language === 'mr' ? 'स्थान (Venue)' : 'Venue'}
              </label>
              <input
                type="text"
                value={venue}
                onChange={(e) => setVenue(e.target.value)}
                placeholder="उदा. संस्था कार्यालय, माळी गल्ली"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600"
              />
            </div>
          </div>

          {/* Content Description */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {language === 'mr' ? 'तपशील / विषय / कार्यसूची (Details & Agenda) *' : 'Details & Agenda *'}
            </label>
            <textarea
              required
              rows={4}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder={language === 'mr' ? 'बैठकीचा किंवा उपक्रमाचा संपूर्ण तपशील येथे लिहा...' : 'Write meeting agenda or activity report...'}
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm font-medium text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600 resize-none"
            />
          </div>

          {/* Meeting Attendance Checklist (Shown if category is meeting) */}
          {category === 'meeting' && (
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <Users className="w-4 h-4 text-blue-700" />
                  <span>{language === 'mr' ? 'सभासद उपस्थिती नोंद (Attendance Checklist)' : 'Meeting Attendance'}</span>
                </span>
                <span className="text-[11px] font-semibold text-slate-500">
                  {attendance.filter((a) => a.status === 'present').length} / {attendance.length} {language === 'mr' ? 'उपस्थित' : 'Present'}
                </span>
              </div>

              <div className="max-h-44 overflow-y-auto divide-y divide-slate-200">
                {attendance.map((att) => (
                  <div key={att.memberId} className="py-2 flex items-center justify-between text-xs">
                    <div>
                      <span className="font-mono font-bold text-blue-900 bg-blue-100/70 px-1.5 py-0.5 rounded text-[10px] mr-1.5">
                        {att.memberId}
                      </span>
                      <span className="font-semibold text-slate-800">{att.memberName}</span>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => handleAttendanceToggle(att.memberId, 'present')}
                        className={`px-2 py-0.5 rounded text-[10px] font-bold transition-colors ${
                          att.status === 'present' ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-600'
                        }`}
                      >
                        उपस्थित
                      </button>
                      <button
                        type="button"
                        onClick={() => handleAttendanceToggle(att.memberId, 'absent')}
                        className={`px-2 py-0.5 rounded text-[10px] font-bold transition-colors ${
                          att.status === 'absent' ? 'bg-rose-600 text-white' : 'bg-slate-200 text-slate-600'
                        }`}
                      >
                        अनुपस्थित
                      </button>
                      <button
                        type="button"
                        onClick={() => handleAttendanceToggle(att.memberId, 'excused')}
                        className={`px-2 py-0.5 rounded text-[10px] font-bold transition-colors ${
                          att.status === 'excused' ? 'bg-amber-600 text-white' : 'bg-slate-200 text-slate-600'
                        }`}
                      >
                        रजेवर
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Toggles: Important & Published */}
          <div className="flex items-center justify-between pt-2">
            <label className="flex items-center gap-2 text-xs font-bold text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={isImportant}
                onChange={(e) => setIsImportant(e.target.checked)}
                className="w-4 h-4 text-blue-800 rounded border-slate-300 focus:ring-blue-600"
              />
              <span>{language === 'mr' ? 'अति-महत्त्वाचे म्हणून चिन्हांकित करा' : 'Mark as Important Notice'}</span>
            </label>

            <label className="flex items-center gap-2 text-xs font-bold text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={isPublished}
                onChange={(e) => setIsPublished(e.target.checked)}
                className="w-4 h-4 text-blue-800 rounded border-slate-300 focus:ring-blue-600"
              />
              <span>{language === 'mr' ? 'थेट प्रसिद्ध करा' : 'Publish to Members'}</span>
            </label>
          </div>

          {/* Submit Button */}
          <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 border border-slate-300 hover:bg-slate-100 text-slate-700 font-bold text-xs rounded-xl transition-all cursor-pointer"
            >
              रद्द करा (Cancel)
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2.5 bg-blue-800 hover:bg-blue-900 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {isSubmitting ? 'जतन करत आहे...' : updateToEdit ? 'अपडेट करा (Update)' : 'प्रसिद्ध करा (Publish)'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
