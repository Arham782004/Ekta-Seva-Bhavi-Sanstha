import React, { useState } from 'react';
import { useLanguage } from '../../context/LanguageContext.js';
import { useAuth } from '../../context/AuthContext.js';
import { api } from '../../services/api.js';
import { SansthaUpdate, SansthaUpdateCategory } from '../../types/index.js';
import { formatDate, formatDateTime } from '../../utils/formatters.js';
import {
  Bell,
  Calendar,
  Clock,
  MapPin,
  CheckCircle,
  AlertCircle,
  Users,
  Sparkles,
  Plus,
  Edit2,
  Trash2,
  Activity,
  FileText,
  Radio,
  RefreshCw,
  Award,
} from 'lucide-react';

interface SansthaUpdatesSectionProps {
  updates: SansthaUpdate[];
  isLoading: boolean;
  onRefresh: () => void;
  onOpenAddUpdate: () => void;
  onEditUpdate: (update: SansthaUpdate) => void;
  lastSyncTime?: Date;
}

export const SansthaUpdatesSection: React.FC<SansthaUpdatesSectionProps> = ({
  updates,
  isLoading,
  onRefresh,
  onOpenAddUpdate,
  onEditUpdate,
  lastSyncTime = new Date(),
}) => {
  const { language } = useLanguage();
  const { isAdmin } = useAuth();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const categories = [
    { id: 'all', label: language === 'mr' ? 'सर्व अपडेट्स' : 'All Updates' },
    { id: 'meeting', label: language === 'mr' ? 'बैठका (Meetings)' : 'Meetings' },
    { id: 'activity', label: language === 'mr' ? 'उपक्रम (Activities)' : 'Activities' },
    { id: 'announcement', label: language === 'mr' ? 'घोषणा (Announcements)' : 'Announcements' },
    { id: 'notice', label: language === 'mr' ? 'सूचना (Notices)' : 'Notices' },
  ];

  const filteredUpdates = updates.filter((u) => {
    if (selectedCategory === 'all') return true;
    return u.category === selectedCategory;
  });

  const handleDelete = async (id: string, title: string) => {
    if (!isAdmin) return;
    if (!window.confirm(`Are you sure you want to remove update "${title}"?`)) {
      return;
    }

    setDeletingId(id);
    try {
      await api.updates.delete(id);
      onRefresh();
    } catch (err: any) {
      alert(err.message || 'Failed to remove update');
    } finally {
      setDeletingId(null);
    }
  };

  const getCategoryBadge = (category: SansthaUpdateCategory) => {
    switch (category) {
      case 'meeting':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-indigo-100 text-indigo-900 border border-indigo-200">
            <Users className="w-3 h-3 text-indigo-700" />
            <span>{language === 'mr' ? 'मासिक बैठक' : 'Meeting'}</span>
          </span>
        );
      case 'activity':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-900 border border-emerald-200">
            <Activity className="w-3 h-3 text-emerald-700" />
            <span>{language === 'mr' ? 'यशस्वी उपक्रम' : 'Activity'}</span>
          </span>
        );
      case 'notice':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-100 text-amber-900 border border-amber-200">
            <AlertCircle className="w-3 h-3 text-amber-700" />
            <span>{language === 'mr' ? 'महत्त्वाची सूचना' : 'Notice'}</span>
          </span>
        );
      case 'event':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-purple-100 text-purple-900 border border-purple-200">
            <Sparkles className="w-3 h-3 text-purple-700" />
            <span>{language === 'mr' ? 'विशेष कार्यक्रम' : 'Event'}</span>
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-blue-100 text-blue-900 border border-blue-200">
            <Bell className="w-3 h-3 text-blue-700" />
            <span>{language === 'mr' ? 'संस्था घोषणा' : 'Announcement'}</span>
          </span>
        );
    }
  };

  return (
    <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200 shadow-xs space-y-6">
      {/* Header with Title and Live Sync status */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 bg-blue-100 text-blue-900 rounded-xl">
              <Sparkles className="w-5 h-5 text-blue-800" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-extrabold text-blue-950 flex items-center gap-2">
                <span>{language === 'mr' ? 'संस्था थेट घडामोडी व उपक्रम' : 'Sanstha Live Updates & Activities'}</span>
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                  <Radio className="w-2.5 h-2.5 animate-pulse text-emerald-600" />
                  <span>Live</span>
                </span>
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                {language === 'mr'
                  ? 'सर्व सभासदांसाठी बैठका, उपक्रम, घोषणा आणि उपस्थितीचा थेट पारदर्शक आढावा'
                  : 'Live updates, upcoming meetings, completed activities, and notices for all members'}
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <div className="text-[11px] text-slate-400 flex items-center gap-1.5 mr-1">
            <Clock className="w-3.5 h-3.5 text-slate-400" />
            <span>{language === 'mr' ? 'सिंक: ' : 'Synced: '}{lastSyncTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</span>
          </div>

          <button
            onClick={onRefresh}
            className="p-2 text-slate-500 hover:text-blue-900 hover:bg-slate-100 rounded-xl transition-all cursor-pointer"
            title="Refresh Updates"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </button>

          {isAdmin && (
            <button
              onClick={onOpenAddUpdate}
              className="px-3.5 py-2 bg-blue-800 hover:bg-blue-900 text-white font-bold text-xs rounded-xl shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>{language === 'mr' ? 'नवीन अपडेट जोडा' : 'Add Update'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Category Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id)}
            className={`px-3.5 py-1.5 text-xs font-bold rounded-xl whitespace-nowrap transition-colors cursor-pointer ${
              selectedCategory === cat.id
                ? 'bg-blue-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Updates Cards List */}
      <div className="space-y-4">
        {filteredUpdates.length === 0 ? (
          <div className="py-12 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200">
            <FileText className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <h4 className="text-sm font-bold text-slate-700">
              {language === 'mr' ? 'कोणतेही अपडेट उपलब्ध नाहीत' : 'No updates found in this category'}
            </h4>
            <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
              {language === 'mr'
                ? 'या प्रवर्गात सध्या कोणतीही नोंद नाही. प्रशासनाकडून नवीन माहिती प्रसिद्ध झाल्यावर येथे त्वरित दिसेल.'
                : 'No notices or meetings currently listed. New verified announcements will appear here automatically.'}
            </p>
          </div>
        ) : (
          filteredUpdates.map((item) => (
            <div
              key={item.id}
              className={`p-5 rounded-2xl border transition-all ${
                item.isImportant
                  ? 'bg-amber-50/40 border-amber-300/80 shadow-xs'
                  : 'bg-slate-50/70 hover:bg-slate-50 border-slate-200'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2.5">
                <div className="flex items-center gap-2 flex-wrap">
                  {getCategoryBadge(item.category)}

                  {item.isImportant && (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-rose-100 text-rose-800 uppercase tracking-wider">
                      {language === 'mr' ? 'अति-महत्त्वाचे' : 'Important'}
                    </span>
                  )}

                  <span className="text-[11px] text-slate-500 font-medium flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-slate-400" />
                    <span>{formatDate(item.date)}</span>
                  </span>

                  {item.time && (
                    <span className="text-[11px] text-slate-500 font-medium flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      <span>{item.time}</span>
                    </span>
                  )}
                </div>

                {/* Admin Actions */}
                {isAdmin && (
                  <div className="flex items-center gap-1 self-end sm:self-auto">
                    <button
                      onClick={() => onEditUpdate(item)}
                      className="p-1.5 text-slate-500 hover:text-blue-900 hover:bg-blue-100/60 rounded-lg transition-colors cursor-pointer"
                      title="Edit update"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      disabled={deletingId === item.id}
                      onClick={() => handleDelete(item.id, item.title)}
                      className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-100/60 rounded-lg transition-colors cursor-pointer"
                      title="Delete update"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>

              {/* Title & Content */}
              <h3 className="text-base font-extrabold text-slate-900 leading-snug">
                {item.title}
              </h3>

              <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed whitespace-pre-line">
                {item.content}
              </p>

              {/* Venue if present */}
              {item.venue && (
                <div className="mt-3 flex items-center gap-1.5 text-xs text-slate-600 bg-white/80 px-3 py-1.5 rounded-xl border border-slate-200/80 w-fit">
                  <MapPin className="w-3.5 h-3.5 text-rose-500 flex-shrink-0" />
                  <span className="font-medium">{item.venue}</span>
                </div>
              )}

              {/* Attendance Summary Badge (For Meetings) */}
              {item.category === 'meeting' && item.attendanceSummary && (
                <div className="mt-3 pt-3 border-t border-slate-200/60 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-blue-700" />
                    <span className="font-bold text-slate-800">
                      {language === 'mr' ? 'सभासद उपस्थिती सारांश:' : 'Meeting Attendance:'}
                    </span>
                    <span className="font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200 text-xs">
                      {item.attendanceSummary.presentCount} / {item.attendanceSummary.totalInvited} {language === 'mr' ? 'उपस्थित' : 'Present'}
                    </span>
                    {item.attendanceSummary.absentCount > 0 && (
                      <span className="text-[11px] text-slate-400">
                        ({item.attendanceSummary.absentCount} {language === 'mr' ? 'अनुपस्थित' : 'absent'})
                      </span>
                    )}
                  </div>

                  <span className="text-[10px] text-slate-400 font-mono">
                    {formatDateTime(item.createdAt)}
                  </span>
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};
