import React, { useState, useEffect } from 'react';
import { useLanguage } from '../../context/LanguageContext.js';
import { useAuth } from '../../context/AuthContext.js';
import { api } from '../../services/api.js';
import {
  OrganizationSettings,
  AuditLog,
  User,
  StaffPermissions,
} from '../../types/index.js';
import { formatDateTime, formatINR } from '../../utils/formatters.js';
import { SansthaLogo } from '../common/SansthaLogo.js';
import {
  Settings,
  Building,
  CreditCard,
  Lock,
  History,
  Save,
  CheckCircle,
  AlertCircle,
  KeyRound,
  ShieldAlert,
  ShieldCheck,
  Users,
  Receipt,
  UserCheck,
  Bell,
  Database,
  Globe,
  Info,
  Sparkles,
  Smartphone,
  Download,
  RefreshCw,
  Eye,
  EyeOff,
  Plus,
  Trash2,
  Edit,
  X,
  FileSpreadsheet,
  Upload,
  RotateCcw,
  Palette,
  Send,
} from 'lucide-react';

type SettingsTab =
  | 'modify_app'
  | 'security'
  | 'members'
  | 'payments'
  | 'staff'
  | 'notifications'
  | 'reports_data'
  | 'appearance'
  | 'app_info'
  | 'audit';

export const SettingsScreen: React.FC = () => {
  const { t, language, setLanguage } = useLanguage();
  const { settings, updateSettingsState, isAdmin, user } = useAuth();

  const [activeTab, setActiveTab] = useState<SettingsTab>('modify_app');

  // Status banners
  const [saveStatus, setSaveStatus] = useState('');
  const [errorStatus, setErrorStatus] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  // -------------------------------------------------------------
  // A. Modify App Form State
  // -------------------------------------------------------------
  const [orgName, setOrgName] = useState(settings?.orgName || 'Ekta Seva Bhavi Sanstha');
  const [marathiName, setMarathiName] = useState(settings?.marathiName || 'एकता सेवा भावी संस्था');
  const [hindiName, setHindiName] = useState(settings?.hindiName || 'एकता सेवा भावी संस्था');
  const [address, setAddress] = useState(settings?.address || 'Mali Galli, Kalamnuri, Maharashtra, India');
  const [regNo, setRegNo] = useState(settings?.registrationNumber || 'MAH/KLM/1048/2022');
  const [phone, setPhone] = useState(settings?.contactPhone || '+91 98765 43210');
  const [email, setEmail] = useState(settings?.contactEmail || 'info@ektasanstha.org');
  const [presidentName, setPresidentName] = useState(settings?.presidentName || 'Santoshrao Mali');
  const [appSubtitle, setAppSubtitle] = useState(
    settings?.appSubtitle || 'माळी गल्ली, कळमनुरी - मासिक योगदान आणि सदस्य निधी व्यवस्थापन पोर्टल'
  );
  const [customLogoUrl, setCustomLogoUrl] = useState<string | undefined>(settings?.customLogoUrl);
  const [themePrimaryColor, setThemePrimaryColor] = useState(settings?.themePrimaryColor || '#1e3a8a');
  const [themeSecondaryColor, setThemeSecondaryColor] = useState(settings?.themeSecondaryColor || '#d97706');
  const [themeAccentColor, setThemeAccentColor] = useState(settings?.themeAccentColor || '#059669');

  // -------------------------------------------------------------
  // B. Login & Security State
  // -------------------------------------------------------------
  const [allowStaffLogin, setAllowStaffLogin] = useState(settings?.allowStaffLogin !== false);
  const [allowMemberLogin, setAllowMemberLogin] = useState(settings?.allowMemberLogin !== false);
  const [sessionTimeoutMinutes, setSessionTimeoutMinutes] = useState(settings?.sessionTimeoutMinutes || 120);
  const [requirePasswordMinLength, setRequirePasswordMinLength] = useState(
    settings?.requirePasswordMinLength || 6
  );
  const [maxFailedLoginAttempts, setMaxFailedLoginAttempts] = useState(
    settings?.maxFailedLoginAttempts || 5
  );

  // Password change state
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passMsg, setPassMsg] = useState('');
  const [passError, setPassError] = useState('');

  // -------------------------------------------------------------
  // C. Member Management Rules State
  // -------------------------------------------------------------
  const [memberIdPrefix, setMemberIdPrefix] = useState(settings?.memberIdPrefix || 'M');
  const [memberIdDigits, setMemberIdDigits] = useState(settings?.memberIdDigits || 3);
  const [autoAssignMemberId, setAutoAssignMemberId] = useState(settings?.autoAssignMemberId !== false);
  const [requireEmailForMembers, setRequireEmailForMembers] = useState(
    settings?.requireEmailForMembers ?? false
  );
  const [requireAddressForMembers, setRequireAddressForMembers] = useState(
    settings?.requireAddressForMembers !== false
  );

  // -------------------------------------------------------------
  // D. Payment & Receipt Settings State
  // -------------------------------------------------------------
  const [monthlyContribution, setMonthlyContribution] = useState(
    settings ? settings.standardContributionPaise / 100 : 1000
  );
  const [dueDay, setDueDay] = useState(settings?.dueDayOfMonth || 10);
  const [enableCashPayments, setEnableCashPayments] = useState(settings?.enableCashPayments !== false);
  const [enableUpiPayments, setEnableUpiPayments] = useState(settings?.enableUpiPayments !== false);
  const [enableBankTransfer, setEnableBankTransfer] = useState(settings?.enableBankTransfer !== false);
  const [bankName, setBankName] = useState(settings?.bankName || 'State Bank of India, Kalamnuri Branch');
  const [bankAccountNumber, setBankAccountNumber] = useState(settings?.bankAccountNumber || '30489218491');
  const [bankIfsc, setBankIfsc] = useState(settings?.bankIfsc || 'SBIN0001234');
  const [upiId, setUpiId] = useState(settings?.upiId || 'ektasanstha@upi');
  const [receiptPrefix, setReceiptPrefix] = useState(settings?.receiptPrefix || 'ESBS');
  const [receiptStartNumber, setReceiptStartNumber] = useState(settings?.receiptStartNumber || 1001);
  const [receiptIssuedBy, setReceiptIssuedBy] = useState(
    settings?.receiptIssuedBy || 'कार्यालय व्यवस्थापक / Admin Office'
  );
  const [receiptPresidentName, setReceiptPresidentName] = useState(
    settings?.receiptPresidentName || 'Santoshrao Mali'
  );
  const [receiptFooterNote, setReceiptFooterNote] = useState(
    settings?.receiptFooterNote || 'ही संगणकीय पावती आहे. स्वाक्षरीची आवश्यकता नाही.'
  );
  const [showFinancialSummaryToMembers, setShowFinancialSummaryToMembers] = useState(
    settings?.showFinancialSummaryToMembers !== false
  );

  // Payment Gateway credentials
  const [rzpKeyId, setRzpKeyId] = useState(settings?.razorpayKeyId || 'rzp_test_ekta_kalamnuri');
  const [rzpKeySecret, setRzpKeySecret] = useState(settings?.razorpayKeySecret || '••••••••••••••••');
  const [rzpWebhookSecret, setRzpWebhookSecret] = useState(
    settings?.razorpayWebhookSecret || '••••••••••••••••'
  );
  const [isSandbox, setIsSandbox] = useState(settings?.isSandbox ?? true);

  // -------------------------------------------------------------
  // E. Staff Accounts & Permissions State
  // -------------------------------------------------------------
  const [staffUsers, setStaffUsers] = useState<User[]>([]);
  const [isLoadingStaff, setIsLoadingStaff] = useState(false);
  const [showAddStaffModal, setShowAddStaffModal] = useState(false);
  const [newStaffName, setNewStaffName] = useState('');
  const [newStaffEmail, setNewStaffEmail] = useState('');
  const [newStaffMobile, setNewStaffMobile] = useState('');
  const [newStaffPassword, setNewStaffPassword] = useState('staff123');
  const [newStaffPermissions, setNewStaffPermissions] = useState<StaffPermissions>({
    canManageMembers: true,
    canCollectPayments: true,
    canViewReports: true,
    canSendNotifications: true,
    canGenerateDues: true,
  });
  const [resetStaffTarget, setResetStaffTarget] = useState<User | null>(null);
  const [resetStaffPassInput, setResetStaffPassInput] = useState('');

  // -------------------------------------------------------------
  // F. Notifications Settings State
  // -------------------------------------------------------------
  const [enablePaymentReminders, setEnablePaymentReminders] = useState(
    settings?.enablePaymentReminders !== false
  );
  const [reminderDaysBeforeDue, setReminderDaysBeforeDue] = useState(settings?.reminderDaysBeforeDue || 3);
  const [enablePaymentConfirmationSms, setEnablePaymentConfirmationSms] = useState(
    settings?.enablePaymentConfirmationSms !== false
  );
  const [enableOverdueAlerts, setEnableOverdueAlerts] = useState(settings?.enableOverdueAlerts !== false);
  const [enableAdminPaymentAlerts, setEnableAdminPaymentAlerts] = useState(
    settings?.enableAdminPaymentAlerts !== false
  );

  // Instant announcement broadcast state
  const [broadcastTitle, setBroadcastTitle] = useState('');
  const [broadcastMessage, setBroadcastMessage] = useState('');
  const [broadcastStatus, setBroadcastStatus] = useState('');

  // -------------------------------------------------------------
  // Audit Logs State
  // -------------------------------------------------------------
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [isLoadingLogs, setIsLoadingLogs] = useState(false);

  // Load audit logs when on audit tab
  useEffect(() => {
    if ((activeTab === 'audit' || activeTab === 'staff') && isAdmin) {
      loadAuditLogs();
    }
  }, [activeTab, isAdmin]);

  // Load staff list when on staff tab
  useEffect(() => {
    if (activeTab === 'staff' && isAdmin) {
      loadStaffUsers();
    }
  }, [activeTab, isAdmin]);

  const loadAuditLogs = async () => {
    setIsLoadingLogs(true);
    try {
      const logs = await api.settings.getAuditLogs();
      setAuditLogs(logs);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoadingLogs(false);
    }
  };

  const loadStaffUsers = async () => {
    setIsLoadingStaff(true);
    try {
      const users = await api.admin.getStaffUsers();
      setStaffUsers(users);
    } catch (err: any) {
      console.error(err);
    } finally {
      setIsLoadingStaff(false);
    }
  };

  // Sync state if settings update
  useEffect(() => {
    if (settings) {
      setOrgName(settings.orgName);
      setMarathiName(settings.marathiName || 'एकता सेवा भावी संस्था');
      setHindiName(settings.hindiName || 'एकता सेवा भावी संस्था');
      setAddress(settings.address);
      setRegNo(settings.registrationNumber);
      setPhone(settings.contactPhone);
      setEmail(settings.contactEmail);
      setPresidentName(settings.presidentName || 'Santoshrao Mali');
      setAppSubtitle(settings.appSubtitle || 'माळी गल्ली, कळमनुरी - मासिक योगदान आणि सदस्य निधी व्यवस्थापन पोर्टल');
      setCustomLogoUrl(settings.customLogoUrl);
      setThemePrimaryColor(settings.themePrimaryColor || '#1e3a8a');
      setThemeSecondaryColor(settings.themeSecondaryColor || '#d97706');
      setThemeAccentColor(settings.themeAccentColor || '#059669');

      setAllowStaffLogin(settings.allowStaffLogin !== false);
      setAllowMemberLogin(settings.allowMemberLogin !== false);
      setSessionTimeoutMinutes(settings.sessionTimeoutMinutes || 120);
      setRequirePasswordMinLength(settings.requirePasswordMinLength || 6);
      setMaxFailedLoginAttempts(settings.maxFailedLoginAttempts || 5);

      setMemberIdPrefix(settings.memberIdPrefix || 'M');
      setMemberIdDigits(settings.memberIdDigits || 3);
      setAutoAssignMemberId(settings.autoAssignMemberId !== false);
      setRequireEmailForMembers(settings.requireEmailForMembers ?? false);
      setRequireAddressForMembers(settings.requireAddressForMembers !== false);

      setMonthlyContribution(settings.standardContributionPaise / 100);
      setDueDay(settings.dueDayOfMonth);
      setEnableCashPayments(settings.enableCashPayments !== false);
      setEnableUpiPayments(settings.enableUpiPayments !== false);
      setEnableBankTransfer(settings.enableBankTransfer !== false);
      setBankName(settings.bankName || 'State Bank of India, Kalamnuri Branch');
      setBankAccountNumber(settings.bankAccountNumber || '30489218491');
      setBankIfsc(settings.bankIfsc || 'SBIN0001234');
      setUpiId(settings.upiId);
      setReceiptPrefix(settings.receiptPrefix);
      setReceiptStartNumber(settings.receiptStartNumber || 1001);
      setReceiptIssuedBy(settings.receiptIssuedBy || 'कार्यालय व्यवस्थापक / Admin Office');
      setReceiptPresidentName(settings.receiptPresidentName || 'Santoshrao Mali');
      setReceiptFooterNote(settings.receiptFooterNote || 'ही संगणकीय पावती आहे. स्वाक्षरीची आवश्यकता नाही.');
      setShowFinancialSummaryToMembers(settings.showFinancialSummaryToMembers !== false);

      setRzpKeyId(settings.razorpayKeyId);
      setIsSandbox(settings.isSandbox);

      setEnablePaymentReminders(settings.enablePaymentReminders !== false);
      setReminderDaysBeforeDue(settings.reminderDaysBeforeDue || 3);
      setEnablePaymentConfirmationSms(settings.enablePaymentConfirmationSms !== false);
      setEnableOverdueAlerts(settings.enableOverdueAlerts !== false);
      setEnableAdminPaymentAlerts(settings.enableAdminPaymentAlerts !== false);
    }
  }, [settings]);

  // Handle Logo Upload
  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 1.5 * 1024 * 1024) {
      setErrorStatus('लोगो इमेज आकार १.५ MB पेक्षा कमी असावा (Logo image must be smaller than 1.5MB)');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      setCustomLogoUrl(dataUrl);
      setSaveStatus('लोगो पूर्वावलोकन तयार झाले. बदल जतन करण्यासाठी "बदल जतन करा" बटण दाबा.');
    };
    reader.readAsDataURL(file);
  };

  const handleResetLogo = () => {
    setCustomLogoUrl(undefined);
    setSaveStatus('मूळ लोगो निवडला. बदल जतन करण्यासाठी "बदल जतन करा" बटण दाबा.');
  };

  // Cancel / Reset form to saved settings
  const handleCancelChanges = () => {
    if (!settings) return;
    setOrgName(settings.orgName);
    setMarathiName(settings.marathiName || 'एकता सेवा भावी संस्था');
    setHindiName(settings.hindiName || 'एकता सेवा भावी संस्था');
    setAddress(settings.address);
    setRegNo(settings.registrationNumber);
    setPhone(settings.contactPhone);
    setEmail(settings.contactEmail);
    setPresidentName(settings.presidentName || 'Santoshrao Mali');
    setAppSubtitle(settings.appSubtitle || 'माळी गल्ली, कळमनुरी - मासिक योगदान आणि सदस्य निधी व्यवस्थापन पोर्टल');
    setCustomLogoUrl(settings.customLogoUrl);
    setThemePrimaryColor(settings.themePrimaryColor || '#1e3a8a');
    setThemeSecondaryColor(settings.themeSecondaryColor || '#d97706');
    setThemeAccentColor(settings.themeAccentColor || '#059669');
    setSaveStatus('');
    setErrorStatus('बदल रद्द केले आहेत.');
  };

  // Save App & Organization Settings (A. Modify App)
  const handleSaveModifyApp = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaveStatus('');
    setErrorStatus('');
    setIsSaving(true);
    try {
      const updated = await api.settings.update({
        orgName,
        marathiName,
        hindiName,
        address,
        registrationNumber: regNo,
        contactPhone: phone,
        contactEmail: email,
        presidentName,
        appSubtitle,
        customLogoUrl,
        themePrimaryColor,
        themeSecondaryColor,
        themeAccentColor,
      });
      updateSettingsState(updated);
      setSaveStatus('संस्था व अ‍ॅप माहिती यशस्वीरीत्या जतन केली!');
    } catch (err: any) {
      setErrorStatus(err.message || 'त्रुटी: सेटिंग्ज जतन होऊ शकल्या नाहीत');
    } finally {
      setIsSaving(false);
    }
  };

  // Save Security Settings (B. Login & Security)
  const handleSaveSecurity = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaveStatus('');
    setErrorStatus('');
    setIsSaving(true);
    try {
      const updated = await api.settings.update({
        allowStaffLogin,
        allowMemberLogin,
        sessionTimeoutMinutes: Number(sessionTimeoutMinutes),
        requirePasswordMinLength: Number(requirePasswordMinLength),
        maxFailedLoginAttempts: Number(maxFailedLoginAttempts),
      });
      updateSettingsState(updated);
      setSaveStatus('लॉगिन व सुरक्षा नियमावली यशस्वीरीत्या जतन केली!');
    } catch (err: any) {
      setErrorStatus(err.message || 'Error updating security settings');
    } finally {
      setIsSaving(false);
    }
  };

  // Save Member Management Rules (C. Member Management)
  const handleSaveMemberRules = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaveStatus('');
    setErrorStatus('');
    setIsSaving(true);
    try {
      const updated = await api.settings.update({
        memberIdPrefix,
        memberIdDigits: Number(memberIdDigits),
        autoAssignMemberId,
        requireEmailForMembers,
        requireAddressForMembers,
      });
      updateSettingsState(updated);
      setSaveStatus('सभासद व्यवस्थापन नियमावली यशस्वीरीत्या जतन केली!');
    } catch (err: any) {
      setErrorStatus(err.message || 'Error updating member settings');
    } finally {
      setIsSaving(false);
    }
  };

  // Save Payment & Receipt Settings (D. Payment & Receipt)
  const handleSavePayments = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaveStatus('');
    setErrorStatus('');
    setIsSaving(true);
    try {
      const updated = await api.settings.update({
        standardContributionPaise: Math.round(monthlyContribution * 100),
        dueDayOfMonth: Number(dueDay),
        enableCashPayments,
        enableUpiPayments,
        enableBankTransfer,
        bankName,
        bankAccountNumber,
        bankIfsc,
        upiId,
        receiptPrefix,
        receiptStartNumber: Number(receiptStartNumber),
        receiptIssuedBy,
        receiptPresidentName,
        receiptFooterNote,
        showFinancialSummaryToMembers,
        razorpayKeyId: rzpKeyId,
        ...(rzpKeySecret !== '••••••••••••••••' && { razorpayKeySecret: rzpKeySecret }),
        ...(rzpWebhookSecret !== '••••••••••••••••' && { razorpayWebhookSecret: rzpWebhookSecret }),
        isSandbox,
      });
      updateSettingsState(updated);
      setSaveStatus('वर्गणी, बँक तपशील व पावती सेटिंग्ज यशस्वीरीत्या जतन केल्या!');
    } catch (err: any) {
      setErrorStatus(err.message || 'Error updating payment settings');
    } finally {
      setIsSaving(false);
    }
  };

  // Save Notifications Settings (F. Notifications)
  const handleSaveNotifications = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaveStatus('');
    setErrorStatus('');
    setIsSaving(true);
    try {
      const updated = await api.settings.update({
        enablePaymentReminders,
        reminderDaysBeforeDue: Number(reminderDaysBeforeDue),
        enablePaymentConfirmationSms,
        enableOverdueAlerts,
        enableAdminPaymentAlerts,
      });
      updateSettingsState(updated);
      setSaveStatus('सूचना व स्मरणपत्र सेटिंग्ज यशस्वीरीत्या जतन केल्या!');
    } catch (err: any) {
      setErrorStatus(err.message || 'Error updating notification settings');
    } finally {
      setIsSaving(false);
    }
  };

  // Handle Admin Password Change
  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPassMsg('');
    setPassError('');

    if (newPassword.length < (settings?.requirePasswordMinLength || 6)) {
      setPassError(`नवीन पासवर्ड किमान ${settings?.requirePasswordMinLength || 6} अक्षरांचा असावा`);
      return;
    }

    if (newPassword !== confirmPassword) {
      setPassError('नवीन पासवर्ड व पुष्टी पासवर्ड जुळत नाहीत');
      return;
    }

    try {
      const res = await api.auth.changePassword({ currentPassword, newPassword });
      setPassMsg(res.message);
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (err: any) {
      setPassError(err.message || 'पासवर्ड बदलताना त्रुटी आली');
    }
  };

  // Handle Add Staff User
  const handleAddStaffUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorStatus('');
    setSaveStatus('');
    try {
      await api.admin.createStaffUser({
        name: newStaffName,
        email: newStaffEmail,
        mobile: newStaffMobile,
        password: newStaffPassword,
        permissions: newStaffPermissions,
      });
      setShowAddStaffModal(false);
      setNewStaffName('');
      setNewStaffEmail('');
      setNewStaffMobile('');
      setNewStaffPassword('staff123');
      setSaveStatus('नवीन कर्मचारी खाते यशस्वीरित्या तयार केले!');
      loadStaffUsers();
    } catch (err: any) {
      setErrorStatus(err.message || 'कर्मचारी खाते तयार करताना त्रुटी आली');
    }
  };

  // Handle Toggle Staff Account Status
  const handleToggleStaffStatus = async (staffUser: User) => {
    const nextStatus = staffUser.status === 'active' ? 'suspended' : 'active';
    const confirmAction = window.confirm(
      `तुम्हाला खात्री आहे का? ${staffUser.name} चे खाते ${nextStatus === 'suspended' ? 'निलंबित (Suspend)' : 'सक्रिय (Activate)'} करायचे आहे?`
    );
    if (!confirmAction) return;

    try {
      await api.admin.updateStaffUser(staffUser.id, { status: nextStatus });
      setSaveStatus(`${staffUser.name} चे खाते यशस्वीरीत्या ${nextStatus === 'suspended' ? 'निलंबित' : 'सक्रिय'} केले!`);
      loadStaffUsers();
    } catch (err: any) {
      setErrorStatus(err.message || 'त्रुटी');
    }
  };

  // Handle Reset Staff Password
  const handleResetStaffPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resetStaffTarget || !resetStaffPassInput) return;
    try {
      const res = await api.admin.resetStaffPassword(resetStaffTarget.id, resetStaffPassInput);
      setSaveStatus(res.message);
      setResetStaffTarget(null);
      setResetStaffPassInput('');
    } catch (err: any) {
      setErrorStatus(err.message || 'त्रुटी आली');
    }
  };

  // Handle Broadcast Announcement
  const handleSendBroadcast = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!broadcastTitle || !broadcastMessage) return;
    setBroadcastStatus('पाठवत आहे...');
    try {
      await api.notifications.sendAnnouncement({
        title: broadcastTitle,
        message: broadcastMessage,
      });
      setBroadcastStatus('सर्व सभासदांना सूचना यशस्वीरीत्या प्रसारित केली!');
      setBroadcastTitle('');
      setBroadcastMessage('');
    } catch (err: any) {
      setBroadcastStatus('त्रुटी: ' + (err.message || 'संदेश पाठवता आला नाही'));
    }
  };

  // Guard for authorized Admin users only
  if (!isAdmin) {
    return (
      <div className="bg-white rounded-3xl p-8 border border-rose-200 shadow-sm text-center max-w-xl mx-auto my-12">
        <div className="w-16 h-16 bg-rose-100 text-rose-600 rounded-full flex items-center justify-center mx-auto mb-4">
          <ShieldAlert className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-extrabold text-blue-950 mb-2">
          प्रशासक परवानगी आवश्यक (Administrator Privileges Required)
        </h2>
        <p className="text-sm text-slate-600 leading-relaxed">
          संस्थेच्या अंतर्गत धोरणानुसार, संपूर्ण अ‍ॅप-व्यापी सेटिंग्ज आणि बदल केवळ अधिकृत प्रशासक (Admin) खात्याद्वारेच करता येतात. कर्मचारी आणि सदस्यांना या विभागात प्रवेश नाकारला आहे.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Top Main Banner & Header */}
      <div className="bg-gradient-to-r from-blue-950 via-blue-900 to-indigo-950 rounded-3xl p-6 sm:p-8 text-white shadow-lg border border-blue-800/40 flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative overflow-hidden">
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex items-center gap-4 relative z-10">
          <div className="p-3.5 bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 shadow-inner flex-shrink-0">
            <Settings className="w-8 h-8 text-amber-400 animate-spin-slow" />
          </div>
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 text-xs font-bold mb-1.5 border border-amber-400/30">
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
              <span>प्रशासक नियंत्रण कक्ष • Admin Control Center</span>
            </div>
            <h1 className="text-xl sm:text-2xl lg:text-3xl font-black tracking-tight">
              संस्था व अ‍ॅप सेटिंग्ज (Admin Settings & Modify App)
            </h1>
            <p className="text-xs sm:text-sm text-blue-200 mt-1 max-w-2xl leading-relaxed">
              एकता सेवा भावी संस्था • अ‍ॅप ब्रँडिंग, सुरक्षा, सभासद, वर्गणी, कर्मचारी परवानग्या व संपूर्ण डेटा व्यवस्थापन
            </p>
          </div>
        </div>

        {/* Quick Database Backup Trigger */}
        <div className="flex items-center gap-3 relative z-10">
          <a
            href={api.admin.getBackupUrl()}
            download
            className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer border border-emerald-400/30"
            title="Download secure database JSON backup"
          >
            <Database className="w-4 h-4 text-emerald-200" />
            <span>डेटाबेस बॅकअप (JSON)</span>
          </a>
        </div>
      </div>

      {/* Global Success / Error Alerts */}
      {saveStatus && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded-2xl text-xs sm:text-sm flex items-center gap-3 shadow-xs animate-in fade-in">
          <CheckCircle className="w-5 h-5 text-emerald-600 flex-shrink-0" />
          <span className="font-semibold">{saveStatus}</span>
        </div>
      )}

      {errorStatus && (
        <div className="p-4 bg-rose-50 border border-rose-200 text-rose-900 rounded-2xl text-xs sm:text-sm flex items-center gap-3 shadow-xs animate-in fade-in">
          <AlertCircle className="w-5 h-5 text-rose-600 flex-shrink-0" />
          <span className="font-semibold">{errorStatus}</span>
        </div>
      )}

      {/* Navigation Tabs - Mobile scrollable and desktop layout */}
      <div className="bg-white rounded-2xl p-2 border border-slate-200 shadow-xs overflow-x-auto scrollbar-none">
        <div className="flex items-center space-x-1 min-w-max">
          <button
            onClick={() => { setActiveTab('modify_app'); setSaveStatus(''); setErrorStatus(''); }}
            className={`px-3 py-2 text-xs sm:text-sm font-bold rounded-xl transition-all flex items-center gap-2 ${
              activeTab === 'modify_app'
                ? 'bg-blue-800 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Building className="w-4 h-4" />
            <span>A. Modify App (अ‍ॅप माहिती)</span>
          </button>

          <button
            onClick={() => { setActiveTab('security'); setSaveStatus(''); setErrorStatus(''); }}
            className={`px-3 py-2 text-xs sm:text-sm font-bold rounded-xl transition-all flex items-center gap-2 ${
              activeTab === 'security'
                ? 'bg-blue-800 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Lock className="w-4 h-4" />
            <span>B. सुरक्षा व लॉगिन (Security)</span>
          </button>

          <button
            onClick={() => { setActiveTab('members'); setSaveStatus(''); setErrorStatus(''); }}
            className={`px-3 py-2 text-xs sm:text-sm font-bold rounded-xl transition-all flex items-center gap-2 ${
              activeTab === 'members'
                ? 'bg-blue-800 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>C. सभासद नियमावली (Members)</span>
          </button>

          <button
            onClick={() => { setActiveTab('payments'); setSaveStatus(''); setErrorStatus(''); }}
            className={`px-3 py-2 text-xs sm:text-sm font-bold rounded-xl transition-all flex items-center gap-2 ${
              activeTab === 'payments'
                ? 'bg-blue-800 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <CreditCard className="w-4 h-4" />
            <span>D. वर्गणी व पावती (Payments)</span>
          </button>

          <button
            onClick={() => { setActiveTab('staff'); setSaveStatus(''); setErrorStatus(''); }}
            className={`px-3 py-2 text-xs sm:text-sm font-bold rounded-xl transition-all flex items-center gap-2 ${
              activeTab === 'staff'
                ? 'bg-blue-800 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <UserCheck className="w-4 h-4" />
            <span>E. कर्मचारी व परवानग्या (Staff)</span>
          </button>

          <button
            onClick={() => { setActiveTab('notifications'); setSaveStatus(''); setErrorStatus(''); }}
            className={`px-3 py-2 text-xs sm:text-sm font-bold rounded-xl transition-all flex items-center gap-2 ${
              activeTab === 'notifications'
                ? 'bg-blue-800 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Bell className="w-4 h-4" />
            <span>F. सूचना (Notifications)</span>
          </button>

          <button
            onClick={() => { setActiveTab('reports_data'); setSaveStatus(''); setErrorStatus(''); }}
            className={`px-3 py-2 text-xs sm:text-sm font-bold rounded-xl transition-all flex items-center gap-2 ${
              activeTab === 'reports_data'
                ? 'bg-blue-800 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Database className="w-4 h-4" />
            <span>G. अहवाल व बॅकअप (Data)</span>
          </button>

          <button
            onClick={() => { setActiveTab('appearance'); setSaveStatus(''); setErrorStatus(''); }}
            className={`px-3 py-2 text-xs sm:text-sm font-bold rounded-xl transition-all flex items-center gap-2 ${
              activeTab === 'appearance'
                ? 'bg-blue-800 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Globe className="w-4 h-4" />
            <span>H. भाषा व स्वरूप (Appearance)</span>
          </button>

          <button
            onClick={() => { setActiveTab('app_info'); setSaveStatus(''); setErrorStatus(''); }}
            className={`px-3 py-2 text-xs sm:text-sm font-bold rounded-xl transition-all flex items-center gap-2 ${
              activeTab === 'app_info'
                ? 'bg-blue-800 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Info className="w-4 h-4" />
            <span>I. अ‍ॅप माहिती (App Info)</span>
          </button>

          <button
            onClick={() => { setActiveTab('audit'); setSaveStatus(''); setErrorStatus(''); }}
            className={`px-3 py-2 text-xs sm:text-sm font-bold rounded-xl transition-all flex items-center gap-2 ${
              activeTab === 'audit'
                ? 'bg-blue-800 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <History className="w-4 h-4" />
            <span>ऑडिट लॉग (Audit Log)</span>
          </button>
        </div>
      </div>

      {/* ========================================================= */}
      {/* SECTION A: MODIFY APP (Organization & Branding) */}
      {/* ========================================================= */}
      {activeTab === 'modify_app' && (
        <form onSubmit={handleSaveModifyApp} className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
            <div>
              <h2 className="text-lg sm:text-xl font-black text-blue-950 flex items-center gap-2">
                <Building className="w-5 h-5 text-blue-800" />
                <span>A. Modify App (संस्था माहिती, लोगो व ब्रँडिंग)</span>
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                संस्थेचे नाव, पत्ता, अध्यक्ष नाव, नोंदणी क्रमांक आणि अधिकृत लोगो व्यवस्थापन
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleCancelChanges}
                className="px-4 py-2 border border-slate-300 text-slate-700 hover:bg-slate-100 font-bold text-xs sm:text-sm rounded-xl transition-all"
              >
                रद्द करा (Cancel)
              </button>
              <button
                type="submit"
                disabled={isSaving}
                className="px-5 py-2 bg-blue-800 hover:bg-blue-900 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
              >
                <Save className="w-4 h-4" />
                <span>{isSaving ? 'जतन होत आहे...' : 'बदल जतन करा (Save Changes)'}</span>
              </button>
            </div>
          </div>

          {/* Logo Upload & Realtime Preview Card */}
          <div className="p-5 bg-gradient-to-r from-blue-50/70 to-indigo-50/70 border border-blue-200/80 rounded-2xl flex flex-col md:flex-row items-center gap-6">
            <div className="flex flex-col items-center gap-2 flex-shrink-0">
              <span className="text-xs font-bold text-blue-950">सध्याचा लोगो पूर्वावलोकन</span>
              <SansthaLogo size="xl" customUrl={customLogoUrl} />
            </div>

            <div className="flex-1 space-y-3 text-center md:text-left">
              <div>
                <h3 className="text-sm font-black text-blue-950">
                  अधिकृत संस्था लोगो अपलोड करा (Organization Logo Upload)
                </h3>
                <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                  हा लोगो डॅशबोर्ड, पावती प्रिंट, लॉगिन स्क्रीन आणि मोबाइल अ‍ॅपमध्ये आपोआप प्रदर्शित होईल. (PNG, JPG, SVG, कमाल १.५ MB).
                </p>
              </div>

              <div className="flex flex-wrap items-center justify-center md:justify-start gap-3">
                <label className="px-4 py-2 bg-blue-800 hover:bg-blue-900 text-white font-bold text-xs rounded-xl cursor-pointer flex items-center gap-2 shadow-xs transition-colors">
                  <Upload className="w-4 h-4" />
                  <span>नवीन लोगो फाइल निवडा</span>
                  <input
                    type="file"
                    accept="image/png, image/jpeg, image/svg+xml, image/webp"
                    onChange={handleLogoUpload}
                    className="hidden"
                  />
                </label>

                {customLogoUrl && (
                  <button
                    type="button"
                    onClick={handleResetLogo}
                    className="px-3.5 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold text-xs rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>मूळ लोगो पुनर्स्थापित करा (Restore Default)</span>
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Form Fields Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Organization Name (English) *
              </label>
              <input
                type="text"
                required
                value={orgName}
                onChange={(e) => setOrgName(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:bg-white focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                संस्थेचे नाव (मराठी) *
              </label>
              <input
                type="text"
                required
                value={marathiName}
                onChange={(e) => setMarathiName(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:bg-white focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                संस्था नाव (हिंदी)
              </label>
              <input
                type="text"
                value={hindiName}
                onChange={(e) => setHindiName(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:bg-white focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                संस्था अध्यक्ष / प्रमुख नाव (President / Chairperson) *
              </label>
              <input
                type="text"
                required
                value={presidentName}
                onChange={(e) => setPresidentName(e.target.value)}
                placeholder="उदा. संतोषराव माळी (अध्यक्ष)"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:bg-white focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                नोंदणी क्रमांक (Registration Number) *
              </label>
              <input
                type="text"
                required
                value={regNo}
                onChange={(e) => setRegNo(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:bg-white focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                संपर्क मोबाईल नंबर (Contact Phone) *
              </label>
              <input
                type="text"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:bg-white focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                अधिकृत ईमेल (Contact Email)
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:bg-white focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                संस्थेचा संपूर्ण पत्ता (Headquarters Address) *
              </label>
              <input
                type="text"
                required
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:bg-white focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                अ‍ॅप उपशीर्षक व स्वागत संदेश (App Subtitle & Welcome Message)
              </label>
              <textarea
                rows={2}
                value={appSubtitle}
                onChange={(e) => setAppSubtitle(e.target.value)}
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:bg-white focus:ring-2 focus:ring-blue-600"
              />
            </div>
          </div>

          {/* Theme Color and Branding Palette Section */}
          <div className="p-5 bg-slate-50 rounded-2xl border border-slate-200 space-y-4">
            <h3 className="text-sm font-black text-blue-950 flex items-center gap-2">
              <Palette className="w-4 h-4 text-blue-800" />
              <span>थीम रंग व ब्रँडिंग पॅलेट (Theme Color & Branding Settings)</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  मुख्य रंग (Primary Blue)
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={themePrimaryColor}
                    onChange={(e) => setThemePrimaryColor(e.target.value)}
                    className="w-10 h-10 rounded-lg cursor-pointer border border-slate-300 p-0.5"
                  />
                  <input
                    type="text"
                    value={themePrimaryColor}
                    onChange={(e) => setThemePrimaryColor(e.target.value)}
                    className="flex-1 px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-mono font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  दुय्यम रंग (Secondary Amber)
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={themeSecondaryColor}
                    onChange={(e) => setThemeSecondaryColor(e.target.value)}
                    className="w-10 h-10 rounded-lg cursor-pointer border border-slate-300 p-0.5"
                  />
                  <input
                    type="text"
                    value={themeSecondaryColor}
                    onChange={(e) => setThemeSecondaryColor(e.target.value)}
                    className="flex-1 px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-mono font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  हायलाइट रंग (Accent Emerald)
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={themeAccentColor}
                    onChange={(e) => setThemeAccentColor(e.target.value)}
                    className="w-10 h-10 rounded-lg cursor-pointer border border-slate-300 p-0.5"
                  />
                  <input
                    type="text"
                    value={themeAccentColor}
                    onChange={(e) => setThemeAccentColor(e.target.value)}
                    className="flex-1 px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-mono font-bold"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={handleCancelChanges}
              className="px-4 py-2.5 border border-slate-300 text-slate-700 hover:bg-slate-100 font-bold text-xs sm:text-sm rounded-xl transition-all"
            >
              रद्द करा (Cancel)
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="px-6 py-2.5 bg-blue-800 hover:bg-blue-900 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              <span>{isSaving ? 'जतन होत आहे...' : 'बदल जतन करा (Save Changes)'}</span>
            </button>
          </div>
        </form>
      )}

      {/* ========================================================= */}
      {/* SECTION B: LOGIN & SECURITY SETTINGS */}
      {/* ========================================================= */}
      {activeTab === 'security' && (
        <div className="space-y-6">
          <form onSubmit={handleSaveSecurity} className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div>
                <h2 className="text-lg sm:text-xl font-black text-blue-950 flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-blue-800" />
                  <span>B. Login & Security Settings (लॉगिन व सुरक्षा धोरण)</span>
                </h2>
                <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                  प्रशासक, स्टाफ आणि सभासद लॉगिन अधिकार, सत्र कालावधी आणि सुरक्षा नियंत्रणे
                </p>
              </div>
              <button
                type="submit"
                disabled={isSaving}
                className="px-5 py-2.5 bg-blue-800 hover:bg-blue-900 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
              >
                <Save className="w-4 h-4" />
                <span>सुरक्षा सेटिंग्ज जतन करा</span>
              </button>
            </div>

            {/* Login Access Controls */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                <span className="text-xs font-bold text-slate-500 uppercase">लॉगिन पोर्टल प्रवेश नियंत्रणे</span>
                
                <div className="flex items-center justify-between p-3 bg-white rounded-xl border border-slate-200">
                  <div>
                    <span className="font-bold text-xs sm:text-sm text-blue-950 block">प्रशासक लॉगिन (Admin Login)</span>
                    <span className="text-[11px] text-slate-500">संस्था नियंत्रणासाठी नेहमी सक्रिय</span>
                  </div>
                  <span className="px-2.5 py-1 text-xs font-bold bg-emerald-100 text-emerald-800 rounded-full">कायम सक्रिय</span>
                </div>

                <div className="flex items-center justify-between p-3 bg-white rounded-xl border border-slate-200">
                  <div>
                    <span className="font-bold text-xs sm:text-sm text-blue-950 block">स्टाफ लॉगिन (Staff Login)</span>
                    <span className="text-[11px] text-slate-500">कार्यालय कर्मचाऱ्यांसाठी लॉगिन सुरू ठेवा</span>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={allowStaffLogin}
                      onChange={(e) => setAllowStaffLogin(e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-slate-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-800" />
                  </label>
                </div>

                <div className="flex items-center justify-between p-3 bg-white rounded-xl border border-slate-200">
                  <div>
                    <span className="font-bold text-xs sm:text-sm text-blue-950 block">सदस्य लॉगिन (Member Login)</span>
                    <span className="text-[11px] text-slate-500">नोंदणीकृत सभासदांसाठी पोर्टल लॉगिन सुरू ठेवा</span>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={allowMemberLogin}
                      onChange={(e) => setAllowMemberLogin(e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-slate-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-800" />
                  </label>
                </div>
              </div>

              {/* Session and Security Parameters */}
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-4">
                <span className="text-xs font-bold text-slate-500 uppercase">सत्र व सुरक्षा मापदंड</span>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    सत्र मुदत समाप्ती (Session Timeout in Minutes)
                  </label>
                  <select
                    value={sessionTimeoutMinutes}
                    onChange={(e) => setSessionTimeoutMinutes(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-sm"
                  >
                    <option value={30}>30 मिनिटे (High Security)</option>
                    <option value={60}>60 मिनिटे (1 तास)</option>
                    <option value={120}>120 मिनिटे (2 तास - शिफारस केलेले)</option>
                    <option value={240}>240 मिनिटे (4 तास)</option>
                    <option value={480}>480 मिनिटे (8 तास)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    किमान पासवर्ड लांबी (Minimum Password Length)
                  </label>
                  <input
                    type="number"
                    min={6}
                    max={16}
                    value={requirePasswordMinLength}
                    onChange={(e) => setRequirePasswordMinLength(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    कमाल अयशस्वी प्रयत्न मर्यादा (Max Failed Attempts before Cooldown)
                  </label>
                  <input
                    type="number"
                    min={3}
                    max={10}
                    value={maxFailedLoginAttempts}
                    onChange={(e) => setMaxFailedLoginAttempts(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-sm"
                  />
                </div>
              </div>
            </div>

            {/* Zero Secret Exposure Notice */}
            <div className="p-4 bg-blue-50/80 border border-blue-200 rounded-2xl text-xs text-blue-950 flex items-start gap-3">
              <ShieldAlert className="w-5 h-5 text-blue-700 flex-shrink-0 mt-0.5" />
              <div>
                <span className="font-bold block mb-0.5">एनक्रिप्टेड पासवर्ड सुरक्षा खात्री:</span>
                सिस्टममधील पासवर्ड scrypt अल्गोरिदमद्वारे सॉल्टसह हॅश केले जातात. मूळ पासवर्ड किंवा गुप्त टोकन कोणत्याही स्क्रीनवर कधीही उघड केले जात नाहीत.
              </div>
            </div>
          </form>

          {/* Change Admin Password Card */}
          <form onSubmit={handleChangePassword} className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4">
            <h3 className="text-base font-extrabold text-blue-950 flex items-center gap-2">
              <KeyRound className="w-5 h-5 text-amber-600" />
              <span>प्रशासक पासवर्ड सुरक्षितपणे बदला (Change Admin Password)</span>
            </h3>

            {passMsg && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-600" />
                <span>{passMsg}</span>
              </div>
            )}
            {passError && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600" />
                <span>{passError}</span>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  सध्याचा पासवर्ड *
                </label>
                <input
                  type="password"
                  required
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:bg-white focus:ring-2 focus:ring-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  नवीन पासवर्ड *
                </label>
                <input
                  type="password"
                  required
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="किमान ६ अक्षरे"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:bg-white focus:ring-2 focus:ring-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  नवीन पासवर्ड पुन्हा टाका *
                </label>
                <input
                  type="password"
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="पुष्टी करा"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:bg-white focus:ring-2 focus:ring-blue-600"
                />
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="submit"
                className="px-5 py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer"
              >
                <Lock className="w-4 h-4" />
                <span>पासवर्ड अद्यतनित करा</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ========================================================= */}
      {/* SECTION C: MEMBER MANAGEMENT RULES */}
      {/* ========================================================= */}
      {activeTab === 'members' && (
        <form onSubmit={handleSaveMemberRules} className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div>
              <h2 className="text-lg sm:text-xl font-black text-blue-950 flex items-center gap-2">
                <Users className="w-5 h-5 text-blue-800" />
                <span>C. Member Management Settings (सभासद व्यवस्थापन नियमावली)</span>
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                सदस्य आयडी फॉरमॅट, प्रोफाइल फील्ड्स आणि सभासद डेटा संरक्षण
              </p>
            </div>
            <button
              type="submit"
              disabled={isSaving}
              className="px-5 py-2.5 bg-blue-800 hover:bg-blue-900 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              <span>सभासद नियम जतन करा</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-4">
              <span className="text-xs font-bold text-slate-500 uppercase">सदस्य आयडी (Member ID) संरचना</span>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  सदस्य आयडी उपसर्ग (Prefix) *
                </label>
                <input
                  type="text"
                  required
                  value={memberIdPrefix}
                  onChange={(e) => setMemberIdPrefix(e.target.value.toUpperCase())}
                  placeholder="उदा. M किंवा ESBS"
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-sm font-mono font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  क्रमांक संख्या लांबी (Digits Padding)
                </label>
                <input
                  type="number"
                  min={2}
                  max={6}
                  value={memberIdDigits}
                  onChange={(e) => setMemberIdDigits(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-sm font-mono font-bold"
                />
                <span className="text-[11px] text-slate-500 mt-1 block">
                  फॉरमॅट पूर्वावलोकन: <strong className="text-blue-900 font-mono">{memberIdPrefix}{'0'.repeat(Math.max(0, memberIdDigits - 1))}1</strong> (उदा. {memberIdPrefix}001, {memberIdPrefix}002)
                </span>
              </div>

              <div className="flex items-center justify-between p-3 bg-white rounded-xl border border-slate-200">
                <div>
                  <span className="font-bold text-xs text-blue-950 block">स्वयंचलित आयडी वाटप (Auto-assign ID)</span>
                  <span className="text-[11px] text-slate-500">नवीन सदस्य जोडताना आपोआप पुढील अनुक्रमांक देणे</span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={autoAssignMemberId}
                    onChange={(e) => setAutoAssignMemberId(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-800" />
                </label>
              </div>
            </div>

            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-4">
              <span className="text-xs font-bold text-slate-500 uppercase">सदस्य प्रोफाइल अनिवार्य फील्ड्स</span>

              <div className="flex items-center justify-between p-3 bg-white rounded-xl border border-slate-200">
                <div>
                  <span className="font-bold text-xs text-blue-950 block">ईमेल पत्ता अनिवार्य करा</span>
                  <span className="text-[11px] text-slate-500">सदस्य नोंदणी करताना ईमेल अनिवार्य असावा का</span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={requireEmailForMembers}
                    onChange={(e) => setRequireEmailForMembers(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-800" />
                </label>
              </div>

              <div className="flex items-center justify-between p-3 bg-white rounded-xl border border-slate-200">
                <div>
                  <span className="font-bold text-xs text-blue-950 block">रहिवासी पत्ता अनिवार्य करा</span>
                  <span className="text-[11px] text-slate-500">माळी गल्ली किंवा स्थानिक पत्ता नोंदवणे बंधनकारक</span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={requireAddressForMembers}
                    onChange={(e) => setRequireAddressForMembers(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-800" />
                </label>
              </div>
            </div>
          </div>

          <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-xs text-emerald-950 flex items-start gap-3">
            <CheckCircle className="w-5 h-5 text-emerald-600 flex-shrink-0 mt-0.5" />
            <div>
              <span className="font-bold block mb-0.5">सभासद नोंदी संरक्षण हमी:</span>
              संस्थेच्या सर्व विद्यमान १५+ नोंदणीकृत सभासदांची माहिती, त्यांचे मोबाइल क्रमांक, पत्ते व मासिक हप्ते डेटाबेसमध्ये सुरक्षित आणि अबाधित राहतील.
            </div>
          </div>
        </form>
      )}

      {/* ========================================================= */}
      {/* SECTION D: PAYMENT & RECEIPT SETTINGS */}
      {/* ========================================================= */}
      {activeTab === 'payments' && (
        <form onSubmit={handleSavePayments} className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div>
              <h2 className="text-lg sm:text-xl font-black text-blue-950 flex items-center gap-2">
                <Receipt className="w-5 h-5 text-blue-800" />
                <span>D. Payment & Receipt Settings (मासिक वर्गणी व पावती सेटिंग्ज)</span>
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                मासिक वर्गणी रक्कम, रोख/UPI/बँक ट्रान्सफर, पावती उपसर्ग व अधिकृत तपशील
              </p>
            </div>
            <button
              type="submit"
              disabled={isSaving}
              className="px-5 py-2.5 bg-blue-800 hover:bg-blue-900 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              <span>पेमेंट सेटिंग्ज जतन करा</span>
            </button>
          </div>

          {/* Core Contribution & Due Day */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                प्रमाणित मासिक वर्गणी रक्कम (रुपये) *
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500 font-bold">
                  ₹
                </span>
                <input
                  type="number"
                  required
                  min={100}
                  step={50}
                  value={monthlyContribution}
                  onChange={(e) => setMonthlyContribution(Number(e.target.value))}
                  className="w-full pl-8 pr-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-bold text-blue-950 focus:bg-white focus:ring-2 focus:ring-blue-600"
                />
              </div>
              <span className="text-[11px] text-slate-500 mt-1 block">
                सर्व सभासदांसाठी प्रमाणित मासिक वर्गणी (उदा. ₹1,000 / महिना)
              </span>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                मासिक हप्ता अंतिम देय तारीख (Due Day of Month) *
              </label>
              <input
                type="number"
                required
                min={1}
                max={28}
                value={dueDay}
                onChange={(e) => setDueDay(Number(e.target.value))}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-bold focus:bg-white focus:ring-2 focus:ring-blue-600"
              />
              <span className="text-[11px] text-slate-500 mt-1 block">
                दर महिन्याची अंतिम तारीख (उदा. 10 तारीख)
              </span>
            </div>
          </div>

          {/* Payment Methods Allowed */}
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
            <span className="text-xs font-bold text-slate-500 uppercase">स्वीकृत पेमेंट पद्धती (Accepted Payment Methods)</span>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <label className="flex items-center gap-3 p-3 bg-white rounded-xl border border-slate-200 cursor-pointer">
                <input
                  type="checkbox"
                  checked={enableCashPayments}
                  onChange={(e) => setEnableCashPayments(e.target.checked)}
                  className="w-4 h-4 text-blue-800 rounded"
                />
                <div>
                  <span className="text-xs font-bold text-blue-950 block">रोख जमा (Cash)</span>
                  <span className="text-[10px] text-slate-500">कार्यालयात रोख पावती</span>
                </div>
              </label>

              <label className="flex items-center gap-3 p-3 bg-white rounded-xl border border-slate-200 cursor-pointer">
                <input
                  type="checkbox"
                  checked={enableUpiPayments}
                  onChange={(e) => setEnableUpiPayments(e.target.checked)}
                  className="w-4 h-4 text-blue-800 rounded"
                />
                <div>
                  <span className="text-xs font-bold text-blue-950 block">UPI / QR कोड</span>
                  <span className="text-[10px] text-slate-500">ऑनलाइन त्वरित UPI</span>
                </div>
              </label>

              <label className="flex items-center gap-3 p-3 bg-white rounded-xl border border-slate-200 cursor-pointer">
                <input
                  type="checkbox"
                  checked={enableBankTransfer}
                  onChange={(e) => setEnableBankTransfer(e.target.checked)}
                  className="w-4 h-4 text-blue-800 rounded"
                />
                <div>
                  <span className="text-xs font-bold text-blue-950 block">बँक ट्रान्सफर (NEFT/IMPS)</span>
                  <span className="text-[10px] text-slate-500">संस्थेच्या बँक खात्यावर</span>
                </div>
              </label>
            </div>
          </div>

          {/* Bank & UPI Details */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            <div className="md:col-span-2">
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                संस्थेचा UPI ID / VPA *
              </label>
              <input
                type="text"
                value={upiId}
                onChange={(e) => setUpiId(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-mono font-bold"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                बँकेचे नाव (Bank Name)
              </label>
              <input
                type="text"
                value={bankName}
                onChange={(e) => setBankName(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                बँक खाते क्र. (Account Number)
              </label>
              <input
                type="text"
                value={bankAccountNumber}
                onChange={(e) => setBankAccountNumber(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                IFSC कोड
              </label>
              <input
                type="text"
                value={bankIfsc}
                onChange={(e) => setBankIfsc(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-mono"
              />
            </div>
          </div>

          {/* Receipt Customization Details */}
          <div className="p-5 bg-slate-50 rounded-2xl border border-slate-200 space-y-4">
            <h3 className="text-sm font-black text-blue-950 flex items-center gap-2">
              <FileSpreadsheet className="w-4 h-4 text-blue-800" />
              <span>पावती डिझाइन व माहिती (Receipt Header & Signatory Settings)</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  पावती उपसर्ग (Receipt Prefix) *
                </label>
                <input
                  type="text"
                  required
                  value={receiptPrefix}
                  onChange={(e) => setReceiptPrefix(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-sm font-mono font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  पावती स्वीकारणारा (Received By Officer)
                </label>
                <input
                  type="text"
                  value={receiptIssuedBy}
                  onChange={(e) => setReceiptIssuedBy(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  पावतीवरील अध्यक्ष नाव (President Signatory)
                </label>
                <input
                  type="text"
                  value={receiptPresidentName}
                  onChange={(e) => setReceiptPresidentName(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-sm"
                />
              </div>

              <div className="sm:col-span-3">
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  पावती तळटीप (Receipt Footer Note)
                </label>
                <input
                  type="text"
                  value={receiptFooterNote}
                  onChange={(e) => setReceiptFooterNote(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-sm"
                />
              </div>
            </div>

            {/* Financial summary toggle for members */}
            <div className="flex items-center justify-between p-3 bg-white rounded-xl border border-slate-200 mt-2">
              <div>
                <span className="font-bold text-xs text-blue-950 block">
                  सभासदांना संस्था एकत्रित जमा-खर्च सारांश दाखवा
                </span>
                <span className="text-[11px] text-slate-500">
                  सभासदांच्या पोर्टलवर अधिकृत एकत्रित आर्थिक स्थिती कार्ड दाखवणे
                </span>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={showFinancialSummaryToMembers}
                  onChange={(e) => setShowFinancialSummaryToMembers(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-slate-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-800" />
              </label>
            </div>
          </div>
        </form>
      )}

      {/* ========================================================= */}
      {/* SECTION E: STAFF & PERMISSIONS */}
      {/* ========================================================= */}
      {activeTab === 'staff' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
            <div>
              <h2 className="text-lg sm:text-xl font-black text-blue-950 flex items-center gap-2">
                <UserCheck className="w-5 h-5 text-blue-800" />
                <span>E. Staff & Permissions (कर्मचारी खाती व परवानग्या)</span>
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                कार्यालय व्यवस्थापक, कर्मचारी खाती तयार करणे, परवानग्या वाटप आणि निलंबन
              </p>
            </div>
            <button
              onClick={() => setShowAddStaffModal(true)}
              className="px-4 py-2 bg-blue-800 hover:bg-blue-900 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>नवीन स्टाफ जोडा (Add Staff Account)</span>
            </button>
          </div>

          {/* Staff Accounts Table */}
          {isLoadingStaff ? (
            <div className="text-center py-8 text-xs text-slate-500">कर्मचारी खाती लोड होत आहेत...</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs sm:text-sm">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500 uppercase text-[11px] font-bold">
                    <th className="py-3 px-3">कर्मचारी नाव</th>
                    <th className="py-3 px-3">भूमिका</th>
                    <th className="py-3 px-3">ईमेल / मोबाईल</th>
                    <th className="py-3 px-3">स्थिती</th>
                    <th className="py-3 px-3">परवानग्या</th>
                    <th className="py-3 px-3 text-right">कृती</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {staffUsers.map((su) => (
                    <tr key={su.id} className="hover:bg-slate-50">
                      <td className="py-3 px-3 font-bold text-blue-950">
                        {su.name}
                      </td>
                      <td className="py-3 px-3">
                        <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                          su.role === 'admin' ? 'bg-amber-100 text-amber-900' : 'bg-blue-100 text-blue-900'
                        }`}>
                          {su.role === 'admin' ? 'प्रशासक (Admin)' : 'स्टाफ (Staff)'}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-slate-600">
                        <div>{su.email}</div>
                        <div className="text-[11px] text-slate-400">{su.mobile}</div>
                      </td>
                      <td className="py-3 px-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          su.status === 'active' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                        }`}>
                          {su.status === 'active' ? 'सक्रिय (Active)' : 'निलंबित (Suspended)'}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-[11px] text-slate-600">
                        {su.role === 'admin' ? (
                          <span className="font-semibold text-emerald-700">सर्व हक्क (Full Admin)</span>
                        ) : (
                          <div className="flex flex-wrap gap-1">
                            <span className="px-1.5 py-0.5 bg-slate-100 rounded">सभासद</span>
                            <span className="px-1.5 py-0.5 bg-slate-100 rounded">वर्गणी पावती</span>
                            <span className="px-1.5 py-0.5 bg-slate-100 rounded">अहवाल</span>
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-3 text-right">
                        {su.role !== 'admin' && (
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => { setResetStaffTarget(su); setResetStaffPassInput(''); }}
                              className="px-2 py-1 text-xs bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-semibold"
                            >
                              पासवर्ड रीसेट
                            </button>
                            <button
                              onClick={() => handleToggleStaffStatus(su)}
                              className={`px-2 py-1 text-xs font-semibold rounded-lg ${
                                su.status === 'active'
                                  ? 'bg-rose-50 hover:bg-rose-100 text-rose-700'
                                  : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700'
                              }`}
                            >
                              {su.status === 'active' ? 'निलंबित करा' : 'सक्रिय करा'}
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Add Staff Account Modal */}
          {showAddStaffModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
              <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
                  <h3 className="font-bold text-base text-blue-950">नवीन कर्मचारी खाते तयार करा</h3>
                  <button onClick={() => setShowAddStaffModal(false)} className="text-slate-400 hover:text-slate-600">
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <form onSubmit={handleAddStaffUser} className="space-y-3.5">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">कर्मचारी पूर्ण नाव *</label>
                    <input
                      type="text"
                      required
                      value={newStaffName}
                      onChange={(e) => setNewStaffName(e.target.value)}
                      placeholder="उदा. राहुल देशमुख"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">स्टाफ ईमेल पत्ता *</label>
                    <input
                      type="email"
                      required
                      value={newStaffEmail}
                      onChange={(e) => setNewStaffEmail(e.target.value)}
                      placeholder="rahul@ektasanstha.org"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">मोबाईल क्रमांक *</label>
                    <input
                      type="tel"
                      required
                      maxLength={10}
                      value={newStaffMobile}
                      onChange={(e) => setNewStaffMobile(e.target.value)}
                      placeholder="10 अंकी मोबाईल क्रमांक"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">सुरुवातीचा पासवर्ड *</label>
                    <input
                      type="text"
                      required
                      value={newStaffPassword}
                      onChange={(e) => setNewStaffPassword(e.target.value)}
                      placeholder="staff123"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-mono"
                    />
                  </div>

                  <div className="pt-2 flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setShowAddStaffModal(false)}
                      className="px-4 py-2 border border-slate-300 text-slate-700 text-xs font-bold rounded-xl"
                    >
                      रद्द करा
                    </button>
                    <button
                      type="submit"
                      className="px-5 py-2 bg-blue-800 text-white text-xs font-bold rounded-xl shadow-xs"
                    >
                      खाते तयार करा
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* Reset Staff Password Modal */}
          {resetStaffTarget && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
              <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-2xl">
                <h3 className="font-bold text-base text-blue-950 mb-1">
                  {resetStaffTarget.name} चा पासवर्ड बदला
                </h3>
                <p className="text-xs text-slate-500 mb-4">
                  कर्मचाऱ्यासाठी नवीन पासवर्ड प्रविष्ट करा
                </p>

                <form onSubmit={handleResetStaffPasswordSubmit} className="space-y-3">
                  <input
                    type="text"
                    required
                    value={resetStaffPassInput}
                    onChange={(e) => setResetStaffPassInput(e.target.value)}
                    placeholder="नवीन पासवर्ड (किमान ६ अक्षरे)"
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm font-mono"
                  />
                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => setResetStaffTarget(null)}
                      className="px-4 py-2 border border-slate-300 text-slate-700 text-xs font-bold rounded-xl"
                    >
                      रद्द करा
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-2 bg-blue-800 text-white text-xs font-bold rounded-xl"
                    >
                      जतन करा
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================= */}
      {/* SECTION F: NOTIFICATIONS SETTINGS & BROADCAST */}
      {/* ========================================================= */}
      {activeTab === 'notifications' && (
        <div className="space-y-6">
          <form onSubmit={handleSaveNotifications} className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div>
                <h2 className="text-lg sm:text-xl font-black text-blue-950 flex items-center gap-2">
                  <Bell className="w-5 h-5 text-blue-800" />
                  <span>F. Notification Settings (सूचना व स्मरणपत्र सेटिंग्ज)</span>
                </h2>
                <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                  हप्ता स्मरणपत्रे, थकबाकी इशारे आणि पावती पुष्टीकरण संदेश
                </p>
              </div>
              <button
                type="submit"
                disabled={isSaving}
                className="px-5 py-2.5 bg-blue-800 hover:bg-blue-900 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
              >
                <Save className="w-4 h-4" />
                <span>सूचना सेटिंग्ज जतन करा</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                <span className="text-xs font-bold text-slate-500 uppercase">स्वयंचलित सूचना प्राधान्ये</span>

                <div className="flex items-center justify-between p-3 bg-white rounded-xl border border-slate-200">
                  <div>
                    <span className="font-bold text-xs text-blue-950 block">हप्ता देय स्मरणपत्र (Due Reminders)</span>
                    <span className="text-[11px] text-slate-500">महिन्याच्या देय तारखेआधी सभासदांना स्मरण</span>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={enablePaymentReminders}
                      onChange={(e) => setEnablePaymentReminders(e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-slate-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-800" />
                  </label>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    अंतिम तारखेच्या किती दिवस आधी स्मरण द्यावे?
                  </label>
                  <select
                    value={reminderDaysBeforeDue}
                    onChange={(e) => setReminderDaysBeforeDue(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-sm"
                  >
                    <option value={1}>1 दिवस आधी</option>
                    <option value={3}>3 दिवस आधी (शिफारस केलेले)</option>
                    <option value={5}>5 दिवस आधी</option>
                    <option value={7}>7 दिवस आधी (1 आठवडा)</option>
                  </select>
                </div>
              </div>

              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                <span className="text-xs font-bold text-slate-500 uppercase">पावती व थकबाकी इशारे</span>

                <div className="flex items-center justify-between p-3 bg-white rounded-xl border border-slate-200">
                  <div>
                    <span className="font-bold text-xs text-blue-950 block">पावती पुष्टीकरण संदेश</span>
                    <span className="text-[11px] text-slate-500">वर्गणी जमा झाल्यावर सभासदास त्वरित सूचना</span>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={enablePaymentConfirmationSms}
                      onChange={(e) => setEnablePaymentConfirmationSms(e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-slate-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-800" />
                  </label>
                </div>

                <div className="flex items-center justify-between p-3 bg-white rounded-xl border border-slate-200">
                  <div>
                    <span className="font-bold text-xs text-blue-950 block">थकबाकी इशारा सूचना (Overdue Alert)</span>
                    <span className="text-[11px] text-slate-500">देय तारीख उलटून गेल्यास थकीत हप्ता सूचना</span>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={enableOverdueAlerts}
                      onChange={(e) => setEnableOverdueAlerts(e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-slate-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-800" />
                  </label>
                </div>
              </div>
            </div>
          </form>

          {/* Instant Broadcast Notice to All Members Card */}
          <form onSubmit={handleSendBroadcast} className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4">
            <h3 className="text-base font-extrabold text-blue-950 flex items-center gap-2">
              <Send className="w-5 h-5 text-indigo-700" />
              <span>सर्व सभासदांना त्वरित सार्वजनिक सूचना पाठवा (Broadcast Announcement)</span>
            </h3>

            {broadcastStatus && (
              <div className="p-3 bg-indigo-50 border border-indigo-200 text-indigo-900 rounded-xl text-xs font-semibold">
                {broadcastStatus}
              </div>
            )}

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">सूचनेचे शीर्षक *</label>
                <input
                  type="text"
                  required
                  value={broadcastTitle}
                  onChange={(e) => setBroadcastTitle(e.target.value)}
                  placeholder="उदा. आगामी वार्षिक सर्वसाधारण सभा सूचना"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">सूचनेचा तपशील / संदेश *</label>
                <textarea
                  rows={3}
                  required
                  value={broadcastMessage}
                  onChange={(e) => setBroadcastMessage(e.target.value)}
                  placeholder="कृपया सर्व सभासदांनी उपस्थित राहावे..."
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm"
                />
              </div>

              <div className="flex justify-end">
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-indigo-700 hover:bg-indigo-800 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  <span>सर्व सभासदांना संदेश पाठवा</span>
                </button>
              </div>
            </div>
          </form>
        </div>
      )}

      {/* ========================================================= */}
      {/* SECTION G: REPORTS & DATA BACKUP */}
      {/* ========================================================= */}
      {activeTab === 'reports_data' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
          <div className="pb-4 border-b border-slate-100">
            <h2 className="text-lg sm:text-xl font-black text-blue-950 flex items-center gap-2">
              <Database className="w-5 h-5 text-blue-800" />
              <span>G. Reports & Data Management (अहवाल व सुरक्षित डेटा बॅकअप)</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
              मासिक व वार्षिक वर्गणी अहवाल, सभासद यादी CSV निर्यात आणि सुरक्षित डेटाबेस बॅकअप
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {/* Export Collections CSV */}
            <div className="p-5 bg-blue-50/80 rounded-2xl border border-blue-200 space-y-3 flex flex-col justify-between">
              <div>
                <div className="p-2.5 bg-blue-800 text-white rounded-xl w-fit mb-3">
                  <FileSpreadsheet className="w-5 h-5" />
                </div>
                <h3 className="text-sm font-black text-blue-950">वर्गणी व पावती अहवाल (CSV)</h3>
                <p className="text-xs text-slate-600 mt-1">
                  सर्व सत्यापित पावत्या, देय महिना, रक्कम, संदर्भ आणि पावती क्रमांक एक्सेल/CSV स्वरूपात.
                </p>
              </div>
              <a
                href={api.reports.getExportCsvUrl()}
                download="ekta_sanstha_collections_report.csv"
                className="w-full py-2.5 bg-blue-800 hover:bg-blue-900 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-xs transition-colors"
              >
                <Download className="w-4 h-4" />
                <span>वर्गणी अहवाल डाउनलोड करा (CSV)</span>
              </a>
            </div>

            {/* Export Members CSV */}
            <div className="p-5 bg-teal-50/80 rounded-2xl border border-teal-200 space-y-3 flex flex-col justify-between">
              <div>
                <div className="p-2.5 bg-teal-700 text-white rounded-xl w-fit mb-3">
                  <Users className="w-5 h-5" />
                </div>
                <h3 className="text-sm font-black text-teal-950">सभासद यादी अहवाल (CSV)</h3>
                <p className="text-xs text-slate-600 mt-1">
                  सर्व नोंदणीकृत सभासदांची माहिती, सदस्य आयडी, मोबाईल आणि मासिक वर्गणी तपशील.
                </p>
              </div>
              <a
                href={api.admin.getMembersCsvUrl()}
                download="ekta_sanstha_members_list.csv"
                className="w-full py-2.5 bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-xs transition-colors"
              >
                <Download className="w-4 h-4" />
                <span>सभासद यादी डाउनलोड करा (CSV)</span>
              </a>
            </div>

            {/* Complete System Database Backup */}
            <div className="p-5 bg-emerald-50/80 rounded-2xl border border-emerald-200 space-y-3 flex flex-col justify-between">
              <div>
                <div className="p-2.5 bg-emerald-700 text-white rounded-xl w-fit mb-3">
                  <Database className="w-5 h-5" />
                </div>
                <h3 className="text-sm font-black text-emerald-950">संपूर्ण डेटाबेस बॅकअप (JSON)</h3>
                <p className="text-xs text-slate-600 mt-1">
                  संस्थेच्या सर्व सभासद, पावत्या, हप्ते, खर्च आणि सेटिंग्जचा सुरक्षित बॅकअप स्नॅपशॉट.
                </p>
              </div>
              <a
                href={api.admin.getBackupUrl()}
                download
                onClick={(e) => {
                  if (!window.confirm('तुम्हाला खात्री आहे का? संपूर्ण डेटाबेस बॅकअप डाउनलोड करायचा आहे?')) {
                    e.preventDefault();
                  }
                }}
                className="w-full py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-xs transition-colors"
              >
                <Download className="w-4 h-4" />
                <span>सुरक्षित डेटाबेस बॅकअप डाउनलोड</span>
              </a>
            </div>
          </div>

          <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl text-xs text-slate-600 space-y-1">
            <span className="font-bold text-slate-800 block">शून्य डेटा नुकसान हमी (Zero-Loss Guarantee):</span>
            <p>
              सेटिंग्ज बदलताना किंवा नवीन कॉन्फिगरेशन लागू करताना डेटाबेसमधील विद्यमान नोंदी कधीही हटवल्या जात नाहीत. सर्व बदल तात्काळ सुरक्षित स्टोरेजमध्ये सुरक्षित केले जातात.
            </p>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* SECTION H: APPEARANCE & LANGUAGE */}
      {/* ========================================================= */}
      {activeTab === 'appearance' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
          <div className="pb-4 border-b border-slate-100">
            <h2 className="text-lg sm:text-xl font-black text-blue-950 flex items-center gap-2">
              <Globe className="w-5 h-5 text-blue-800" />
              <span>H. Appearance & Language (भाषा व स्वरूप)</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
              बहुभाषिक पर्याय (मराठी, हिंदी, English) आणि मोबाइल-अनुकूल डिस्प्ले
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-5 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
              <span className="text-xs font-bold text-slate-500 uppercase">इंटरफेस भाषा निवडा (Language Selection)</span>
              
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setLanguage('mr')}
                  className={`py-3 px-2 rounded-xl text-center font-bold text-xs sm:text-sm border transition-all ${
                    language === 'mr'
                      ? 'bg-blue-800 text-white border-blue-900 shadow-xs'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  🚩 मराठी
                </button>
                <button
                  type="button"
                  onClick={() => setLanguage('hi')}
                  className={`py-3 px-2 rounded-xl text-center font-bold text-xs sm:text-sm border transition-all ${
                    language === 'hi'
                      ? 'bg-blue-800 text-white border-blue-900 shadow-xs'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  🇮🇳 हिंदी
                </button>
                <button
                  type="button"
                  onClick={() => setLanguage('en')}
                  className={`py-3 px-2 rounded-xl text-center font-bold text-xs sm:text-sm border transition-all ${
                    language === 'en'
                      ? 'bg-blue-800 text-white border-blue-900 shadow-xs'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  🌐 English
                </button>
              </div>
            </div>

            <div className="p-5 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
              <span className="text-xs font-bold text-slate-500 uppercase">संस्थेचे अधिकृत रंग स्वरूप (Brand Colors)</span>
              <div className="flex items-center gap-3">
                <div className="flex-1 p-3 bg-blue-900 text-white rounded-xl text-center font-bold text-xs shadow-xs">
                  Ekta Blue
                  <span className="block text-[10px] font-mono text-blue-200">#1E3A8A</span>
                </div>
                <div className="flex-1 p-3 bg-amber-600 text-white rounded-xl text-center font-bold text-xs shadow-xs">
                  Seva Amber
                  <span className="block text-[10px] font-mono text-amber-200">#D97706</span>
                </div>
                <div className="flex-1 p-3 bg-emerald-700 text-white rounded-xl text-center font-bold text-xs shadow-xs">
                  Bhavi Green
                  <span className="block text-[10px] font-mono text-emerald-200">#059669</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* SECTION I: APP INFORMATION */}
      {/* ========================================================= */}
      {activeTab === 'app_info' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
          <div className="pb-4 border-b border-slate-100">
            <h2 className="text-lg sm:text-xl font-black text-blue-950 flex items-center gap-2">
              <Info className="w-5 h-5 text-blue-800" />
              <span>I. App Information (अ‍ॅप माहिती व स्थिती)</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
              संस्था अ‍ॅप तपशील, आवृत्ती, नोंदणी व थेट सिंक स्थिती
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div className="p-5 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
              <div className="flex items-center gap-3">
                <SansthaLogo size="md" />
                <div>
                  <h3 className="font-black text-base text-blue-950">Ekta Seva Bhavi Sanstha</h3>
                  <span className="text-xs text-amber-600 font-bold">एकता सेवा भावी संस्था, कळमनुरी</span>
                </div>
              </div>

              <div className="space-y-1.5 text-xs text-slate-600 pt-2 border-t border-slate-200">
                <div className="flex justify-between">
                  <span>अ‍ॅप आवृत्ती (Version):</span>
                  <strong className="font-mono text-blue-900">v2.4.0 (Build 2026.10)</strong>
                </div>
                <div className="flex justify-between">
                  <span>नोंदणी क्र. (Reg. No.):</span>
                  <strong className="text-slate-900">{settings?.registrationNumber || 'MAH/KLM/1048/2022'}</strong>
                </div>
                <div className="flex justify-between">
                  <span>प्लॅटफॉर्म (Platform):</span>
                  <strong className="text-slate-900">Web SPA & Android Native APK</strong>
                </div>
                <div className="flex justify-between">
                  <span>सिस्टम स्थिती:</span>
                  <span className="font-bold text-emerald-700 flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                    सर्व सेवा सुरळीत सुरू आहेत
                  </span>
                </div>
              </div>
            </div>

            <div className="p-5 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
              <h3 className="font-bold text-sm text-blue-950 flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-emerald-700" />
                <span>Android APK माहिती (Mobile App Package)</span>
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                हा प्रकल्प कॅपेसिटर (Capacitor) द्वारे नेटिव्ह अँड्रॉइड अ‍ॅप म्हणून जोडलेला आहे. अ‍ॅपचे पॅकेज नाव: <code className="bg-slate-200 px-1 py-0.5 rounded font-mono text-[11px]">org.ektasanstha.app</code>
              </p>
              <div className="p-3 bg-white rounded-xl border border-slate-200 text-xs text-slate-700 flex items-center justify-between">
                <span>अद्यतने (Updates):</span>
                <span className="font-bold text-emerald-700">नवीनतम आवृत्ती स्थापित (Up to date)</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* AUDIT LOG TAB */}
      {/* ========================================================= */}
      {activeTab === 'audit' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div>
              <h2 className="text-lg sm:text-xl font-black text-blue-950 flex items-center gap-2">
                <History className="w-5 h-5 text-blue-800" />
                <span>प्रशासकीय ऑडिट लॉग (Administrative Audit Trail)</span>
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                सर्व महत्त्वाच्या आर्थिक व प्रशासकीय बदलांची सुरक्षित नोंद
              </p>
            </div>
            <button
              onClick={loadAuditLogs}
              className="p-2 text-slate-500 hover:text-blue-900 rounded-lg hover:bg-slate-100 transition-colors"
              title="रिफ्रेश करा"
            >
              <RefreshCw className={`w-4 h-4 ${isLoadingLogs ? 'animate-spin' : ''}`} />
            </button>
          </div>

          {isLoadingLogs ? (
            <div className="text-center py-8 text-xs text-slate-500">लॉग लोड होत आहेत...</div>
          ) : auditLogs.length === 0 ? (
            <div className="text-center py-8 text-xs text-slate-500">कोणतीही नोंद आढळली नाही.</div>
          ) : (
            <div className="overflow-x-auto max-h-96 overflow-y-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500 uppercase font-bold sticky top-0 bg-white">
                    <th className="py-2.5 px-3">वेळ</th>
                    <th className="py-2.5 px-3">वापरकर्ता</th>
                    <th className="py-2.5 px-3">कृती (Action)</th>
                    <th className="py-2.5 px-3">तपशील (Details)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {auditLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-slate-50">
                      <td className="py-2.5 px-3 text-slate-500 font-mono whitespace-nowrap">
                        {formatDateTime(log.timestamp)}
                      </td>
                      <td className="py-2.5 px-3 font-semibold text-slate-800 whitespace-nowrap">
                        {log.actorName}
                      </td>
                      <td className="py-2.5 px-3 whitespace-nowrap">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-700">
                          {log.action}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-slate-600 max-w-md truncate" title={log.details}>
                        {log.details}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
