import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext.js';
import { useLanguage } from '../../context/LanguageContext.js';
import { SansthaLogo } from '../common/SansthaLogo.js';
import {
  ShieldCheck,
  User,
  Lock,
  Briefcase,
  MapPin,
  ArrowRight,
  CheckCircle,
  AlertCircle,
  Globe,
  Sparkles,
  Smartphone,
  Eye,
  EyeOff,
} from 'lucide-react';
import { api } from '../../services/api.js';

interface AuthScreenProps {
  onOpenAndroidGuide?: () => void;
}

export const AuthScreen: React.FC<AuthScreenProps> = ({ onOpenAndroidGuide }) => {
  const { login, isLoading } = useAuth();
  const { language, setLanguage, t } = useLanguage();

  const [activeTab, setActiveTab] = useState<'admin' | 'staff' | 'member'>('admin');

  // Admin form state
  const [adminIdentifier, setAdminIdentifier] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [showAdminPassword, setShowAdminPassword] = useState(false);

  // Staff form state
  const [staffIdentifier, setStaffIdentifier] = useState('');
  const [staffPassword, setStaffPassword] = useState('');
  const [showStaffPassword, setShowStaffPassword] = useState(false);

  // Member form state
  const [memberIdentifier, setMemberIdentifier] = useState('');
  const [memberPassword, setMemberPassword] = useState('');
  const [showMemberPassword, setShowMemberPassword] = useState(false);

  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Forgot password modal
  const [showForgotModal, setShowForgotModal] = useState(false);
  const [forgotInput, setForgotInput] = useState('');
  const [forgotMsg, setForgotMsg] = useState('');

  // Handle Admin Login submission
  const handleAdminLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');
    setIsSubmitting(true);

    try {
      const res = await login(adminIdentifier, adminPassword);
      if (res.role !== 'admin' && res.role !== 'staff') {
        setErrorMsg('केवळ संस्था प्रशासक खात्यांना या टॅबद्वारे प्रवेश आहे. कृपया "सदस्य लॉगिन" टॅब वापरा.');
        return;
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'प्रशासक लॉगिन अयशस्वी. कृपया अचूक तपशील तपासा.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle Staff Login submission
  const handleStaffLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');
    setIsSubmitting(true);

    try {
      const res = await login(staffIdentifier, staffPassword);
      if (res.role !== 'staff' && res.role !== 'admin') {
        setErrorMsg('हे अधिकृत स्टाफ खाते नाही. कृपया "सदस्य लॉगिन" टॅब वापरा.');
        return;
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'स्टाफ लॉगिन अयशस्वी. कृपया अधिकृत कर्मचारी तपशील तपासा.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle Member Login submission
  const handleMemberLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');
    setIsSubmitting(true);

    try {
      await login(memberIdentifier, memberPassword);
    } catch (err: any) {
      setErrorMsg(err.message || 'सदस्य लॉगिन अयशस्वी. कृपया नोंदणीकृत सदस्य आयडी किंवा मोबाईल तपासा.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle Forgot Password modal submission
  const handleForgotSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!forgotInput) return;
    try {
      const res = await api.auth.forgotPassword(forgotInput);
      setForgotMsg(res.message);
    } catch (err: any) {
      setForgotMsg(err.message || 'Request failed');
    }
  };

  // Quick fill helper for testing credentials
  const fillCredentials = (type: 'admin' | 'staff' | 'member1' | 'member2') => {
    setErrorMsg('');
    setSuccessMsg('');
    if (type === 'admin') {
      setActiveTab('admin');
      setAdminIdentifier('admin@ektasanstha.org');
      setAdminPassword('admin123');
    } else if (type === 'staff') {
      setActiveTab('staff');
      setStaffIdentifier('staff@ektasanstha.org');
      setStaffPassword('staff123');
    } else if (type === 'member1') {
      setActiveTab('member');
      setMemberIdentifier('M001');
      setMemberPassword('member123');
    } else if (type === 'member2') {
      setActiveTab('member');
      setMemberIdentifier('M002');
      setMemberPassword('member123');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-indigo-900 to-slate-900 flex flex-col justify-between text-slate-100 relative overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-0 -left-40 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 -right-40 w-96 h-96 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Top Header Bar */}
      <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between relative z-10">
        <div className="flex items-center gap-2">
          <SansthaLogo size="sm" light={true} />
          <span className="font-bold text-white text-sm sm:text-base tracking-tight hidden sm:inline">
            {t.appName}
          </span>
        </div>

        <div className="flex items-center gap-3">
          {/* Language Selector */}
          <div className="flex items-center bg-white/10 backdrop-blur-md rounded-lg p-0.5 border border-white/20">
            <Globe className="w-3.5 h-3.5 ml-1.5 text-blue-200" />
            <button
              onClick={() => setLanguage('hi')}
              className={`px-2 py-1 text-xs font-semibold rounded transition-all ${
                language === 'hi' ? 'bg-amber-400 text-blue-950 font-bold' : 'text-blue-100 hover:text-white'
              }`}
            >
              हिंदी
            </button>
            <button
              onClick={() => setLanguage('mr')}
              className={`px-2 py-1 text-xs font-semibold rounded transition-all ${
                language === 'mr' ? 'bg-amber-400 text-blue-950 font-bold' : 'text-blue-100 hover:text-white'
              }`}
            >
              मराठी
            </button>
            <button
              onClick={() => setLanguage('en')}
              className={`px-2 py-1 text-xs font-semibold rounded transition-all ${
                language === 'en' ? 'bg-amber-400 text-blue-950 font-bold' : 'text-blue-100 hover:text-white'
              }`}
            >
              English
            </button>
          </div>

          {onOpenAndroidGuide && (
            <button
              onClick={onOpenAndroidGuide}
              className="px-2.5 py-1 text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-lg hover:bg-emerald-500/30 transition-all flex items-center gap-1.5"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Android APK</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Container */}
      <div className="flex-1 flex items-center justify-center px-4 py-8 relative z-10">
        <div className="w-full max-w-lg">
          {/* Card */}
          <div className="bg-white/95 backdrop-blur-xl text-slate-900 rounded-3xl shadow-2xl border border-white/40 p-6 sm:p-8">
            {/* Logo & Org Header */}
            <div className="text-center mb-6">
              <div className="flex justify-center mb-3">
                <SansthaLogo size="xl" />
              </div>
              <h1 className="text-2xl sm:text-3xl font-black text-blue-950 tracking-tight">
                Ekta Seva Bhavi Sanstha
              </h1>
              <h2 className="text-base sm:text-lg font-bold text-amber-600 mt-0.5">
                एकता सेवा भावी संस्था, कळमनुरी
              </h2>
              <div className="flex items-center justify-center gap-1.5 text-xs font-semibold text-slate-600 mt-1">
                <MapPin className="w-3.5 h-3.5 text-amber-500 flex-shrink-0" />
                <span>{t.orgAddress}</span>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                {t.welcomeSubtitle}
              </p>
            </div>

            {/* Tab switchers: Admin, Staff, Member Login */}
            <div className="grid grid-cols-3 gap-1 bg-slate-100 p-1 sm:p-1.5 rounded-xl mb-6 border border-slate-200">
              {/* Tab 1: प्रशासक लॉगिन (Admin) */}
              <button
                type="button"
                onClick={() => {
                  setActiveTab('admin');
                  setErrorMsg('');
                  setSuccessMsg('');
                }}
                className={`py-2 px-1 text-center font-bold rounded-lg transition-all text-[11px] sm:text-xs md:text-sm leading-snug flex flex-col sm:flex-row items-center justify-center gap-1 ${
                  activeTab === 'admin'
                    ? 'bg-blue-800 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                }`}
              >
                <ShieldCheck className="w-3.5 h-3.5 flex-shrink-0" />
                <span className="truncate">{t.adminLogin}</span>
              </button>

              {/* Tab 2: स्टाफ लॉगिन (Staff) */}
              <button
                type="button"
                onClick={() => {
                  setActiveTab('staff');
                  setErrorMsg('');
                  setSuccessMsg('');
                }}
                className={`py-2 px-1 text-center font-bold rounded-lg transition-all text-[11px] sm:text-xs md:text-sm leading-snug flex flex-col sm:flex-row items-center justify-center gap-1 ${
                  activeTab === 'staff'
                    ? 'bg-amber-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                }`}
              >
                <Briefcase className="w-3.5 h-3.5 flex-shrink-0" />
                <span className="truncate">{t.staffLogin}</span>
              </button>

              {/* Tab 3: सदस्य लॉगिन (Member Login) */}
              <button
                type="button"
                onClick={() => {
                  setActiveTab('member');
                  setErrorMsg('');
                  setSuccessMsg('');
                }}
                className={`py-2 px-1 text-center font-bold rounded-lg transition-all text-[11px] sm:text-xs md:text-sm leading-snug flex flex-col sm:flex-row items-center justify-center gap-1 ${
                  activeTab === 'member'
                    ? 'bg-blue-800 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                }`}
              >
                <User className="w-3.5 h-3.5 flex-shrink-0" />
                <span className="truncate">{t.memberLogin}</span>
              </button>
            </div>

            {/* Error or Success notification */}
            {errorMsg && (
              <div className="mb-4 p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs sm:text-sm flex items-start gap-2">
                <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5 text-rose-600" />
                <span>{errorMsg}</span>
              </div>
            )}
            {successMsg && (
              <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs sm:text-sm flex items-start gap-2">
                <CheckCircle className="w-4 h-4 flex-shrink-0 mt-0.5 text-emerald-600" />
                <span>{successMsg}</span>
              </div>
            )}

            {/* 1. ADMIN LOGIN FORM */}
            {activeTab === 'admin' && (
              <form onSubmit={handleAdminLoginSubmit} className="space-y-4">
                <div className="flex items-center gap-2 px-3 py-1.5 bg-blue-50 border border-blue-200/80 rounded-lg text-blue-900 text-xs font-semibold">
                  <ShieldCheck className="w-4 h-4 text-blue-700 flex-shrink-0" />
                  <span>संस्था प्रशासक लॉगिन कक्ष (Sanstha Administrator Portal)</span>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    {t.emailOrMobile}
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                      <ShieldCheck className="w-4 h-4" />
                    </div>
                    <input
                      type="text"
                      required
                      value={adminIdentifier}
                      onChange={(e) => setAdminIdentifier(e.target.value)}
                      placeholder="admin@ektasanstha.org किंवा 9876543210"
                      className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600 focus:border-transparent transition-all"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                      {t.password}
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowForgotModal(true)}
                      className="text-xs font-semibold text-blue-700 hover:underline"
                    >
                      {t.forgotPassword}
                    </button>
                  </div>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                      <Lock className="w-4 h-4" />
                    </div>
                    <input
                      type={showAdminPassword ? 'text' : 'password'}
                      required
                      value={adminPassword}
                      onChange={(e) => setAdminPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full pl-9 pr-10 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600 focus:border-transparent transition-all"
                    />
                    <button
                      type="button"
                      onClick={() => setShowAdminPassword(!showAdminPassword)}
                      className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600"
                    >
                      {showAdminPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting || isLoading}
                  className="w-full py-3 px-4 bg-blue-800 hover:bg-blue-900 text-white font-bold text-sm rounded-xl shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
                >
                  {isSubmitting ? (
                    <span>{t.loading}</span>
                  ) : (
                    <>
                      <span>{t.loginAsAdmin}</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>
            )}

            {/* 2. STAFF LOGIN FORM */}
            {activeTab === 'staff' && (
              <form onSubmit={handleStaffLoginSubmit} className="space-y-4">
                <div className="flex items-center gap-2 px-3 py-1.5 bg-amber-50 border border-amber-200/80 rounded-lg text-amber-900 text-xs font-semibold">
                  <Briefcase className="w-4 h-4 text-amber-700 flex-shrink-0" />
                  <span>संस्था स्टाफ व व्यवस्थापक कक्ष (Staff & Office Login)</span>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    {t.staffEmailOrMobile}
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                      <Briefcase className="w-4 h-4" />
                    </div>
                    <input
                      type="text"
                      required
                      value={staffIdentifier}
                      onChange={(e) => setStaffIdentifier(e.target.value)}
                      placeholder="staff@ektasanstha.org किंवा 9876500000"
                      className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                      {t.password}
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowForgotModal(true)}
                      className="text-xs font-semibold text-amber-800 hover:underline"
                    >
                      {t.forgotPassword}
                    </button>
                  </div>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                      <Lock className="w-4 h-4" />
                    </div>
                    <input
                      type={showStaffPassword ? 'text' : 'password'}
                      required
                      value={staffPassword}
                      onChange={(e) => setStaffPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full pl-9 pr-10 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all"
                    />
                    <button
                      type="button"
                      onClick={() => setShowStaffPassword(!showStaffPassword)}
                      className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600"
                    >
                      {showStaffPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting || isLoading}
                  className="w-full py-3 px-4 bg-amber-600 hover:bg-amber-700 text-white font-bold text-sm rounded-xl shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
                >
                  {isSubmitting ? (
                    <span>{t.loading}</span>
                  ) : (
                    <>
                      <span>{t.loginAsStaff}</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>
            )}

            {/* 3. MEMBER LOGIN FORM (No public registration form) */}
            {activeTab === 'member' && (
              <form onSubmit={handleMemberLoginSubmit} className="space-y-4">
                <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-50 border border-emerald-200/80 rounded-lg text-emerald-900 text-xs font-semibold">
                  <User className="w-4 h-4 text-emerald-700 flex-shrink-0" />
                  <span>नोंदणीकृत सभासद लॉगिन कक्ष (Registered Member Portal)</span>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    {t.memberIdOrMobile}
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                      <User className="w-4 h-4" />
                    </div>
                    <input
                      type="text"
                      required
                      value={memberIdentifier}
                      onChange={(e) => setMemberIdentifier(e.target.value)}
                      placeholder="M001 किंवा 9822110022"
                      className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600 focus:border-transparent transition-all"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                      {t.password}
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowForgotModal(true)}
                      className="text-xs font-semibold text-blue-700 hover:underline"
                    >
                      {t.forgotPassword}
                    </button>
                  </div>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                      <Lock className="w-4 h-4" />
                    </div>
                    <input
                      type={showMemberPassword ? 'text' : 'password'}
                      required
                      value={memberPassword}
                      onChange={(e) => setMemberPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full pl-9 pr-10 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600 focus:border-transparent transition-all"
                    />
                    <button
                      type="button"
                      onClick={() => setShowMemberPassword(!showMemberPassword)}
                      className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600"
                    >
                      {showMemberPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting || isLoading}
                  className="w-full py-3 px-4 bg-blue-800 hover:bg-blue-900 text-white font-bold text-sm rounded-xl shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
                >
                  {isSubmitting ? (
                    <span>{t.loading}</span>
                  ) : (
                    <>
                      <span>{t.loginAsMember}</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>
            )}

            {/* Quick Demo Access Bar */}
            <div className="mt-6 pt-5 border-t border-slate-200">
              <div className="flex items-center gap-1.5 text-xs font-bold text-slate-500 mb-2">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>त्वरित चाचणी खाती (Quick Demo Credentials):</span>
              </div>
              <div className="grid grid-cols-3 gap-1.5">
                <button
                  type="button"
                  onClick={() => fillCredentials('admin')}
                  className={`px-2 py-2 text-[11px] font-semibold rounded-lg border transition-all text-center ${
                    activeTab === 'admin'
                      ? 'bg-blue-100 text-blue-900 border-blue-400 ring-2 ring-blue-300'
                      : 'bg-blue-50 text-blue-800 hover:bg-blue-100 border-blue-200'
                  }`}
                >
                  <div className="font-bold flex items-center justify-center gap-0.5">
                    <span>👑 Admin</span>
                  </div>
                  <span className="text-[10px] text-slate-500 block truncate">admin@ektasanstha</span>
                </button>

                <button
                  type="button"
                  onClick={() => fillCredentials('staff')}
                  className={`px-2 py-2 text-[11px] font-semibold rounded-lg border transition-all text-center ${
                    activeTab === 'staff'
                      ? 'bg-amber-100 text-amber-900 border-amber-400 ring-2 ring-amber-300'
                      : 'bg-amber-50 text-amber-800 hover:bg-amber-100 border-amber-200'
                  }`}
                >
                  <div className="font-bold flex items-center justify-center gap-0.5">
                    <span>💼 Staff</span>
                  </div>
                  <span className="text-[10px] text-slate-500 block truncate">staff@ektasanstha</span>
                </button>

                <button
                  type="button"
                  onClick={() => fillCredentials('member1')}
                  className={`px-2 py-2 text-[11px] font-semibold rounded-lg border transition-all text-center ${
                    activeTab === 'member'
                      ? 'bg-emerald-100 text-emerald-900 border-emerald-400 ring-2 ring-emerald-300'
                      : 'bg-teal-50 text-teal-800 hover:bg-teal-100 border-teal-200'
                  }`}
                >
                  <div className="font-bold flex items-center justify-center gap-0.5">
                    <span>👤 M001</span>
                  </div>
                  <span className="text-[10px] text-slate-500 block truncate">Ramesh Patil</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Forgot Password Modal */}
      {showForgotModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white text-slate-900 rounded-2xl max-w-sm w-full p-6 shadow-2xl">
            <h3 className="text-lg font-bold text-blue-950 mb-2">{t.forgotPassword}</h3>
            <p className="text-xs text-slate-600 mb-4">
              आपला नोंदणीकृत ईमेल, मोबाईल नंबर किंवा सदस्य आयडी टाका.
            </p>
            {forgotMsg ? (
              <div className="p-3 bg-blue-50 text-blue-900 rounded-xl text-xs mb-4">
                {forgotMsg}
              </div>
            ) : (
              <form onSubmit={handleForgotSubmit} className="space-y-3">
                <input
                  type="text"
                  required
                  value={forgotInput}
                  onChange={(e) => setForgotInput(e.target.value)}
                  placeholder="ईमेल, मोबाईल किंवा M001"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm"
                />
                <button
                  type="submit"
                  className="w-full py-2 bg-blue-800 text-white font-bold text-sm rounded-xl"
                >
                  {t.confirm}
                </button>
              </form>
            )}
            <button
              onClick={() => {
                setShowForgotModal(false);
                setForgotMsg('');
              }}
              className="mt-3 w-full py-2 text-xs font-semibold text-slate-500 hover:text-slate-800"
            >
              {t.close}
            </button>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="w-full text-center py-3 text-xs text-blue-200/60 border-t border-white/5 relative z-10">
        © 2026 Ekta Seva Bhavi Sanstha • Mali Galli, Kalamnuri, Maharashtra • All Rights Reserved.
      </footer>
    </div>
  );
};
