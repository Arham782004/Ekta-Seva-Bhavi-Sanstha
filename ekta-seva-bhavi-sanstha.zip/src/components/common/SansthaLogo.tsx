import React from 'react';
import { useAuth } from '../../context/AuthContext.js';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  light?: boolean;
  customUrl?: string;
}

export const SansthaLogo: React.FC<LogoProps> = ({
  className = '',
  size = 'md',
  showText = false,
  light = false,
  customUrl,
}) => {
  const sizeMap = {
    sm: 'w-8 h-8',
    md: 'w-12 h-12',
    lg: 'w-16 h-16',
    xl: 'w-24 h-24',
  };

  let settingsCustomUrl: string | undefined;
  let orgMarathiName = 'एकता सेवा भावी संस्था';
  let orgRegNumber = 'MAH/KLM/1048';
  try {
    const auth = useAuth();
    settingsCustomUrl = auth.settings?.customLogoUrl;
    if (auth.settings?.marathiName) orgMarathiName = auth.settings.marathiName;
    if (auth.settings?.registrationNumber) orgRegNumber = auth.settings.registrationNumber;
  } catch {
    // Context unavailable
  }

  const logoSrc = customUrl || settingsCustomUrl;

  return (
    <div className={`flex items-center gap-3 ${className}`}>
      <div className={`relative flex-shrink-0 ${sizeMap[size]}`}>
        {logoSrc ? (
          <img
            src={logoSrc}
            alt="Ekta Seva Bhavi Sanstha Logo"
            className="w-full h-full object-contain rounded-full shadow-md border-2 border-amber-400 bg-white"
          />
        ) : (
          /* Emblem Badge: Deep Royal Blue circle with gold/teal rim and unity hands & banyan motif */
          <svg
            viewBox="0 0 100 100"
            className="w-full h-full drop-shadow-md"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            {/* Outer circle */}
            <circle cx="50" cy="50" r="48" fill={light ? '#FFFFFF' : '#1E40AF'} stroke="#F59E0B" strokeWidth="3" />
            <circle cx="50" cy="50" r="44" stroke={light ? '#1E40AF' : '#60A5FA'} strokeWidth="1" strokeDasharray="3 3" />

            {/* Sun rays at top */}
            <path
              d="M50 12 L50 20 M38 15 L42 22 M62 15 L58 22 M27 24 L34 28 M73 24 L66 28"
              stroke="#F59E0B"
              strokeWidth="2"
              strokeLinecap="round"
            />

            {/* Banyan Tree / Unity emblem in center */}
            <path
              d="M50 32 C42 32 36 38 36 45 C36 48 38 51 40 53 C38 56 38 60 42 62 C44 63 46 63 48 62 L48 70 L44 76 L48 76 L50 72 L52 76 L56 76 L52 70 L52 62 C54 63 56 63 58 62 C62 60 62 56 60 53 C62 51 64 48 64 45 C64 38 58 32 50 32 Z"
              fill={light ? '#0D9488' : '#34D399'}
            />

            {/* Supporting open hands at bottom representing Seva & Unity */}
            <path
              d="M24 66 C28 62 34 60 40 62 C43 63 44 66 42 69 C37 69 33 71 28 75 C25 78 22 75 24 66 Z"
              fill="#FBBF24"
            />
            <path
              d="M76 66 C72 62 66 60 60 62 C57 63 56 66 58 69 C63 69 67 71 72 75 C75 78 78 75 76 66 Z"
              fill="#FBBF24"
            />

            {/* Center Rupee / Unity Star symbol */}
            <circle cx="50" cy="48" r="6" fill="#FFFFFF" />
            <text
              x="50"
              y="52"
              textAnchor="middle"
              fill="#1E40AF"
              fontSize="7"
              fontWeight="bold"
              fontFamily="system-ui"
            >
              ₹
            </text>

            {/* Bottom Banner ribbon */}
            <path
              d="M26 82 L74 82 L70 88 L30 88 Z"
              fill="#F59E0B"
            />
            <text
              x="50"
              y="87"
              textAnchor="middle"
              fill="#1E3A8A"
              fontSize="4.5"
              fontWeight="bold"
              letterSpacing="0.5"
            >
              एकता सेवा
            </text>
          </svg>
        )}
      </div>

      {showText && (
        <div className="flex flex-col">
          <span
            className={`font-bold tracking-tight text-lg leading-tight ${
              light ? 'text-white' : 'text-blue-950'
            }`}
          >
            {orgMarathiName}
          </span>
          <span
            className={`text-xs font-medium leading-normal ${
              light ? 'text-blue-200' : 'text-slate-500'
            }`}
          >
            माळी गल्ली, कळमनुरी • Reg. {orgRegNumber}
          </span>
        </div>
      )}
    </div>
  );
};
