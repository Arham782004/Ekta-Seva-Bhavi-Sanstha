import React from 'react';
import { SansthaLogo } from './SansthaLogo.js';

interface SplashScreenProps {
  message?: string;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({
  message = 'एकता सेवा भावी संस्था लोड होत आहे...',
}) => {
  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-between bg-gradient-to-br from-blue-950 via-slate-900 to-indigo-950 text-white px-6 py-12 select-none overflow-hidden">
      {/* Ambient background glow */}
      <div className="absolute top-1/4 w-96 h-96 bg-blue-600/15 rounded-full blur-3xl pointer-events-none -translate-y-1/2" />
      <div className="absolute bottom-1/4 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none translate-y-1/2" />

      {/* Top decorative spacing */}
      <div className="w-full flex justify-center">
        <span className="text-[11px] font-bold tracking-widest uppercase text-blue-300/70 border border-blue-400/20 px-3 py-1 rounded-full bg-blue-900/30 backdrop-blur-xs">
          अधिकृत संस्था ॲप • Official Mobile App
        </span>
      </div>

      {/* Center Logo & Branding */}
      <div className="relative z-10 flex flex-col items-center text-center max-w-md w-full animate-in fade-in zoom-in-95 duration-500">
        <div className="relative mb-6">
          <div className="absolute inset-0 bg-amber-400/20 rounded-full blur-xl scale-110 animate-pulse pointer-events-none" />
          <div className="relative p-2 bg-white/5 rounded-full border border-white/10 backdrop-blur-xs shadow-2xl">
            <SansthaLogo size="xl" className="w-28 h-28 sm:w-32 sm:h-32" />
          </div>
        </div>

        {/* Exact Organization Name */}
        <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white drop-shadow-md">
          Ekta Seva Bhavi Sanstha
        </h1>

        {/* Marathi Name */}
        <h2 className="text-lg sm:text-xl font-extrabold text-amber-400 mt-1">
          एकता सेवा भावी संस्था, कळमनुरी
        </h2>

        {/* Registration & Location */}
        <p className="text-xs sm:text-sm text-blue-200/90 mt-2 font-medium">
          माळी गल्ली, कळमनुरी, जि. हिंगोली • Reg. No: MAH/KLM/1048/2022
        </p>

        {/* Loading Indicator */}
        <div className="mt-8 flex flex-col items-center gap-3">
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-amber-400 animate-bounce" style={{ animationDelay: '0ms' }} />
            <div className="w-2 h-2 rounded-full bg-blue-400 animate-bounce" style={{ animationDelay: '150ms' }} />
            <div className="w-2 h-2 rounded-full bg-emerald-400 animate-bounce" style={{ animationDelay: '300ms' }} />
          </div>
          <p className="text-xs font-semibold text-slate-400 tracking-wide">
            {message}
          </p>
        </div>
      </div>

      {/* Footer info */}
      <div className="relative z-10 text-center text-[11px] text-slate-500 font-medium">
        <p>© 2026 Ekta Seva Bhavi Sanstha • सर्व हक्क सुरक्षित</p>
      </div>
    </div>
  );
};
