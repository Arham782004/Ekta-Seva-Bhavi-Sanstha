import React, { useState } from 'react';
import { X, Smartphone, Copy, Check, Terminal, ShieldCheck, Download, Code } from 'lucide-react';

interface AndroidGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidGuideModal: React.FC<AndroidGuideModalProps> = ({ isOpen, onClose }) => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!isOpen) return null;

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const debugCommand = `npm run build\nnpx cap add android\nnpx cap sync\ncd android && ./gradlew assembleDebug`;
  const releaseCommand = `cd android && ./gradlew assembleRelease`;
  const aabCommand = `cd android && ./gradlew bundleRelease`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 relative my-8">
        <button
          onClick={onClose}
          className="absolute top-6 right-6 p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-full transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-emerald-100 text-emerald-900 rounded-2xl">
            <Smartphone className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-extrabold text-blue-950">
              Android Application Packaging (APK & AAB)
            </h2>
            <p className="text-xs text-slate-500">
              Ekta Seva Bhavi Sanstha • Capacitor Android Native App
            </p>
          </div>
        </div>

        <div className="space-y-5 text-xs text-slate-700">
          {/* Important Distinction: Web Shortcut vs Native APK Icon */}
          <div className="p-4 bg-amber-50 border border-amber-300 rounded-2xl">
            <div className="flex items-start gap-2.5">
              <ShieldCheck className="w-5 h-5 text-amber-700 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="font-extrabold text-xs text-amber-950 uppercase tracking-wide">
                  महत्त्वाचा फरक: ब्राऊझर शॉर्टकट विरुद्ध खरा नेटिव्ह Android APK
                </h4>
                <p className="text-[11px] text-amber-900 mt-1 leading-relaxed">
                  मोबाईल ब्राऊझरमधील <span className="font-bold">"Add to Home screen"</span> हा केवळ वेब शॉर्टकट असतो जो ब्राऊझरच्या बॅजसह दिसू शकतो. याउलट, खरा <span className="font-bold">Android APK Launcher Icon</span> हा ॲपच्या बायनरी फाईलमध्ये (<code className="font-mono text-amber-950 font-semibold">res/mipmap-*/ic_launcher.png</code>) थेट अंतर्भूत असतो आणि तो कोणत्याही ब्राऊझर बॅजशिवाय स्वतंत्र मूळ ॲप म्हणून स्थापित होतो.
                </p>
                <p className="text-[11px] text-amber-800 mt-1 italic">
                  (नोंद: जोपर्यंत Gradle किंवा Cloud Build द्वारे <code className="font-mono text-amber-950">app-debug.apk</code> प्रत्यक्षात कम्पाइल होत नाही, तोपर्यंत तो आपोआप अस्तित्वात येत नाही.)
                </p>
              </div>
            </div>
          </div>

          {/* Metadata info */}
          <div className="grid grid-cols-2 gap-3 p-3 bg-slate-50 border border-slate-200 rounded-2xl">
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Package ID</span>
              <span className="font-mono font-bold text-blue-900">org.ektasanstha.kalamnuri</span>
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block">App Name</span>
              <span className="font-bold text-slate-900">Ekta Seva Bhavi Sanstha</span>
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Config File</span>
              <span className="font-mono text-slate-700">capacitor.config.ts</span>
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Target Android API</span>
              <span className="font-bold text-emerald-700">API 34 (Android 14+)</span>
            </div>
          </div>

          {/* 1. Debug APK Build */}
          <div className="border border-slate-200 rounded-2xl p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="font-bold text-blue-950 flex items-center gap-1.5">
                <Terminal className="w-4 h-4 text-emerald-600" />
                <span>1. Debug APK तयार करणे (Testing on Real Phone)</span>
              </span>
              <button
                onClick={() => copyToClipboard(debugCommand, 'debug')}
                className="text-blue-700 hover:text-blue-900 flex items-center gap-1 font-semibold"
              >
                {copiedKey === 'debug' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedKey === 'debug' ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
            <pre className="bg-slate-900 text-emerald-400 p-3 rounded-xl font-mono text-[11px] overflow-x-auto">
              {debugCommand}
            </pre>
            <p className="text-[11px] text-slate-500 mt-2">
              तयार झालेली APK फाईल येथे मिळेल: <code className="text-slate-800 font-mono">android/app/build/outputs/apk/debug/app-debug.apk</code>
            </p>
          </div>

          {/* 2. Release APK Build */}
          <div className="border border-slate-200 rounded-2xl p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="font-bold text-blue-950 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-blue-600" />
                <span>2. Signed Production APK तयार करणे</span>
              </span>
              <button
                onClick={() => copyToClipboard(releaseCommand, 'release')}
                className="text-blue-700 hover:text-blue-900 flex items-center gap-1 font-semibold"
              >
                {copiedKey === 'release' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedKey === 'release' ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
            <pre className="bg-slate-900 text-emerald-400 p-3 rounded-xl font-mono text-[11px] overflow-x-auto">
              {releaseCommand}
            </pre>
            <p className="text-[11px] text-slate-500 mt-2">
              तयार झालेली फाईल: <code className="text-slate-800 font-mono">android/app/build/outputs/apk/release/app-release-unsigned.apk</code>
            </p>
          </div>

          {/* 3. Google Play Store AAB Bundle */}
          <div className="border border-slate-200 rounded-2xl p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="font-bold text-blue-950 flex items-center gap-1.5">
                <Code className="w-4 h-4 text-amber-600" />
                <span>3. Google Play Store साठी AAB (Android App Bundle)</span>
              </span>
              <button
                onClick={() => copyToClipboard(aabCommand, 'aab')}
                className="text-blue-700 hover:text-blue-900 flex items-center gap-1 font-semibold"
              >
                {copiedKey === 'aab' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedKey === 'aab' ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
            <pre className="bg-slate-900 text-emerald-400 p-3 rounded-xl font-mono text-[11px] overflow-x-auto">
              {aabCommand}
            </pre>
            <p className="text-[11px] text-slate-500 mt-2">
              तयार झालेली AAB फाईल: <code className="text-slate-800 font-mono">android/app/build/outputs/bundle/release/app-release.aab</code>
            </p>
          </div>
        </div>

        <div className="mt-6 pt-4 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-blue-900 text-white font-bold text-xs rounded-xl"
          >
            बंद करा (Close)
          </button>
        </div>
      </div>
    </div>
  );
};
