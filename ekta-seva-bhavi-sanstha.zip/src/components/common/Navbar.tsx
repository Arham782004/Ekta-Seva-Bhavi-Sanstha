import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext.js';
import { useLanguage } from '../../context/LanguageContext.js';
import { SansthaLogo } from './SansthaLogo.js';
import {
  Bell,
  LogOut,
  Globe,
  User,
  Smartphone,
  CheckCircle,
} from 'lucide-react';
import { api } from '../../services/api.js';
import { AppNotification } from '../../types/index.js';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  onOpenNotifications: () => void;
  onOpenAndroidGuide: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  setCurrentTab,
  onOpenNotifications,
  onOpenAndroidGuide,
}) => {
  const { user, member, isAdmin, isStaff, logout } = useAuth();
  const { language, setLanguage, t } = useLanguage();
  const [unreadCount, setUnreadCount] = useState<number>(0);

  useEffect(() => {
    let isMounted = true;
    const fetchNotifs = async () => {
      try {
        const notifs = await api.notifications.getAll();
        if (isMounted) {
          const unread = notifs.filter((n: AppNotification) => !n.isRead).length;
          setUnreadCount(unread);
        }
      } catch {
        // silent fail
      }
    };

    fetchNotifs();
    const interval = setInterval(fetchNotifs, 15000);
    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, []);

  const hasManagerAccess = isAdmin || isStaff;

  const navItems = hasManagerAccess
    ? [
        { id: 'dashboard', label: t.dashboard },
        { id: 'members', label: t.members },
        { id: 'dues', label: t.dues },
        { id: 'deposit', label: t.monthlyDepositBtn },
        { id: 'receipts', label: t.receipts },
        { id: 'reports', label: t.reports },
        ...(isAdmin ? [{ id: 'settings', label: t.settings }] : []),
      ]
    : [
        { id: 'member-portal', label: t.myDashboard },
        { id: 'shared-members', label: language === 'mr' ? 'सर्व सभासद (Members)' : language === 'hi' ? 'सभी सदस्य (Members)' : 'All Members' },
        { id: 'my-dues', label: t.myDues },
        { id: 'my-receipts', label: t.myReceipts },
      ];

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand */}
          <div
            className="flex items-center gap-3 cursor-pointer py-1"
            onClick={() => setCurrentTab(hasManagerAccess ? 'dashboard' : 'member-portal')}
          >
            <SansthaLogo size="md" />
            <div>
              <div className="font-extrabold text-blue-900 text-base sm:text-lg leading-tight tracking-tight flex items-center gap-1.5">
                <span>{t.appName}</span>
                <span className="hidden sm:inline-block px-1.5 py-0.5 text-[10px] uppercase font-bold tracking-wider bg-blue-100 text-blue-800 rounded">
                  {isAdmin ? 'Admin' : isStaff ? 'Staff' : member?.memberId || 'Member'}
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium truncate max-w-[200px] sm:max-w-none">
                {t.orgAddress}
              </p>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center space-x-1">
            {navItems.map((item) => {
              const active = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setCurrentTab(item.id)}
                  className={`px-3 py-1.5 text-xs sm:text-sm font-semibold rounded-lg transition-colors ${
                    active
                      ? 'bg-blue-800 text-white shadow-xs'
                      : 'text-slate-700 hover:text-blue-900 hover:bg-slate-100'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Right utility icons & user menu */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Language Selector */}
            <div className="relative flex items-center bg-slate-100 rounded-lg p-0.5 border border-slate-200">
              <Globe className="w-3.5 h-3.5 ml-1.5 text-slate-500" />
              <button
                onClick={() => setLanguage('hi')}
                className={`px-1.5 py-1 text-xs font-semibold rounded transition-all ${
                  language === 'hi' ? 'bg-blue-700 text-white shadow-2xs' : 'text-slate-600 hover:text-slate-900'
                }`}
                title="हिंदी"
              >
                हिं
              </button>
              <button
                onClick={() => setLanguage('mr')}
                className={`px-1.5 py-1 text-xs font-semibold rounded transition-all ${
                  language === 'mr' ? 'bg-blue-700 text-white shadow-2xs' : 'text-slate-600 hover:text-slate-900'
                }`}
                title="मराठी"
              >
                मरा
              </button>
              <button
                onClick={() => setLanguage('en')}
                className={`px-1.5 py-1 text-xs font-semibold rounded transition-all ${
                  language === 'en' ? 'bg-blue-700 text-white shadow-2xs' : 'text-slate-600 hover:text-slate-900'
                }`}
                title="English"
              >
                EN
              </button>
            </div>

            {/* Android APK Build Guide Trigger */}
            <button
              onClick={onOpenAndroidGuide}
              className="p-2 text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition-colors flex items-center gap-1 text-xs font-semibold border border-transparent hover:border-emerald-200"
              title="Android App APK & Package Info"
            >
              <Smartphone className="w-4 h-4 text-emerald-600" />
              <span className="hidden md:inline text-emerald-800">APK</span>
            </button>

            {/* Notifications Bell */}
            <button
              onClick={onOpenNotifications}
              className="relative p-2 text-slate-600 hover:text-blue-900 hover:bg-blue-50 rounded-lg transition-colors"
              title={t.notifications}
            >
              <Bell className="w-5 h-5" />
              {unreadCount > 0 && (
                <span className="absolute top-1 right-1 flex items-center justify-center min-w-[18px] h-[18px] px-1 text-[10px] font-bold text-white bg-rose-600 rounded-full ring-2 ring-white">
                  {unreadCount}
                </span>
              )}
            </button>

            {/* User Profile Info & Logout */}
            <div className="flex items-center gap-2 pl-2 border-l border-slate-200">
              <div className="hidden sm:flex flex-col text-right">
                <span className="text-xs font-bold text-slate-800 truncate max-w-[120px]">
                  {user?.name?.split(' ')[0]}
                </span>
                <span className="text-[10px] font-medium text-blue-700 capitalize">
                  {isAdmin ? 'प्रशासक (Admin)' : isStaff ? 'स्टाफ (Staff)' : member?.memberId || 'Member'}
                </span>
              </div>

              <button
                onClick={logout}
                className="p-2 text-slate-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors"
                title={t.logout}
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Horizontal Sub-Navigation */}
        <div className="lg:hidden flex items-center space-x-1 overflow-x-auto py-2 border-t border-slate-100 scrollbar-none">
          {navItems.map((item) => {
            const active = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setCurrentTab(item.id)}
                className={`px-3 py-1 text-xs font-medium whitespace-nowrap rounded-md ${
                  active
                    ? 'bg-blue-800 text-white font-bold'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
