import React, { useState, useEffect } from 'react';
import { useLanguage } from '../../context/LanguageContext.js';
import { useAuth } from '../../context/AuthContext.js';
import { api } from '../../services/api.js';
import { AppNotification } from '../../types/index.js';
import { formatDateTime } from '../../utils/formatters.js';
import {
  Bell,
  CheckCheck,
  Megaphone,
  CreditCard,
  Banknote,
  AlertCircle,
  UserCheck,
  UserPlus,
  RefreshCw,
  Send,
} from 'lucide-react';

export const NotificationsScreen: React.FC = () => {
  const { t } = useLanguage();
  const { isAdmin } = useAuth();
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Broadcast announcement form
  const [announceTitle, setAnnounceTitle] = useState('');
  const [announceMsg, setAnnounceMsg] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [sendSuccess, setSendSuccess] = useState('');

  const fetchNotifs = async () => {
    setIsLoading(true);
    try {
      const data = await api.notifications.getAll();
      setNotifications(data);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchNotifs();
  }, []);

  const handleMarkRead = async (id: string) => {
    try {
      await api.notifications.markRead(id);
      setNotifications((prev) =>
        prev.map((n) => (n.id === id ? { ...n, isRead: true } : n))
      );
    } catch (err) {
      console.error(err);
    }
  };

  const handleMarkAllRead = async () => {
    try {
      await api.notifications.markAllRead();
      setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
    } catch (err) {
      console.error(err);
    }
  };

  const handleBroadcast = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!announceTitle || !announceMsg) return;
    setIsSending(true);
    setSendSuccess('');
    try {
      await api.notifications.sendAnnouncement({
        title: announceTitle,
        message: announceMsg,
      });
      setSendSuccess('सूचना सर्व सभासदांना यशस्वीरीत्या पाठवली गेली!');
      setAnnounceTitle('');
      setAnnounceMsg('');
      await fetchNotifs();
    } catch (err: any) {
      alert(err.message || 'त्रुटी आली');
    } finally {
      setIsSending(false);
    }
  };

  const getIcon = (type: AppNotification['type']) => {
    switch (type) {
      case 'payment_cash':
        return <Banknote className="w-5 h-5 text-amber-600" />;
      case 'payment_online':
        return <CreditCard className="w-5 h-5 text-teal-600" />;
      case 'announcement':
        return <Megaphone className="w-5 h-5 text-blue-600" />;
      case 'member_registered':
        return <UserPlus className="w-5 h-5 text-indigo-600" />;
      case 'member_approved':
        return <UserCheck className="w-5 h-5 text-emerald-600" />;
      case 'overdue_alert':
        return <AlertCircle className="w-5 h-5 text-rose-600" />;
      default:
        return <Bell className="w-5 h-5 text-blue-600" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-blue-950">
            {t.notifications}
          </h1>
          <p className="text-xs text-slate-500">
            संस्थेच्या महत्त्वपूर्ण सूचना, पेमेंट अपडेट्स आणि घोषणा
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleMarkAllRead}
            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <CheckCheck className="w-4 h-4 text-emerald-600" />
            <span>सर्व वाचल्या म्हणून खूण करा</span>
          </button>
          <button
            onClick={fetchNotifs}
            className="p-1.5 text-slate-500 hover:text-slate-800 rounded-xl hover:bg-slate-100"
            title="Refresh"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Admin Broadcast Box */}
      {isAdmin && (
        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-3xl p-6 shadow-xs">
          <h2 className="text-base font-extrabold text-blue-950 mb-1 flex items-center gap-2">
            <Megaphone className="w-4 h-4 text-blue-700" />
            <span>सर्व सदस्यांना नवीन सूचना पाठवा (Broadcast Announcement)</span>
          </h2>
          <p className="text-xs text-blue-800 mb-4">
            मासिक बैठक, विशेष उपक्रम किंवा संस्थेच्या घोषणेसाठी त्वरित सूचना जारी करा.
          </p>

          {sendSuccess && (
            <div className="mb-4 p-3 bg-emerald-100 text-emerald-900 rounded-xl text-xs font-bold">
              {sendSuccess}
            </div>
          )}

          <form onSubmit={handleBroadcast} className="space-y-3">
            <input
              type="text"
              required
              value={announceTitle}
              onChange={(e) => setAnnounceTitle(e.target.value)}
              placeholder="सूचनेचे शीर्षक (उदा. संस्थेची वार्षिक सर्वसाधारण सभा)"
              className="w-full px-3.5 py-2.5 bg-white border border-blue-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-600 font-medium"
            />
            <textarea
              required
              rows={2}
              value={announceMsg}
              onChange={(e) => setAnnounceMsg(e.target.value)}
              placeholder="सूचनेचा सविस्तर संदेश..."
              className="w-full px-3.5 py-2 bg-white border border-blue-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-600"
            />
            <div className="flex justify-end">
              <button
                type="submit"
                disabled={isSending}
                className="px-5 py-2 bg-blue-800 hover:bg-blue-900 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer"
              >
                <Send className="w-4 h-4" />
                <span>{isSending ? 'पाठवत आहे...' : 'सर्व सदस्यांना पाठवा'}</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Notifications List */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xs divide-y divide-slate-100 overflow-hidden">
        {notifications.length === 0 ? (
          <div className="p-12 text-center text-slate-400 text-sm">
            कोणत्याही नवीन सूचना नाहीत
          </div>
        ) : (
          notifications.map((n) => (
            <div
              key={n.id}
              onClick={() => handleMarkRead(n.id)}
              className={`p-4 sm:p-5 flex items-start gap-4 transition-colors cursor-pointer ${
                n.isRead ? 'bg-white hover:bg-slate-50' : 'bg-blue-50/50 hover:bg-blue-50'
              }`}
            >
              <div className="p-2.5 bg-slate-100 rounded-2xl flex-shrink-0 mt-0.5">
                {getIcon(n.type)}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <h3
                    className={`text-sm ${
                      n.isRead ? 'font-semibold text-slate-800' : 'font-extrabold text-blue-950'
                    }`}
                  >
                    {n.title}
                  </h3>
                  <span className="text-[11px] text-slate-400 whitespace-nowrap">
                    {formatDateTime(n.createdAt)}
                  </span>
                </div>
                <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                  {n.message}
                </p>
                {n.memberId && (
                  <span className="inline-block mt-1 font-mono text-[10px] text-blue-700 bg-blue-100 px-1.5 py-0.5 rounded">
                    सदस्य: {n.memberId}
                  </span>
                )}
              </div>

              {!n.isRead && (
                <span className="w-2.5 h-2.5 bg-blue-600 rounded-full flex-shrink-0 mt-2" />
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};
