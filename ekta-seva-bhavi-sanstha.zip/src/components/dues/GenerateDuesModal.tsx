import React, { useState } from 'react';
import { useLanguage } from '../../context/LanguageContext.js';
import { api } from '../../services/api.js';
import { X, CalendarCheck, CheckCircle, AlertCircle } from 'lucide-react';

interface GenerateDuesModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDuesGenerated: () => void;
}

export const GenerateDuesModal: React.FC<GenerateDuesModalProps> = ({
  isOpen,
  onClose,
  onDuesGenerated,
}) => {
  const { t } = useLanguage();
  const currentYear = new Date().getFullYear();
  const [selectedMonthYear, setSelectedMonthYear] = useState('2026-11');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [resultMsg, setResultMsg] = useState('');

  if (!isOpen) return null;

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');
    setResultMsg('');

    try {
      const res = await api.dues.generate(selectedMonthYear);
      setResultMsg(res.message);
      setTimeout(() => {
        onDuesGenerated();
        onClose();
      }, 1500);
    } catch (err: any) {
      setError(err.message || 'हप्ते जनरेट करताना त्रुटी आली');
    } finally {
      setIsLoading(false);
    }
  };

  const months = [
    { key: `${currentYear}-10`, label: `October ${currentYear}` },
    { key: `${currentYear}-11`, label: `November ${currentYear}` },
    { key: `${currentYear}-12`, label: `December ${currentYear}` },
    { key: `${currentYear + 1}-01`, label: `January ${currentYear + 1}` },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
      <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 shadow-2xl border border-slate-200 relative">
        <button
          onClick={onClose}
          className="absolute top-6 right-6 p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-full transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-teal-100 text-teal-900 rounded-2xl">
            <CalendarCheck className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-extrabold text-blue-950">
              मासिक हप्ते जनरेट करा
            </h2>
            <p className="text-xs text-slate-500">
              सर्व सक्रिय सदस्यांसाठी ₹१,००० चा मासिक हप्ता तयार करा
            </p>
          </div>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {resultMsg ? (
          <div className="py-6 text-center space-y-2">
            <CheckCircle className="w-12 h-12 text-emerald-600 mx-auto" />
            <p className="text-sm font-bold text-emerald-950">{resultMsg}</p>
          </div>
        ) : (
          <form onSubmit={handleGenerate} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                महिना निवडा (Billing Month)
              </label>
              <select
                required
                value={selectedMonthYear}
                onChange={(e) => setSelectedMonthYear(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-semibold focus:bg-white focus:ring-2 focus:ring-blue-600"
              >
                {months.map((m) => (
                  <option key={m.key} value={m.key}>
                    {m.label} ({m.key})
                  </option>
                ))}
              </select>
            </div>

            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-600 space-y-1">
              <div className="flex justify-between">
                <span>प्रति सदस्य योगदान:</span>
                <span className="font-bold text-blue-900">₹1,000 / महिना</span>
              </div>
              <div className="flex justify-between">
                <span>देय तारीख:</span>
                <span className="font-bold text-slate-800">१० तारीख</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-2">
                * ज्या सदस्यांचा हप्ता आधीच तयार आहे त्यांची डुप्लिकेट नोंद होणार नाही.
              </p>
            </div>

            <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                {t.cancel}
              </button>
              <button
                type="submit"
                disabled={isLoading}
                className="px-6 py-2.5 bg-blue-800 hover:bg-blue-900 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer"
              >
                {isLoading ? <span>{t.loading}</span> : <span>हप्ते तयार करा</span>}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
