import React, { useState, useEffect } from 'react';
import { useLanguage } from '../../context/LanguageContext.js';
import { useAuth } from '../../context/AuthContext.js';
import { api } from '../../services/api.js';
import { MonthlyDue, Member, Receipt } from '../../types/index.js';
import { formatINR, formatDate } from '../../utils/formatters.js';
import {
  Calendar,
  Filter,
  CheckCircle,
  Clock,
  AlertCircle,
  PlusCircle,
  Banknote,
  Smartphone,
  Search,
  RefreshCw,
  FileText,
} from 'lucide-react';

interface MonthlyDuesScreenProps {
  onOpenCashDeposit: (memberId: string, monthYear: string) => void;
  onOpenOnlinePayment: (memberId: string, monthYear: string) => void;
  onViewReceipt: (receipt: Receipt) => void;
  onOpenGenerateDuesModal: () => void;
}

export const MonthlyDuesScreen: React.FC<MonthlyDuesScreenProps> = ({
  onOpenCashDeposit,
  onOpenOnlinePayment,
  onViewReceipt,
  onOpenGenerateDuesModal,
}) => {
  const { t } = useLanguage();
  const { isAdmin } = useAuth();
  const [dues, setDues] = useState<MonthlyDue[]>([]);
  const [members, setMembers] = useState<Member[]>([]);
  const [selectedMonth, setSelectedMonth] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [searchMember, setSearchMember] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  const fetchDues = async () => {
    setIsLoading(true);
    try {
      const [duesData, membersData] = await Promise.all([
        api.dues.getAll({
          monthYear: selectedMonth === 'all' ? undefined : selectedMonth,
          status: selectedStatus === 'all' ? undefined : selectedStatus,
        }),
        api.members.getAll(),
      ]);
      setDues(duesData);
      setMembers(membersData);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchDues();
  }, [selectedMonth, selectedStatus]);

  const memberMap = new Map<string, Member>();
  for (const m of members) {
    memberMap.set(m.memberId, m);
  }

  const filteredDues = dues.filter((d) => {
    if (!searchMember) return true;
    const q = searchMember.toLowerCase();
    const mem = memberMap.get(d.memberId);
    return (
      d.memberId.toLowerCase().includes(q) ||
      (mem && mem.fullName.toLowerCase().includes(q))
    );
  });

  // Calculate totals
  const totalDuePaise = filteredDues.reduce((sum, d) => sum + d.amountDuePaise, 0);
  const totalPaidPaise = filteredDues.reduce((sum, d) => sum + d.amountPaidPaise, 0);
  const totalBalancePaise = filteredDues.reduce((sum, d) => sum + d.remainingPaise, 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-blue-950">
            {t.monthlyDuesTitle}
          </h1>
          <p className="text-xs text-slate-500">
            संस्थेच्या सर्व सभासदांचे मासिक वर्गणी हप्ते, जमा व थकबाकी लेजर
          </p>
        </div>

        {isAdmin && (
          <button
            onClick={onOpenGenerateDuesModal}
            className="px-4 py-2.5 bg-blue-800 hover:bg-blue-900 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer"
          >
            <PlusCircle className="w-4 h-4" />
            <span>हप्ते जनरेट करा (Generate Dues)</span>
          </button>
        )}
      </div>

      {/* Summary KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold uppercase text-slate-500 block">
            एकूण देय रक्कम (Total Dues)
          </span>
          <span className="text-2xl font-black text-slate-900 mt-1 block">
            {formatINR(totalDuePaise)}
          </span>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold uppercase text-emerald-700 block">
            एकूण वसूल झालेली रक्कम (Total Collected)
          </span>
          <span className="text-2xl font-black text-emerald-800 mt-1 block">
            {formatINR(totalPaidPaise)}
          </span>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold uppercase text-rose-700 block">
            एकूण शिल्लक बाकी (Remaining Balance)
          </span>
          <span className="text-2xl font-black text-rose-900 mt-1 block">
            {formatINR(totalBalancePaise)}
          </span>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex flex-wrap gap-3 items-center justify-between">
        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
          <input
            type="text"
            value={searchMember}
            onChange={(e) => setSearchMember(e.target.value)}
            placeholder="सदस्य शोधा (नाव किंवा M001)..."
            className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Month Filter */}
          <select
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(e.target.value)}
            className="px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-700 focus:bg-white focus:ring-2 focus:ring-blue-600"
          >
            <option value="all">सर्व महिने (All Months)</option>
            <option value="2026-10">ऑक्टोबर २०२६ (October 2026)</option>
            <option value="2026-09">सप्टेंबर २०२६ (September 2026)</option>
            <option value="2026-08">ऑगस्ट २०२६ (August 2026)</option>
            <option value="2026-11">नोव्हेंबर २०२६ (November 2026)</option>
          </select>

          {/* Status Filter */}
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-700 focus:bg-white focus:ring-2 focus:ring-blue-600"
          >
            <option value="all">{t.all} स्थिती</option>
            <option value="paid">{t.paid}</option>
            <option value="unpaid">{t.unpaid}</option>
            <option value="partially_paid">{t.partiallyPaid}</option>
            <option value="overdue">{t.overdue}</option>
          </select>

          <button
            onClick={fetchDues}
            className="p-2 text-slate-500 hover:text-slate-800 rounded-xl hover:bg-slate-100"
            title="Refresh"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Dues Table */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase font-bold tracking-wider">
                <th className="py-3 px-4">{t.memberId}</th>
                <th className="py-3 px-4">{t.fullName}</th>
                <th className="py-3 px-4">{t.monthYear}</th>
                <th className="py-3 px-4">{t.amountDue}</th>
                <th className="py-3 px-4">{t.amountPaid}</th>
                <th className="py-3 px-4">{t.remainingAmount}</th>
                <th className="py-3 px-4">{t.dueDate}</th>
                <th className="py-3 px-4">{t.status}</th>
                <th className="py-3 px-4 text-right">{t.actions}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {filteredDues.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-8 text-center text-slate-400">
                    या निकषांनुसार कोणतेही हप्ते उपलब्ध नाहीत
                  </td>
                </tr>
              ) : (
                filteredDues.map((d) => {
                  const mem = memberMap.get(d.memberId);
                  return (
                    <tr key={d.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3.5 px-4 font-mono font-bold text-blue-900">
                        {d.memberId}
                      </td>
                      <td className="py-3.5 px-4">
                        <span className="font-bold text-slate-900 block">
                          {mem ? mem.fullName : d.memberId}
                        </span>
                        <span className="text-[10px] text-slate-400">
                          {mem ? mem.mobile : ''}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 font-bold text-blue-950">
                        {d.monthLabel || d.monthYear}
                      </td>
                      <td className="py-3.5 px-4 text-slate-700">
                        {formatINR(d.amountDuePaise)}
                      </td>
                      <td className="py-3.5 px-4 font-bold text-emerald-700">
                        {formatINR(d.amountPaidPaise)}
                      </td>
                      <td className="py-3.5 px-4 font-bold text-rose-700">
                        {formatINR(d.remainingPaise)}
                      </td>
                      <td className="py-3.5 px-4 text-slate-500">
                        {formatDate(d.dueDate)}
                      </td>
                      <td className="py-3.5 px-4">
                        {d.status === 'paid' && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                            <CheckCircle className="w-3 h-3" />
                            <span>{t.paid}</span>
                          </span>
                        )}
                        {d.status === 'partially_paid' && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800">
                            <Clock className="w-3 h-3" />
                            <span>{t.partiallyPaid}</span>
                          </span>
                        )}
                        {d.status === 'unpaid' && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800">
                            <AlertCircle className="w-3 h-3" />
                            <span>{t.unpaid}</span>
                          </span>
                        )}
                        {d.status === 'overdue' && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-200 text-rose-950">
                            <AlertCircle className="w-3 h-3" />
                            <span>{t.overdue}</span>
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {d.remainingPaise > 0 ? (
                            <>
                              {isAdmin && (
                                <button
                                  onClick={() => onOpenCashDeposit(d.memberId, d.monthYear)}
                                  className="px-2 py-1 text-[11px] font-bold text-amber-900 bg-amber-100 hover:bg-amber-200 rounded-lg transition-colors cursor-pointer"
                                >
                                  रोख जमा
                                </button>
                              )}
                              <button
                                onClick={() => onOpenOnlinePayment(d.memberId, d.monthYear)}
                                className="px-2 py-1 text-[11px] font-bold text-teal-900 bg-teal-100 hover:bg-teal-200 rounded-lg transition-colors cursor-pointer"
                              >
                                UPI
                              </button>
                            </>
                          ) : (
                            <span className="text-[11px] font-bold text-emerald-700 flex items-center gap-1">
                              <CheckCircle className="w-3.5 h-3.5" />
                              <span>पूर्ण</span>
                            </span>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
