import React, { useState, useEffect } from 'react';
import { useLanguage } from '../../context/LanguageContext.js';
import { useAuth } from '../../context/AuthContext.js';
import { api } from '../../services/api.js';
import { Member, MonthlyDue, Payment, Receipt } from '../../types/index.js';
import { formatINR, formatDate } from '../../utils/formatters.js';
import {
  ArrowLeft,
  User,
  Phone,
  Mail,
  MapPin,
  Calendar,
  CheckCircle,
  AlertCircle,
  Clock,
  Banknote,
  FileText,
  CreditCard,
  RefreshCw,
  Wallet,
  ShieldCheck,
} from 'lucide-react';

interface MemberDetailsProps {
  memberId: string;
  onBack: () => void;
  onOpenCashDeposit: (memberId: string, monthYear?: string) => void;
  onOpenOnlinePayment: (memberId: string, monthYear?: string) => void;
  onViewReceipt: (receipt: Receipt) => void;
}

export const MemberDetails: React.FC<MemberDetailsProps> = ({
  memberId,
  onBack,
  onOpenCashDeposit,
  onOpenOnlinePayment,
  onViewReceipt,
}) => {
  const { t } = useLanguage();
  const { isAdmin, user } = useAuth();
  const [data, setData] = useState<{
    member: Member;
    dues: MonthlyDue[];
    payments: Payment[];
    receipts: Receipt[];
    summary: {
      totalPaidPaise: number;
      outstandingBalancePaise: number;
      totalMonthsDues: number;
      paidMonthsCount: number;
    };
  } | null>(null);

  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [showAllMonths, setShowAllMonths] = useState(false);

  const loadMemberData = async () => {
    setIsLoading(true);
    setError('');
    try {
      const res = await api.members.getById(memberId);
      setData(res);
    } catch (err: any) {
      setError(err.message || 'Failed to load member profile');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadMemberData();
  }, [memberId]);

  const handleReceiptLookup = async (receiptNumOrPaymentId: string) => {
    try {
      const rcp = await api.receipts.getById(receiptNumOrPaymentId);
      if (rcp) onViewReceipt(rcp);
    } catch (err: any) {
      alert('Receipt could not be opened: ' + err.message);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <RefreshCw className="w-8 h-8 text-blue-700 animate-spin" />
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="bg-white rounded-3xl p-8 border border-slate-200 text-center max-w-md mx-auto">
        <AlertCircle className="w-12 h-12 text-rose-500 mx-auto mb-3" />
        <h3 className="text-lg font-bold text-slate-800 mb-2">त्रुटी</h3>
        <p className="text-xs text-slate-600 mb-6">{error || 'सदस्य सापडला नाही'}</p>
        <button
          onClick={onBack}
          className="px-4 py-2 bg-blue-800 text-white text-xs font-bold rounded-xl"
        >
          {t.back}
        </button>
      </div>
    );
  }

  const { member, dues, receipts, summary } = data;
  const displayedDues = showAllMonths ? dues : dues.slice(0, 6);

  return (
    <div className="space-y-6">
      {/* Top back button */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 px-3 py-1.5 text-xs font-bold text-blue-900 bg-white hover:bg-slate-100 rounded-xl border border-slate-200 transition-colors shadow-2xs cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{t.back}</span>
        </button>

        <div className="flex items-center gap-2">
          {isAdmin && (
            <button
              onClick={() => onOpenCashDeposit(member.memberId)}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs rounded-xl shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Banknote className="w-4 h-4" />
              <span>{t.monthlyDepositBtn}</span>
            </button>
          )}

          {(isAdmin || user?.memberId === member.memberId) && (
            <button
              onClick={() => onOpenOnlinePayment(member.memberId)}
              className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-xl shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <CreditCard className="w-4 h-4" />
              <span>{t.payNow}</span>
            </button>
          )}
        </div>
      </div>

      {/* MEMBER PROFILE HEADER CARD */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-start gap-4">
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-br from-blue-700 to-indigo-900 text-white flex items-center justify-center font-black text-2xl shadow-md flex-shrink-0">
              {member.fullName.charAt(0)}
            </div>

            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-mono font-bold text-xs bg-blue-100 text-blue-900 px-2 py-0.5 rounded border border-blue-200">
                  {member.memberId}
                </span>
                <span
                  className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold ${
                    member.status === 'active'
                      ? 'bg-emerald-100 text-emerald-800'
                      : member.status === 'pending_approval'
                      ? 'bg-amber-100 text-amber-800'
                      : 'bg-slate-100 text-slate-700'
                  }`}
                >
                  <CheckCircle className="w-3 h-3" />
                  <span>
                    {member.status === 'active'
                      ? t.active
                      : member.status === 'pending_approval'
                      ? t.pending
                      : t.inactive}
                  </span>
                </span>
              </div>

              <h1 className="text-xl sm:text-2xl font-black text-blue-950 mt-1">
                {member.fullName}
              </h1>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-1 mt-2 text-xs text-slate-600">
                <div className="flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-slate-400" />
                  <span className="font-mono font-medium">
                    {(!isAdmin && user?.memberId !== member.memberId) ? '••••••••••' : member.mobile}
                  </span>
                </div>
                {member.email && (isAdmin || user?.memberId === member.memberId) && (
                  <div className="flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-slate-400" />
                    <span>{member.email}</span>
                  </div>
                )}
                <div className="flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-slate-400" />
                  <span>
                    {(!isAdmin && user?.memberId !== member.memberId) ? 'कळमनुरी (Kalamnuri)' : (member.address || 'Mali Galli, Kalamnuri')}
                  </span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  <span>जोडल्याची तारीख: {formatDate(member.joiningDate)}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Balance Cards */}
          <div className="grid grid-cols-2 gap-3 min-w-[240px]">
            <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 text-center">
              <span className="text-[10px] uppercase font-bold text-emerald-800 tracking-wider block">
                {t.totalPaid}
              </span>
              <span className="text-xl font-black text-emerald-900 block mt-1">
                {formatINR(summary.totalPaidPaise)}
              </span>
              <span className="text-[10px] text-emerald-700 mt-0.5 block">
                {summary.paidMonthsCount} महिने पूर्ण
              </span>
            </div>

            <div className="bg-rose-50 border border-rose-200 rounded-2xl p-4 text-center">
              <span className="text-[10px] uppercase font-bold text-rose-800 tracking-wider block">
                {t.outstandingBalance}
              </span>
              <span className="text-xl font-black text-rose-900 block mt-1">
                {formatINR(summary.outstandingBalancePaise)}
              </span>
              <span className="text-[10px] text-rose-700 mt-0.5 block">
                थकबाकी / बाकी
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* MONTH-BY-MONTH CONTRIBUTION HISTORY (MATCHING SCREEN 4) */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-base font-extrabold text-blue-950">
              मासिक वर्गणी इतिहास (Monthly Contribution Ledger)
            </h2>
            <p className="text-xs text-slate-500">
              प्रत्येक महिन्याचे देय, भरलेली रक्कम, शिल्लक व पावती
            </p>
          </div>
          {dues.length > 6 && (
            <button
              onClick={() => setShowAllMonths(!showAllMonths)}
              className="text-xs font-bold text-blue-700 hover:text-blue-900 underline cursor-pointer"
            >
              {showAllMonths ? 'कमी दाखवा (Show Less)' : `पूर्ण इतिहास पहा (${dues.length} महिने)`}
            </button>
          )}
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase font-bold tracking-wider">
                <th className="py-3 px-3">{t.monthYear}</th>
                <th className="py-3 px-3">{t.amountDue}</th>
                <th className="py-3 px-3">{t.amountPaid}</th>
                <th className="py-3 px-3">{t.remainingAmount}</th>
                <th className="py-3 px-3">{t.dueDate}</th>
                <th className="py-3 px-3">{t.status}</th>
                <th className="py-3 px-3 text-right">{t.actions}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {displayedDues.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-6 text-center text-slate-400">
                    या सदस्यासाठी अद्याप हप्ते नोंदवलेले नाहीत
                  </td>
                </tr>
              ) : (
                displayedDues.map((due) => {
                  const matchingReceipt = receipts.find((r) => r.monthYear === due.monthYear);
                  return (
                    <tr key={due.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3.5 px-3 font-bold text-blue-950">
                        {due.monthLabel || due.monthYear}
                      </td>
                      <td className="py-3.5 px-3 text-slate-700">
                        {formatINR(due.amountDuePaise)}
                      </td>
                      <td className="py-3.5 px-3 font-bold text-emerald-700">
                        {formatINR(due.amountPaidPaise)}
                      </td>
                      <td className="py-3.5 px-3 font-bold text-rose-700">
                        {formatINR(due.remainingPaise)}
                      </td>
                      <td className="py-3.5 px-3 text-slate-500">
                        {formatDate(due.dueDate)}
                      </td>
                      <td className="py-3.5 px-3">
                        {due.status === 'paid' && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                            <CheckCircle className="w-3 h-3" />
                            <span>{t.paid}</span>
                          </span>
                        )}
                        {due.status === 'partially_paid' && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800">
                            <Clock className="w-3 h-3" />
                            <span>{t.partiallyPaid}</span>
                          </span>
                        )}
                        {due.status === 'unpaid' && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800">
                            <AlertCircle className="w-3 h-3" />
                            <span>{t.unpaid}</span>
                          </span>
                        )}
                        {due.status === 'overdue' && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-200 text-rose-950">
                            <AlertCircle className="w-3 h-3" />
                            <span>{t.overdue}</span>
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 px-3 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {matchingReceipt && (isAdmin || user?.memberId === member.memberId) ? (
                            <button
                              onClick={() => onViewReceipt(matchingReceipt)}
                              className="px-2.5 py-1 text-[11px] font-bold text-blue-800 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors inline-flex items-center gap-1 cursor-pointer"
                            >
                              <FileText className="w-3 h-3" />
                              <span>पावती</span>
                            </button>
                          ) : due.remainingPaise > 0 ? (
                            <>
                              {isAdmin && (
                                <button
                                  onClick={() => onOpenCashDeposit(member.memberId, due.monthYear)}
                                  className="px-2 py-1 text-[11px] font-bold text-amber-900 bg-amber-100 hover:bg-amber-200 rounded-lg transition-colors cursor-pointer"
                                >
                                  रोख जमा
                                </button>
                              )}
                              {(isAdmin || user?.memberId === member.memberId) && (
                                <button
                                  onClick={() => onOpenOnlinePayment(member.memberId, due.monthYear)}
                                  className="px-2 py-1 text-[11px] font-bold text-teal-900 bg-teal-100 hover:bg-teal-200 rounded-lg transition-colors cursor-pointer"
                                >
                                  UPI भरा
                                </button>
                              )}
                            </>
                          ) : null}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
