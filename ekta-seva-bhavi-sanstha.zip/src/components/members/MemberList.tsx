import React, { useState, useEffect } from 'react';
import { useLanguage } from '../../context/LanguageContext.js';
import { useAuth } from '../../context/AuthContext.js';
import { api } from '../../services/api.js';
import { Member } from '../../types/index.js';
import { formatINR, formatDate } from '../../utils/formatters.js';
import {
  Search,
  UserPlus,
  Filter,
  CheckCircle,
  XCircle,
  MoreVertical,
  Banknote,
  Eye,
  Edit2,
  UserCheck,
  UserX,
  Phone,
  Mail,
  RefreshCw,
  ShieldCheck,
  Users,
  Wallet,
  AlertTriangle,
} from 'lucide-react';

interface MemberListProps {
  onSelectMember: (memberId: string) => void;
  onOpenAddMember: () => void;
  onOpenCashDepositForMember: (memberId: string) => void;
}

export const MemberList: React.FC<MemberListProps> = ({
  onSelectMember,
  onOpenAddMember,
  onOpenCashDepositForMember,
}) => {
  const { t, language } = useLanguage();
  const { isAdmin, user } = useAuth();
  const [members, setMembers] = useState<Member[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [isLoading, setIsLoading] = useState(true);
  const [actionLoadingId, setActionLoadingId] = useState<string | null>(null);

  const fetchMembers = async () => {
    setIsLoading(true);
    try {
      const data = await api.members.getAll({
        search: searchQuery,
        status: statusFilter,
      });
      setMembers(data);
    } catch (err: any) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchMembers();
  }, [statusFilter]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchMembers();
  };

  const handleStatusChange = async (memberId: string, newStatus: Member['status']) => {
    if (!isAdmin) return;
    if (!window.confirm(`Are you sure you want to change member status to ${newStatus}?`)) {
      return;
    }
    setActionLoadingId(memberId);
    try {
      await api.members.setStatus(memberId, newStatus);
      await fetchMembers();
    } catch (err: any) {
      alert(err.message || 'Failed to update member status');
    } finally {
      setActionLoadingId(null);
    }
  };

  // Aggregate stats
  const totalPaidSum = members.reduce((sum, m) => sum + (m.totalPaidPaise || 0), 0);
  const totalPendingSum = members.reduce((sum, m) => sum + (m.remainingBalancePaise || 0), 0);
  const activeMembersCount = members.filter((m) => m.status === 'active').length;

  return (
    <div className="space-y-6">
      {/* Top Header & Search Bar */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-extrabold text-blue-950">
              {isAdmin ? t.memberListTitle : (language === 'mr' ? 'सर्व सभासद व खातेवही (Shared Ledger)' : 'Member Directory & Ledger')}
            </h1>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800">
              {isAdmin ? 'Admin View' : 'Verified Member View'}
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            {language === 'mr'
              ? 'एकता सेवा भावी संस्था, माळी गल्ली, कळमनुरी — सर्व सभासदांचे एकूण योगदान, जमा रक्कम व शिल्लक'
              : 'Ekta Seva Bhavi Sanstha, Kalamnuri — Shared contribution ledger, paid amounts and balances'}
          </p>
        </div>

        {isAdmin && (
          <div className="flex items-center gap-3">
            <button
              onClick={onOpenAddMember}
              className="px-4 py-2.5 bg-blue-800 hover:bg-blue-900 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer"
            >
              <UserPlus className="w-4 h-4" />
              <span>{t.addMemberBtn}</span>
            </button>
          </div>
        )}
      </div>

      {/* Aggregate Overview Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-gradient-to-br from-blue-900 to-indigo-950 text-white rounded-2xl p-4 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs text-blue-200 font-semibold">{language === 'mr' ? 'एकूण सक्रिय सभासद' : 'Active Members'}</p>
            <p className="text-2xl font-black mt-1">{activeMembersCount}</p>
          </div>
          <div className="p-3 bg-blue-800/60 rounded-xl">
            <Users className="w-6 h-6 text-amber-300" />
          </div>
        </div>

        <div className="bg-gradient-to-br from-emerald-800 to-teal-950 text-white rounded-2xl p-4 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs text-emerald-200 font-semibold">{language === 'mr' ? 'एकूण जमा रक्कम (Paid)' : 'Total Paid'}</p>
            <p className="text-2xl font-black mt-1">{formatINR(totalPaidSum)}</p>
          </div>
          <div className="p-3 bg-emerald-700/60 rounded-xl">
            <Wallet className="w-6 h-6 text-emerald-300" />
          </div>
        </div>

        <div className="bg-gradient-to-br from-amber-800 to-orange-950 text-white rounded-2xl p-4 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs text-amber-200 font-semibold">{language === 'mr' ? 'एकूण येणे शिल्लक (Pending)' : 'Total Pending'}</p>
            <p className="text-2xl font-black mt-1">{formatINR(totalPendingSum)}</p>
          </div>
          <div className="p-3 bg-amber-700/60 rounded-xl">
            <AlertTriangle className="w-6 h-6 text-amber-300" />
          </div>
        </div>
      </div>

      {/* Search & Filter Controls */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex flex-col sm:flex-row gap-3 items-center justify-between">
        <form onSubmit={handleSearchSubmit} className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t.search}
            className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600"
          />
        </form>

        <div className="flex items-center gap-2 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0">
          <Filter className="w-4 h-4 text-slate-400 flex-shrink-0" />
          {['all', 'active', 'pending_approval', 'inactive'].map((statusKey) => (
            <button
              key={statusKey}
              onClick={() => setStatusFilter(statusKey)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap transition-colors ${
                statusFilter === statusKey
                  ? 'bg-blue-800 text-white'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              {statusKey === 'all' && t.all}
              {statusKey === 'active' && t.active}
              {statusKey === 'pending_approval' && t.pending}
              {statusKey === 'inactive' && t.inactive}
            </button>
          ))}
          <button
            onClick={fetchMembers}
            className="p-1.5 text-slate-500 hover:text-slate-800 rounded-lg hover:bg-slate-100"
            title="Refresh"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Members Directory Cards & Table */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase font-bold tracking-wider">
                <th className="py-3 px-4">{t.memberId}</th>
                <th className="py-3 px-4">{t.fullName}</th>
                <th className="py-3 px-4">{isAdmin ? t.mobileNumber : (language === 'mr' ? 'मोबाईल (गोपनीय)' : 'Contact (Protected)')}</th>
                <th className="py-3 px-4">{language === 'mr' ? 'एकूण जमा (Paid)' : 'Total Paid'}</th>
                <th className="py-3 px-4">{language === 'mr' ? 'शिल्लक (Balance)' : 'Pending Balance'}</th>
                <th className="py-3 px-4">{t.status}</th>
                <th className="py-3 px-4 text-right">{t.actions}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {members.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400">
                    कोणतेही सदस्य आढळले नाहीत
                  </td>
                </tr>
              ) : (
                members.map((m) => (
                  <tr key={m.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-4">
                      <span className="font-mono font-bold text-blue-900 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                        {m.memberId}
                      </span>
                    </td>
                    <td className="py-3.5 px-4">
                      <div
                        onClick={() => onSelectMember(m.memberId)}
                        className="font-bold text-slate-900 hover:text-blue-800 cursor-pointer"
                      >
                        {m.fullName}
                      </div>
                      <div className="text-[10px] text-slate-400 truncate max-w-[200px]">
                        {(!isAdmin && m.memberId !== user?.memberId) ? 'कळमनुरी (Kalamnuri)' : (m.address || 'Mali Galli, Kalamnuri')}
                      </div>
                    </td>
                    <td className="py-3.5 px-4 font-mono text-slate-700">
                      <div className="flex items-center gap-1">
                        <Phone className="w-3 h-3 text-slate-400" />
                        <span>{(!isAdmin && m.memberId !== user?.memberId) ? '••••••••••' : m.mobile}</span>
                      </div>
                    </td>
                    <td className="py-3.5 px-4 font-bold text-emerald-700">
                      {formatINR(m.totalPaidPaise || 0)}
                    </td>
                    <td className="py-3.5 px-4 font-bold">
                      {(m.remainingBalancePaise || 0) > 0 ? (
                        <span className="text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200 font-mono">
                          {formatINR(m.remainingBalancePaise || 0)}
                        </span>
                      ) : (
                        <span className="text-emerald-700 font-semibold">
                          ₹0 (Nil)
                        </span>
                      )}
                    </td>
                    <td className="py-3.5 px-4">
                      {m.status === 'active' && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                          <CheckCircle className="w-3 h-3" />
                          <span>{t.active}</span>
                        </span>
                      )}
                      {m.status === 'pending_approval' && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 animate-pulse">
                          <span>{t.pending}</span>
                        </span>
                      )}
                      {m.status === 'inactive' && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-600">
                          <span>{t.inactive}</span>
                        </span>
                      )}
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => onSelectMember(m.memberId)}
                          className="px-2 py-1 text-[11px] font-bold text-blue-800 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors inline-flex items-center gap-1 cursor-pointer"
                          title={t.viewDetails}
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>{language === 'mr' ? 'तपशील' : 'Details'}</span>
                        </button>

                        {/* Admin-only action buttons */}
                        {isAdmin && (
                          <>
                            {m.status === 'active' && (
                              <button
                                onClick={() => onOpenCashDepositForMember(m.memberId)}
                                className="px-2 py-1 text-[11px] font-bold text-amber-900 bg-amber-50 hover:bg-amber-100 rounded-lg transition-colors inline-flex items-center gap-1 cursor-pointer"
                                title={t.recordCashDeposit}
                              >
                                <Banknote className="w-3.5 h-3.5 text-amber-600" />
                                <span>जमा</span>
                              </button>
                            )}

                            {m.status === 'pending_approval' && (
                              <button
                                disabled={actionLoadingId === m.memberId}
                                onClick={() => handleStatusChange(m.memberId, 'active')}
                                className="px-2 py-1 text-[11px] font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-colors inline-flex items-center gap-1"
                                title={t.approveMember}
                              >
                                <UserCheck className="w-3.5 h-3.5" />
                                <span>मंजूर</span>
                              </button>
                            )}

                            {m.status === 'active' && (
                              <button
                                disabled={actionLoadingId === m.memberId}
                                onClick={() => handleStatusChange(m.memberId, 'inactive')}
                                className="p-1 text-slate-400 hover:text-rose-600 rounded-md transition-colors"
                                title={t.deactivateMember}
                              >
                                <UserX className="w-3.5 h-3.5" />
                              </button>
                            )}

                            {m.status === 'inactive' && (
                              <button
                                disabled={actionLoadingId === m.memberId}
                                onClick={() => handleStatusChange(m.memberId, 'active')}
                                className="p-1 text-slate-400 hover:text-emerald-600 rounded-md transition-colors"
                                title={t.activateMember}
                              >
                                <UserCheck className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

