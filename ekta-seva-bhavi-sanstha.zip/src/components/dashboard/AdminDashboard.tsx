import React, { useState, useEffect } from 'react';
import { useLanguage } from '../../context/LanguageContext.js';
import { api } from '../../services/api.js';
import {
  DashboardStats,
  MonthlyChartData,
  Payment,
  Receipt,
  SansthaUpdate,
  SharedSansthaFinancials,
} from '../../types/index.js';
import { formatINR, formatDate } from '../../utils/formatters.js';
import { SansthaLogo } from '../common/SansthaLogo.js';
import { SharedFinancialCard } from '../updates/SharedFinancialCard.js';
import { SansthaUpdatesSection } from '../updates/SansthaUpdatesSection.js';
import { ManageUpdateModal } from '../updates/ManageUpdateModal.js';
import {
  Users,
  Wallet,
  Banknote,
  Smartphone,
  Clock,
  AlertTriangle,
  UserPlus,
  PlusCircle,
  CalendarCheck,
  FileText,
  FileCheck,
  ArrowUpRight,
  TrendingUp,
  RefreshCw,
  Settings,
} from 'lucide-react';

interface AdminDashboardProps {
  onNavigate: (tab: string) => void;
  onOpenCashDeposit: () => void;
  onOpenAddMember: () => void;
  onViewReceipt: (receipt: Receipt) => void;
  onOpenGenerateDuesModal: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  onNavigate,
  onOpenCashDeposit,
  onOpenAddMember,
  onViewReceipt,
  onOpenGenerateDuesModal,
}) => {
  const { t } = useLanguage();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [trends, setTrends] = useState<MonthlyChartData[]>([]);
  const [recentPayments, setRecentPayments] = useState<Payment[]>([]);
  const [updates, setUpdates] = useState<SansthaUpdate[]>([]);
  const [financials, setFinancials] = useState<SharedSansthaFinancials | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [lastSyncTime, setLastSyncTime] = useState<Date>(new Date());

  // Update modal state
  const [isUpdateModalOpen, setIsUpdateModalOpen] = useState(false);
  const [selectedUpdateToEdit, setSelectedUpdateToEdit] = useState<SansthaUpdate | null>(null);

  const loadData = async (silent = false) => {
    if (!silent) setIsLoading(true);
    setError('');
    try {
      const [dashRes, updatesRes, finRes] = await Promise.all([
        api.reports.getDashboard(),
        api.updates.getAll(),
        api.financials.getShared(),
      ]);
      setStats(dashRes.stats);
      setTrends(dashRes.trends);
      setRecentPayments(dashRes.recentPayments);
      setUpdates(updatesRes);
      setFinancials(finRes);
      setLastSyncTime(new Date());
    } catch (err: any) {
      setError(err.message || 'Failed to load dashboard data');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
    const interval = setInterval(() => loadData(true), 12000);
    return () => clearInterval(interval);
  }, []);

  const handleReceiptClick = async (receiptNum: string) => {
    try {
      const rcp = await api.receipts.getById(receiptNum);
      if (rcp) onViewReceipt(rcp);
    } catch (err: any) {
      alert('Receipt could not be retrieved: ' + err.message);
    }
  };

  if (isLoading && !stats) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="flex flex-col items-center gap-3">
          <RefreshCw className="w-8 h-8 text-blue-700 animate-spin" />
          <p className="text-sm font-semibold text-slate-600">{t.loading}</p>
        </div>
      </div>
    );
  }

  // Max value calculation for bar chart scaling
  const maxCollection = trends.reduce((max, cur) => Math.max(max, cur.totalPaise), 100000);

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-blue-800 text-white rounded-3xl p-6 sm:p-8 shadow-lg relative overflow-hidden">
        <div className="absolute right-0 top-0 w-80 h-full bg-white/5 skew-x-12 pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="p-1 bg-white/10 rounded-2xl backdrop-blur-xs border border-white/15 shadow-md flex-shrink-0">
              <SansthaLogo size="lg" light={true} />
            </div>
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-700/60 text-blue-100 text-xs font-semibold mb-1">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>प्रशासक पोर्टल • थेट डेटा (Live Database)</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
                {t.appName}
              </h1>
              <p className="text-xs sm:text-sm text-blue-200 mt-0.5">
                माळी गल्ली, कळमनुरी • मासिक वर्गणी हप्ते व आर्थिक व्यवस्थापन
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={onOpenCashDeposit}
              className="px-4 py-2.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer"
            >
              <Banknote className="w-4 h-4" />
              <span>{t.monthlyDepositBtn}</span>
            </button>
            <button
              onClick={onOpenGenerateDuesModal}
              className="px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white font-semibold text-xs sm:text-sm rounded-xl border border-white/20 transition-all flex items-center gap-2 cursor-pointer"
            >
              <CalendarCheck className="w-4 h-4 text-teal-300" />
              <span>{t.generateDuesBtn}</span>
            </button>
            <button
              onClick={() => onNavigate('settings')}
              className="px-4 py-2.5 bg-white/10 hover:bg-white/25 text-white font-bold text-xs sm:text-sm rounded-xl border border-white/25 shadow-xs transition-all flex items-center gap-2 cursor-pointer hover:border-amber-300"
              title="संस्था व अ‍ॅप सेटिंग्ज (Admin Settings & Modify App)"
            >
              <Settings className="w-4 h-4 text-amber-300" />
              <span>{t.settings}</span>
            </button>
          </div>
        </div>
      </div>

      {error && (
        <div className="p-4 bg-rose-50 border border-rose-200 text-rose-800 rounded-2xl text-sm">
          {error}
        </div>
      )}

      {/* Institutional Shared Financials */}
      <SharedFinancialCard
        financials={financials}
        isLoading={isLoading}
        onRefresh={() => loadData(true)}
      />

      {/* Sanstha Live Updates & Activities Feed */}
      <SansthaUpdatesSection
        updates={updates}
        isLoading={isLoading}
        onRefresh={() => loadData(true)}
        onOpenAddUpdate={() => {
          setSelectedUpdateToEdit(null);
          setIsUpdateModalOpen(true);
        }}
        onEditUpdate={(u) => {
          setSelectedUpdateToEdit(u);
          setIsUpdateModalOpen(true);
        }}
        lastSyncTime={lastSyncTime}
      />

      {/* KPI METRIC CARDS (6 Grid) */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        {/* Total Members */}
        <div
          onClick={() => onNavigate('members')}
          className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs hover:border-blue-300 hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-600">
              {t.totalMembersCount}
            </span>
            <div className="p-2 bg-blue-50 text-blue-700 rounded-xl group-hover:scale-110 transition-transform">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-900">
            {stats?.totalMembers || 0}
          </div>
          <div className="text-[11px] text-emerald-600 font-semibold mt-1 flex items-center gap-1">
            <span>{stats?.activeMembers || 0} सक्रिय</span>
            {stats?.pendingApprovals ? (
              <span className="text-amber-600">• {stats.pendingApprovals} प्रलंबित</span>
            ) : null}
          </div>
        </div>

        {/* Total Verified Collection */}
        <div
          onClick={() => onNavigate('reports')}
          className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs hover:border-blue-300 hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-600">
              {t.totalVerifiedCollection}
            </span>
            <div className="p-2 bg-emerald-50 text-emerald-700 rounded-xl group-hover:scale-110 transition-transform">
              <Wallet className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-emerald-700">
            {formatINR(stats?.totalVerifiedCollectionPaise || 0)}
          </div>
          <div className="text-[11px] text-slate-500 font-medium mt-1">
            एकूण पडताळलेली वसुली
          </div>
        </div>

        {/* Cash Collection */}
        <div
          onClick={() => onNavigate('reports')}
          className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs hover:border-amber-300 hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-600">
              {t.cashCollectionTotal}
            </span>
            <div className="p-2 bg-amber-50 text-amber-700 rounded-xl group-hover:scale-110 transition-transform">
              <Banknote className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-amber-800">
            {formatINR(stats?.cashCollectionPaise || 0)}
          </div>
          <div className="text-[11px] text-amber-600 font-semibold mt-1">
            रोख पावती जमा
          </div>
        </div>

        {/* Online Collection */}
        <div
          onClick={() => onNavigate('reports')}
          className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs hover:border-teal-300 hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-600">
              {t.onlineCollectionTotal}
            </span>
            <div className="p-2 bg-teal-50 text-teal-700 rounded-xl group-hover:scale-110 transition-transform">
              <Smartphone className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-teal-800">
            {formatINR(stats?.onlineCollectionPaise || 0)}
          </div>
          <div className="text-[11px] text-teal-600 font-semibold mt-1">
            UPI / QR कोड द्वारे
          </div>
        </div>

        {/* Pending Monthly Payments */}
        <div
          onClick={() => onNavigate('dues')}
          className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs hover:border-indigo-300 hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-600">
              {t.pendingMonthlyPayments}
            </span>
            <div className="p-2 bg-indigo-50 text-indigo-700 rounded-xl group-hover:scale-110 transition-transform">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-indigo-900">
            {formatINR(stats?.pendingMonthlyDuesPaise || 0)}
          </div>
          <div className="text-[11px] text-slate-500 font-medium mt-1">
            चालू महिन्यातील शिल्लक
          </div>
        </div>

        {/* Overdue Members */}
        <div
          onClick={() => onNavigate('members')}
          className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs hover:border-rose-300 hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-600">
              {t.overdueMembersCount}
            </span>
            <div className="p-2 bg-rose-50 text-rose-700 rounded-xl group-hover:scale-110 transition-transform">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-rose-700">
            {stats?.overdueMembers || 0}
          </div>
          <div className="text-[11px] text-rose-600 font-semibold mt-1">
            थकबाकी राहिलेले सभासद
          </div>
        </div>
      </div>

      {/* QUICK ACTION CARDS */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
        <h2 className="text-base font-extrabold text-blue-950 mb-4 flex items-center gap-2">
          <span>{t.quickActions}</span>
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
          <button
            onClick={() => onNavigate('members')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-blue-50/70 hover:bg-blue-100/80 border border-blue-100 text-blue-900 font-bold text-xs transition-all cursor-pointer group"
          >
            <div className="p-2 bg-blue-800 text-white rounded-xl mb-2 group-hover:scale-110 transition-transform">
              <Users className="w-4 h-4" />
            </div>
            <span>{t.members}</span>
          </button>

          <button
            onClick={onOpenAddMember}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-emerald-50/70 hover:bg-emerald-100/80 border border-emerald-100 text-emerald-950 font-bold text-xs transition-all cursor-pointer group"
          >
            <div className="p-2 bg-emerald-700 text-white rounded-xl mb-2 group-hover:scale-110 transition-transform">
              <UserPlus className="w-4 h-4" />
            </div>
            <span>{t.addMemberBtn}</span>
          </button>

          <button
            onClick={onOpenCashDeposit}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-amber-50/70 hover:bg-amber-100/80 border border-amber-100 text-amber-950 font-bold text-xs transition-all cursor-pointer group"
          >
            <div className="p-2 bg-amber-600 text-white rounded-xl mb-2 group-hover:scale-110 transition-transform">
              <Banknote className="w-4 h-4" />
            </div>
            <span>{t.monthlyDepositBtn}</span>
          </button>

          <button
            onClick={onOpenGenerateDuesModal}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-teal-50/70 hover:bg-teal-100/80 border border-teal-100 text-teal-950 font-bold text-xs transition-all cursor-pointer group"
          >
            <div className="p-2 bg-teal-700 text-white rounded-xl mb-2 group-hover:scale-110 transition-transform">
              <PlusCircle className="w-4 h-4" />
            </div>
            <span>हप्ते तयार करा</span>
          </button>

          <button
            onClick={() => onNavigate('dues')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-indigo-50/70 hover:bg-indigo-100/80 border border-indigo-100 text-indigo-950 font-bold text-xs transition-all cursor-pointer group"
          >
            <div className="p-2 bg-indigo-800 text-white rounded-xl mb-2 group-hover:scale-110 transition-transform">
              <CalendarCheck className="w-4 h-4" />
            </div>
            <span>{t.dues}</span>
          </button>

          <button
            onClick={() => onNavigate('receipts')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-purple-50/70 hover:bg-purple-100/80 border border-purple-100 text-purple-950 font-bold text-xs transition-all cursor-pointer group"
          >
            <div className="p-2 bg-purple-700 text-white rounded-xl mb-2 group-hover:scale-110 transition-transform">
              <FileCheck className="w-4 h-4" />
            </div>
            <span>{t.receipts}</span>
          </button>

          <button
            onClick={() => onNavigate('reports')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-sky-50/70 hover:bg-sky-100/80 border border-sky-100 text-sky-950 font-bold text-xs transition-all cursor-pointer group"
          >
            <div className="p-2 bg-sky-700 text-white rounded-xl mb-2 group-hover:scale-110 transition-transform">
              <FileText className="w-4 h-4" />
            </div>
            <span>{t.reports}</span>
          </button>

          <button
            onClick={() => onNavigate('settings')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-amber-50/70 hover:bg-amber-100/90 border border-amber-200 text-amber-950 font-bold text-xs transition-all cursor-pointer group shadow-2xs"
            title="संस्था व अ‍ॅप सेटिंग्ज (Admin Settings & Modify App)"
          >
            <div className="p-2 bg-amber-600 text-white rounded-xl mb-2 group-hover:scale-110 transition-transform shadow-xs">
              <Settings className="w-4 h-4" />
            </div>
            <span>{t.settings}</span>
          </button>
        </div>
      </div>

      {/* MONTHLY COLLECTION CHARTS & BREAKDOWN */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Monthly Collection Bar Trend */}
        <div className="lg:col-span-2 bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-base font-extrabold text-blue-950">
                {t.monthlyCollectionChart}
              </h2>
              <p className="text-xs text-slate-500">
                महिन्यानुसार जमा झालेली रक्कम (रोख व ऑनलाइन वर्गणी)
              </p>
            </div>
            <div className="flex items-center gap-3 text-xs">
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-sm bg-amber-500" />
                <span className="text-slate-600 font-medium">रोख (Cash)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-sm bg-teal-600" />
                <span className="text-slate-600 font-medium">ऑनलाइन (UPI)</span>
              </div>
            </div>
          </div>

          {/* Bar Chart Area */}
          <div className="h-64 flex items-end gap-4 pt-6 px-2 border-b border-slate-100">
            {trends.length === 0 ? (
              <div className="w-full h-full flex items-center justify-center text-xs text-slate-400">
                अद्याप जमा नोंदी नाहीत
              </div>
            ) : (
              trends.map((item) => {
                const heightPercent = Math.max(12, Math.round((item.totalPaise / maxCollection) * 100));
                const cashPercent = item.totalPaise > 0 ? (item.cashPaise / item.totalPaise) * 100 : 50;
                const onlinePercent = 100 - cashPercent;

                return (
                  <div key={item.monthYear} className="flex-1 flex flex-col items-center h-full justify-end group relative">
                    {/* Tooltip on hover */}
                    <div className="absolute -top-12 opacity-0 group-hover:opacity-100 pointer-events-none transition-all duration-200 bg-slate-900 text-white text-[10px] font-bold py-1 px-2 rounded-md shadow-lg whitespace-nowrap z-20">
                      <div>एकूण: {formatINR(item.totalPaise)}</div>
                      <div className="text-amber-300">रोख: {formatINR(item.cashPaise)}</div>
                      <div className="text-teal-300">UPI: {formatINR(item.onlinePaise)}</div>
                    </div>

                    {/* Stacked bar */}
                    <div
                      style={{ height: `${heightPercent}%` }}
                      className="w-full max-w-[48px] rounded-t-lg overflow-hidden flex flex-col justify-end bg-slate-100 border border-slate-200 transition-all group-hover:scale-105"
                    >
                      <div
                        style={{ height: `${onlinePercent}%` }}
                        className="w-full bg-teal-600"
                        title={`Online: ${formatINR(item.onlinePaise)}`}
                      />
                      <div
                        style={{ height: `${cashPercent}%` }}
                        className="w-full bg-amber-500"
                        title={`Cash: ${formatINR(item.cashPaise)}`}
                      />
                    </div>

                    <span className="text-[11px] font-semibold text-slate-600 mt-2 truncate w-full text-center">
                      {item.monthLabel}
                    </span>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Payment Method Breakdown Doughnut Style */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <h2 className="text-base font-extrabold text-blue-950 mb-1">
              {t.collectionBreakdown}
            </h2>
            <p className="text-xs text-slate-500 mb-6">
              रोख रक्कम विरुद्ध ऑनलाइन UPI व्यवहार तुलना
            </p>

            {/* Visual Ring Indicator */}
            {(() => {
              const total = stats?.totalVerifiedCollectionPaise || 1;
              const cashShare = Math.round(((stats?.cashCollectionPaise || 0) / total) * 100);
              const onlineShare = 100 - cashShare;

              return (
                <div className="flex flex-col items-center">
                  <div className="relative w-36 h-36 flex items-center justify-center">
                    <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                      <path
                        className="text-slate-100"
                        strokeWidth="4"
                        stroke="currentColor"
                        fill="none"
                        d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                      />
                      <path
                        className="text-amber-500"
                        strokeDasharray={`${cashShare}, 100`}
                        strokeWidth="4"
                        strokeLinecap="round"
                        stroke="currentColor"
                        fill="none"
                        d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                      />
                      <path
                        className="text-teal-600"
                        strokeDasharray={`${onlineShare}, 100`}
                        strokeDashoffset={`-${cashShare}`}
                        strokeWidth="4"
                        strokeLinecap="round"
                        stroke="currentColor"
                        fill="none"
                        d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                      />
                    </svg>
                    <div className="absolute flex flex-col items-center text-center">
                      <span className="text-xs text-slate-400 font-bold uppercase">एकूण</span>
                      <span className="text-sm font-black text-blue-950">
                        {formatINR(stats?.totalVerifiedCollectionPaise || 0)}
                      </span>
                    </div>
                  </div>

                  <div className="w-full mt-6 space-y-2">
                    <div className="flex items-center justify-between p-2 rounded-xl bg-amber-50 border border-amber-200">
                      <div className="flex items-center gap-2">
                        <span className="w-3 h-3 rounded-full bg-amber-500" />
                        <span className="text-xs font-bold text-amber-950">{t.cash}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-xs font-black text-amber-900 block">
                          {formatINR(stats?.cashCollectionPaise || 0)}
                        </span>
                        <span className="text-[10px] text-amber-700">{cashShare}%</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-2 rounded-xl bg-teal-50 border border-teal-200">
                      <div className="flex items-center gap-2">
                        <span className="w-3 h-3 rounded-full bg-teal-600" />
                        <span className="text-xs font-bold text-teal-950">{t.onlineUpi}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-xs font-black text-teal-900 block">
                          {formatINR(stats?.onlineCollectionPaise || 0)}
                        </span>
                        <span className="text-[10px] text-teal-700">{onlineShare}%</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })()}
          </div>

          <button
            onClick={() => onNavigate('reports')}
            className="w-full mt-4 py-2 px-3 text-xs font-bold text-blue-800 bg-blue-50 hover:bg-blue-100 rounded-xl transition-colors flex items-center justify-center gap-1"
          >
            <span>विस्तृत अहवाल पहा (View Full Reports)</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* RECENT VERIFIED TRANSACTIONS TABLE */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-base font-extrabold text-blue-950">
              {t.recentTransactions}
            </h2>
            <p className="text-xs text-slate-500">
              थेट डेटाबेसमधून पडताळलेले अलीकडील व्यवहार
            </p>
          </div>
          <button
            onClick={() => onNavigate('receipts')}
            className="text-xs font-bold text-blue-700 hover:text-blue-900 flex items-center gap-1"
          >
            <span>सर्व पावत्या पहा</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500 uppercase tracking-wider font-bold">
                <th className="py-3 px-3">{t.receiptNumber}</th>
                <th className="py-3 px-3">{t.memberId} व नाव</th>
                <th className="py-3 px-3">{t.monthYear}</th>
                <th className="py-3 px-3">{t.amount}</th>
                <th className="py-3 px-3">{t.method}</th>
                <th className="py-3 px-3">{t.date}</th>
                <th className="py-3 px-3 text-right">{t.actions}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {recentPayments.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-6 text-center text-slate-400">
                    व्यवहार उपलब्ध नाहीत
                  </td>
                </tr>
              ) : (
                recentPayments.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-3 font-mono font-bold text-blue-900">
                      {p.receiptNumber}
                    </td>
                    <td className="py-3 px-3">
                      <div className="font-bold text-slate-900">{p.memberName}</div>
                      <div className="text-[10px] text-slate-400 font-mono">{p.memberId}</div>
                    </td>
                    <td className="py-3 px-3 text-slate-700">{p.monthYear}</td>
                    <td className="py-3 px-3 font-bold text-emerald-700">
                      {formatINR(p.amountPaise)}
                    </td>
                    <td className="py-3 px-3">
                      <span
                        className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold ${
                          p.paymentMethod === 'cash'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-teal-100 text-teal-800'
                        }`}
                      >
                        {p.paymentMethod === 'cash' ? 'रोख (Cash)' : 'ऑनलाइन (UPI)'}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-slate-500">
                      {formatDate(p.paymentDate)}
                    </td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={() => handleReceiptClick(p.receiptNumber)}
                        className="px-2.5 py-1 text-[11px] font-bold text-blue-800 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors inline-flex items-center gap-1 cursor-pointer"
                      >
                        <FileText className="w-3 h-3" />
                        <span>पावती</span>
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
