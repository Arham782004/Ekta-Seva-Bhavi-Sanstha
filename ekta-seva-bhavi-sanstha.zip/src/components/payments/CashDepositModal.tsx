import React, { useState, useEffect } from 'react';
import { useLanguage } from '../../context/LanguageContext.js';
import { useAuth } from '../../context/AuthContext.js';
import { api } from '../../services/api.js';
import { Member, MonthlyDue, Receipt } from '../../types/index.js';
import { formatINR } from '../../utils/formatters.js';
import confetti from 'canvas-confetti';
import {
  X,
  Banknote,
  Calendar,
  User,
  CheckCircle,
  AlertCircle,
  FileCheck,
} from 'lucide-react';

interface CashDepositModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultMemberId?: string;
  defaultMonthYear?: string;
  onPaymentSuccess: (receipt: Receipt) => void;
}

export const CashDepositModal: React.FC<CashDepositModalProps> = ({
  isOpen,
  onClose,
  defaultMemberId,
  defaultMonthYear,
  onPaymentSuccess,
}) => {
  const { t } = useLanguage();
  const { user } = useAuth();
  const [members, setMembers] = useState<Member[]>([]);
  const [selectedMemberId, setSelectedMemberId] = useState(defaultMemberId || '');
  const [selectedMonthYear, setSelectedMonthYear] = useState(
    defaultMonthYear || new Date().toISOString().slice(0, 7)
  );
  const [amountInr, setAmountInr] = useState(1000);
  const [paymentDate, setPaymentDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [receivedBy, setReceivedBy] = useState(user?.name || 'Santoshrao Mali');
  const [notes, setNotes] = useState('');

  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (isOpen) {
      api.members.getAll({ status: 'active' }).then(setMembers).catch(console.error);
      if (defaultMemberId) setSelectedMemberId(defaultMemberId);
      if (defaultMonthYear) setSelectedMonthYear(defaultMonthYear);
      if (user?.name) setReceivedBy(user.name);
    }
  }, [isOpen, defaultMemberId, defaultMonthYear, user]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!selectedMemberId) {
      setError('कृपया सदस्य निवडा');
      return;
    }

    if (amountInr <= 0) {
      setError('रक्कम ₹० पेक्षा जास्त असणे आवश्यक आहे');
      return;
    }

    setIsLoading(true);
    try {
      const res = await api.payments.recordCash({
        memberId: selectedMemberId,
        monthYear: selectedMonthYear,
        amountPaise: Math.round(amountInr * 100),
        paymentDate: `${paymentDate}T12:00:00.000Z`,
        receivedByAdminName: receivedBy.trim(),
        notes: notes.trim() || 'रोख वर्गणी जमा (Cash deposit received at Sanstha office)',
      });

      // Fire celebratory confetti!
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch {
        // ignore
      }

      onPaymentSuccess(res.receipt);
      onClose();
    } catch (err: any) {
      setError(err.message || 'पेमेंट नोंदवताना त्रुटी आली');
    } finally {
      setIsLoading(false);
    }
  };

  const selectedMemberObj = members.find((m) => m.memberId === selectedMemberId);

  // Generate selectable months (last 4 months + next 2 months)
  const currentYear = new Date().getFullYear();
  const availableMonths = [
    { key: `${currentYear}-07`, label: `July ${currentYear}` },
    { key: `${currentYear}-08`, label: `August ${currentYear}` },
    { key: `${currentYear}-09`, label: `September ${currentYear}` },
    { key: `${currentYear}-10`, label: `October ${currentYear}` },
    { key: `${currentYear}-11`, label: `November ${currentYear}` },
    { key: `${currentYear}-12`, label: `December ${currentYear}` },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 relative my-8">
        <button
          onClick={onClose}
          className="absolute top-6 right-6 p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-full transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-amber-100 text-amber-900 rounded-2xl">
            <Banknote className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-extrabold text-blue-950">
              {t.recordCashDeposit}
            </h2>
            <p className="text-xs text-slate-500">
              माळी गल्ली, कळमनुरी • रोख पावती जमा फॉर्म (Cash Receipt Entry)
            </p>
          </div>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              {t.selectMember} *
            </label>
            <select
              required
              value={selectedMemberId}
              onChange={(e) => setSelectedMemberId(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:bg-white focus:ring-2 focus:ring-blue-600 font-medium"
            >
              <option value="">-- सदस्य निवडा (Select Member) --</option>
              {members.map((m) => (
                <option key={m.id} value={m.memberId}>
                  {m.memberId} — {m.fullName} ({m.mobile})
                </option>
              ))}
            </select>
            {selectedMemberObj && (
              <div className="mt-1.5 text-[11px] text-slate-500 flex items-center gap-2">
                <span>पत्ता: {selectedMemberObj.address || 'Kalamnuri'}</span>
                <span>• मासिक वर्गणी: ₹{selectedMemberObj.monthlyContributionPaise / 100}</span>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                {t.selectMonth} *
              </label>
              <select
                required
                value={selectedMonthYear}
                onChange={(e) => setSelectedMonthYear(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:bg-white focus:ring-2 focus:ring-blue-600 font-medium"
              >
                {availableMonths.map((mo) => (
                  <option key={mo.key} value={mo.key}>
                    {mo.label} ({mo.key})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                जमा रक्कम (₹) *
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-slate-500 font-bold">₹</span>
                <input
                  type="number"
                  required
                  min={50}
                  step={50}
                  value={amountInr}
                  onChange={(e) => setAmountInr(Number(e.target.value))}
                  className="w-full pl-8 pr-3 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-extrabold text-blue-900 focus:bg-white focus:ring-2 focus:ring-blue-600"
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                जमा दिनांक *
              </label>
              <input
                type="date"
                required
                value={paymentDate}
                onChange={(e) => setPaymentDate(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:bg-white focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                {t.receivedBy} *
              </label>
              <input
                type="text"
                required
                value={receivedBy}
                onChange={(e) => setReceivedBy(e.target.value)}
                placeholder="प्रशासकाचे नाव"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:bg-white focus:ring-2 focus:ring-blue-600 font-medium"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              {t.notes}
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="उदा. कार्यालयात रोख पावती दिली"
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:bg-white focus:ring-2 focus:ring-blue-600"
            />
          </div>

          <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-amber-700 flex-shrink-0" />
            <span>
              नोंदवल्यावर लगेच संस्थेची अधिकृत पावती (Receipt) तयार होऊन सदस्याच्या खात्यात जमा दिसेल.
            </span>
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
            >
              {t.cancel}
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="px-6 py-2.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all flex items-center gap-2 disabled:opacity-50 cursor-pointer"
            >
              {isLoading ? <span>{t.loading}</span> : <span>{t.confirm} व पावती काढा</span>}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
